"""
Generator for int8-quantized ONNX models.

Complements gen_full_models.py (complete models) and gen_single_op_models.py
(one float operator per model): this script specifically covers
quantize/dequantize operators and the integer (int8) variants of compute
operators, in order to test conversion of quantized graphs by the Aidge
framework (`aidge-quantization`).

Two levels of granularity:
- single_op/  : a single (de)quantization or integer compute operator per
                file (same approach as gen_single_op_models.py).
- a composite model (qdq_cnn_block.onnx) representing a CNN block quantized
  in the QDQ format (QuantizeLinear/DequantizeLinear around
  Conv/Relu/MaxPool), as produced by training frameworks after
  quantization-aware training or post-training quantization.

Run:  python gen_quantized_int8_models.py
"""
import os

import numpy as np
import onnx
from onnx import TensorProto, checker, helper

from _common import io_entry_from_value_info, write_json_metadata

MODELS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATEGORY = "quantized_int8"
rng = np.random.default_rng(11)


def qconst(shape, low=-127, high=127):
    return rng.integers(low, high, size=shape, endpoint=True).astype(np.int8)


def fconst(shape, low=-0.5, high=0.5):
    return rng.uniform(low, high, size=shape).astype(np.float32)


def tensor(name, arr, dtype):
    arr = np.asarray(arr)
    return helper.make_tensor(name, dtype, list(arr.shape), arr.flatten().tolist())


def vi(name, shape, dtype=TensorProto.FLOAT):
    return helper.make_tensor_value_info(name, dtype, shape)


def build(subfolder, filename, inputs, outputs, nodes, initializers, doc):
    graph = helper.make_graph(
        nodes, filename.replace(".onnx", ""), inputs, outputs, initializers,
        doc_string=doc,
    )
    model = helper.make_model(
        graph,
        producer_name="aidge-test-model-generator",
        opset_imports=[helper.make_opsetid("", 17)],
    )
    model.ir_version = 8
    checker.check_model(model)

    out_dir = os.path.join(MODELS_DIR, CATEGORY, subfolder) if subfolder else os.path.join(MODELS_DIR, CATEGORY)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, filename)
    onnx.save(model, out_path)

    model_name = filename.replace(".onnx", "")
    io_inputs = [io_entry_from_value_info(v, f"Graph input '{v.name}' of the {model_name} model.") for v in inputs]
    io_outputs = [io_entry_from_value_info(v, f"Graph output '{v.name}' of the {model_name} model.") for v in outputs]
    write_json_metadata(out_path, doc, io_inputs, io_outputs)

    size_b = os.path.getsize(out_path)
    print(f"{(subfolder + '/' if subfolder else ''):<12}{filename:<26} {size_b:6d} B  - {doc}")


# ---------------------------------------------------------------------------
# single_op/ : a single (de)quantization or integer compute operator
# ---------------------------------------------------------------------------

def gen_quantizelinear():
    x = vi("input", [1, 8])
    y = vi("output", [1, 8], TensorProto.INT8)
    scale = tensor("scale", np.float32(0.05), TensorProto.FLOAT)
    zp = tensor("zero_point", np.int8(0), TensorProto.INT8)
    nodes = [helper.make_node("QuantizeLinear", ["input", "scale", "zero_point"], ["output"])]
    build("single_op", "quantizelinear.onnx", [x], [y], nodes, [scale, zp],
          "Linear quantization float32 -> int8")


def gen_dequantizelinear():
    x = vi("input", [1, 8], TensorProto.INT8)
    y = vi("output", [1, 8])
    scale = tensor("scale", np.float32(0.05), TensorProto.FLOAT)
    zp = tensor("zero_point", np.int8(0), TensorProto.INT8)
    nodes = [helper.make_node("DequantizeLinear", ["input", "scale", "zero_point"], ["output"])]
    build("single_op", "dequantizelinear.onnx", [x], [y], nodes, [scale, zp],
          "Linear dequantization int8 -> float32")


def gen_dynamicquantizelinear():
    x = vi("input", [1, 8])
    y = vi("output", [1, 8], TensorProto.UINT8)
    y_scale = vi("y_scale", [], TensorProto.FLOAT)
    y_zp = vi("y_zero_point", [], TensorProto.UINT8)
    nodes = [helper.make_node("DynamicQuantizeLinear", ["input"], ["output", "y_scale", "y_zero_point"])]
    build("single_op", "dynamicquantizelinear.onnx", [x], [y, y_scale, y_zp], nodes, [],
          "Dynamic quantization (scale/zero-point computed on the fly) float32 -> uint8")


def gen_qlinearconv():
    x = vi("input", [1, 4, 8, 8], TensorProto.INT8)
    y = vi("output", [1, 8, 8, 8], TensorProto.INT8)

    w = qconst((8, 4, 3, 3))
    bias = (fconst((8,), -1, 1) * 1000).astype(np.int32)

    x_scale = tensor("x_scale", np.float32(0.04), TensorProto.FLOAT)
    x_zp = tensor("x_zp", np.int8(0), TensorProto.INT8)
    w_scale = tensor("w_scale", np.float32(0.01), TensorProto.FLOAT)
    w_zp = tensor("w_zp", np.int8(0), TensorProto.INT8)
    y_scale = tensor("y_scale", np.float32(0.06), TensorProto.FLOAT)
    y_zp = tensor("y_zp", np.int8(0), TensorProto.INT8)

    nodes = [helper.make_node(
        "QLinearConv",
        ["input", "x_scale", "x_zp", "w", "w_scale", "w_zp", "y_scale", "y_zp", "bias"],
        ["output"], kernel_shape=[3, 3], pads=[1, 1, 1, 1],
    )]
    inits = [x_scale, x_zp, tensor("w", w, TensorProto.INT8), w_scale, w_zp,
             y_scale, y_zp, tensor("bias", bias, TensorProto.INT32)]
    build("single_op", "qlinearconv.onnx", [x], [y], nodes, inits,
          "Fully quantized int8 2D convolution (inputs, weights, int32 bias, output)")


def gen_qlinearmatmul():
    a = vi("input", [1, 16], TensorProto.INT8)
    y = vi("output", [1, 10], TensorProto.INT8)

    b = qconst((16, 10))
    a_scale = tensor("a_scale", np.float32(0.03), TensorProto.FLOAT)
    a_zp = tensor("a_zp", np.int8(0), TensorProto.INT8)
    b_scale = tensor("b_scale", np.float32(0.02), TensorProto.FLOAT)
    b_zp = tensor("b_zp", np.int8(0), TensorProto.INT8)
    y_scale = tensor("y_scale", np.float32(0.05), TensorProto.FLOAT)
    y_zp = tensor("y_zp", np.int8(0), TensorProto.INT8)

    nodes = [helper.make_node(
        "QLinearMatMul",
        ["input", "a_scale", "a_zp", "b", "b_scale", "b_zp", "y_scale", "y_zp"],
        ["output"],
    )]
    inits = [a_scale, a_zp, tensor("b", b, TensorProto.INT8), b_scale, b_zp, y_scale, y_zp]
    build("single_op", "qlinearmatmul.onnx", [a], [y], nodes, inits,
          "Fully quantized int8 matrix multiplication")


def gen_convinteger():
    x = vi("input", [1, 4, 8, 8], TensorProto.INT8)
    y = vi("output", [1, 8, 8, 8], TensorProto.INT32)

    w = qconst((8, 4, 3, 3))
    x_zp = tensor("x_zp", np.int8(0), TensorProto.INT8)
    w_zp = tensor("w_zp", np.int8(0), TensorProto.INT8)

    nodes = [helper.make_node(
        "ConvInteger", ["input", "w", "x_zp", "w_zp"], ["output"],
        kernel_shape=[3, 3], pads=[1, 1, 1, 1],
    )]
    inits = [tensor("w", w, TensorProto.INT8), x_zp, w_zp]
    build("single_op", "convinteger.onnx", [x], [y], nodes, inits,
          "2D convolution in integer arithmetic (int32 output, not re-quantized)")


def gen_matmulinteger():
    a = vi("input", [1, 16], TensorProto.INT8)
    y = vi("output", [1, 10], TensorProto.INT32)

    b = qconst((16, 10))
    a_zp = tensor("a_zp", np.int8(0), TensorProto.INT8)
    b_zp = tensor("b_zp", np.int8(0), TensorProto.INT8)

    nodes = [helper.make_node("MatMulInteger", ["input", "b", "a_zp", "b_zp"], ["output"])]
    inits = [tensor("b", b, TensorProto.INT8), a_zp, b_zp]
    build("single_op", "matmulinteger.onnx", [a], [y], nodes, inits,
          "Matrix multiplication in integer arithmetic (int32 output, not re-quantized)")


# ---------------------------------------------------------------------------
# Composite model: CNN block quantized in the QDQ format
# ---------------------------------------------------------------------------

def gen_qdq_cnn_block():
    x = vi("input", [1, 4, 16, 16])
    y = vi("output", [1, 8, 8, 8])

    conv_w = fconst((8, 4, 3, 3))
    conv_b = fconst((8,))

    nodes = [
        # Quantize the input activation
        helper.make_node("QuantizeLinear", ["input", "in_scale", "in_zp"], ["input_q"]),
        helper.make_node("DequantizeLinear", ["input_q", "in_scale", "in_zp"], ["input_dq"]),

        # Quantize the weights (repeated for each use, as a standard QDQ
        # export would produce)
        helper.make_node("QuantizeLinear", ["conv_w", "w_scale", "w_zp"], ["conv_w_q"]),
        helper.make_node("DequantizeLinear", ["conv_w_q", "w_scale", "w_zp"], ["conv_w_dq"]),

        helper.make_node("Conv", ["input_dq", "conv_w_dq", "conv_b"], ["conv_out"],
                          kernel_shape=[3, 3], pads=[1, 1, 1, 1]),
        helper.make_node("Relu", ["conv_out"], ["relu_out"]),

        # Quantize the activation output before pooling
        helper.make_node("QuantizeLinear", ["relu_out", "act_scale", "act_zp"], ["relu_out_q"]),
        helper.make_node("DequantizeLinear", ["relu_out_q", "act_scale", "act_zp"], ["relu_out_dq"]),

        helper.make_node("MaxPool", ["relu_out_dq"], ["output"], kernel_shape=[2, 2], strides=[2, 2]),
    ]
    inits = [
        tensor("conv_w", conv_w, TensorProto.FLOAT),
        tensor("conv_b", conv_b, TensorProto.FLOAT),
        tensor("in_scale", np.float32(0.04), TensorProto.FLOAT),
        tensor("in_zp", np.int8(0), TensorProto.INT8),
        tensor("w_scale", np.float32(0.01), TensorProto.FLOAT),
        tensor("w_zp", np.int8(0), TensorProto.INT8),
        tensor("act_scale", np.float32(0.06), TensorProto.FLOAT),
        tensor("act_zp", np.int8(0), TensorProto.INT8),
    ]
    build(None, "qdq_cnn_block.onnx", [x], [y], nodes, inits,
          "CNN block quantized in the QDQ format (QuantizeLinear/DequantizeLinear "
          "around Conv/Relu/MaxPool), representative of a post-PTQ int8 export")


if __name__ == "__main__":
    gen_quantizelinear()
    gen_dequantizelinear()
    gen_dynamicquantizelinear()
    gen_qlinearconv()
    gen_qlinearmatmul()
    gen_convinteger()
    gen_matmulinteger()

    gen_qdq_cnn_block()

    print("\nDone.")
