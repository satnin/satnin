"""
Generator for tiny ONNX models used to test conversion by the Aidge framework.

Each model is deliberately tiny (tens of KB) but chosen to cover a specific
ONNX operator or a particular combination of operators.
Run with:  python gen_full_models.py
"""
import os

import numpy as np
import onnx
from onnx import TensorProto, checker, helper

from _common import io_entry_from_value_info, write_json_metadata

MODELS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rng = np.random.default_rng(42)


def const(name, shape, low=-0.3, high=0.3):
    return rng.uniform(low, high, size=shape).astype(np.float32)


def make_initializer(name, arr):
    return helper.make_tensor(
        name, TensorProto.FLOAT, list(arr.shape), arr.flatten().tolist()
    )


def build_and_save(category, filename, inputs, outputs, nodes, initializers, doc):
    graph = helper.make_graph(
        nodes, filename.replace(".onnx", ""), inputs, outputs, initializers,
        doc_string=doc,
    )
    model = helper.make_model(
        graph,
        producer_name="aidge-test-model-generator",
        opset_imports=[helper.make_opsetid("", 17)],
    )
    model.ir_version = 8
    checker.check_model(model)

    out_dir = os.path.join(MODELS_DIR, category)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, filename)
    onnx.save(model, out_path)

    io_inputs = [io_entry_from_value_info(v, f"Graph input '{v.name}' of the {filename.replace('.onnx', '')} model.") for v in inputs]
    io_outputs = [io_entry_from_value_info(v, f"Graph output '{v.name}' of the {filename.replace('.onnx', '')} model.") for v in outputs]
    write_json_metadata(out_path, doc, io_inputs, io_outputs)

    size_kb = os.path.getsize(out_path) / 1024
    print(f"[{category}] {filename:<28} {size_kb:6.1f} KB  - {doc}")


# ---------------------------------------------------------------------------
# 1. MLP
# ---------------------------------------------------------------------------

def gen_mlp_classifier():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 64])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 10])

    w1 = const("w1", (64, 48))
    b1 = const("b1", (48,))
    w2 = const("w2", (48, 32))
    b2 = const("b2", (32,))
    w3 = const("w3", (32, 10))
    b3 = const("b3", (10,))

    nodes = [
        helper.make_node("Gemm", ["input", "w1", "b1"], ["h1"], alpha=1.0, beta=1.0),
        helper.make_node("Relu", ["h1"], ["h1r"]),
        helper.make_node("Gemm", ["h1r", "w2", "b2"], ["h2"]),
        helper.make_node("Relu", ["h2"], ["h2r"]),
        helper.make_node("Gemm", ["h2r", "w3", "b3"], ["h3"]),
        helper.make_node("Softmax", ["h3"], ["output"], axis=1),
    ]
    inits = [make_initializer("w1", w1), make_initializer("b1", b1),
             make_initializer("w2", w2), make_initializer("b2", b2),
             make_initializer("w3", w3), make_initializer("b3", b3)]
    build_and_save("full_models/mlp", "mlp_classifier.onnx", [x], [y], nodes, inits,
                   "3-layer MLP: Gemm, Relu, Softmax")


def gen_mlp_residual():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 32])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 32])

    w1 = const("w1", (32, 32))
    b1 = const("b1", (32,))
    w2 = const("w2", (32, 32))
    b2 = const("b2", (32,))

    nodes = [
        helper.make_node("Gemm", ["input", "w1", "b1"], ["h1"]),
        helper.make_node("Sigmoid", ["h1"], ["h1s"]),
        helper.make_node("Gemm", ["h1s", "w2", "b2"], ["h2"]),
        helper.make_node("Tanh", ["h2"], ["h2t"]),
        helper.make_node("Add", ["h2t", "input"], ["res"]),
        helper.make_node("Identity", ["res"], ["output"]),
    ]
    inits = [make_initializer("w1", w1), make_initializer("b1", b1),
             make_initializer("w2", w2), make_initializer("b2", b2)]
    build_and_save("full_models/mlp", "mlp_residual.onnx", [x], [y], nodes, inits,
                   "MLP with a residual connection: Gemm, Sigmoid, Tanh, Add, Identity")


# ---------------------------------------------------------------------------
# 2. CNN
# ---------------------------------------------------------------------------

def gen_cnn_basic():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 1, 28, 28])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 10])

    conv1_w = const("conv1_w", (8, 1, 3, 3))
    conv1_b = const("conv1_b", (8,))
    bn_scale = np.ones(8, dtype=np.float32)
    bn_bias = np.zeros(8, dtype=np.float32)
    bn_mean = np.zeros(8, dtype=np.float32)
    bn_var = np.ones(8, dtype=np.float32)
    conv2_w = const("conv2_w", (16, 8, 3, 3))
    conv2_b = const("conv2_b", (16,))
    fc_w = const("fc_w", (16, 10))
    fc_b = const("fc_b", (10,))

    nodes = [
        helper.make_node("Conv", ["input", "conv1_w", "conv1_b"], ["c1"], kernel_shape=[3, 3], pads=[1, 1, 1, 1]),
        helper.make_node("BatchNormalization", ["c1", "bn_scale", "bn_bias", "bn_mean", "bn_var"], ["bn1"]),
        helper.make_node("Relu", ["bn1"], ["r1"]),
        helper.make_node("MaxPool", ["r1"], ["p1"], kernel_shape=[2, 2], strides=[2, 2]),
        helper.make_node("Conv", ["p1", "conv2_w", "conv2_b"], ["c2"], kernel_shape=[3, 3], pads=[1, 1, 1, 1]),
        helper.make_node("Relu", ["c2"], ["r2"]),
        helper.make_node("GlobalAveragePool", ["r2"], ["gap"]),
        helper.make_node("Flatten", ["gap"], ["flat"]),
        helper.make_node("Gemm", ["flat", "fc_w", "fc_b"], ["fc"]),
        helper.make_node("Softmax", ["fc"], ["output"], axis=1),
    ]
    inits = [
        make_initializer("conv1_w", conv1_w), make_initializer("conv1_b", conv1_b),
        make_initializer("bn_scale", bn_scale), make_initializer("bn_bias", bn_bias),
        make_initializer("bn_mean", bn_mean), make_initializer("bn_var", bn_var),
        make_initializer("conv2_w", conv2_w), make_initializer("conv2_b", conv2_b),
        make_initializer("fc_w", fc_w), make_initializer("fc_b", fc_b),
    ]
    build_and_save("full_models/cnn", "cnn_basic.onnx", [x], [y], nodes, inits,
                   "Simple LeNet-style CNN: Conv, BatchNormalization, Relu, MaxPool, GlobalAveragePool, Flatten, Gemm, Softmax")


def gen_cnn_residual():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 8, 16, 16])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 8, 16, 16])

    w1 = const("w1", (8, 8, 3, 3))
    b1 = const("b1", (8,))
    w2 = const("w2", (8, 8, 3, 3))
    b2 = const("b2", (8,))
    bn_scale = np.ones(8, dtype=np.float32)
    bn_bias = np.zeros(8, dtype=np.float32)
    bn_mean = np.zeros(8, dtype=np.float32)
    bn_var = np.ones(8, dtype=np.float32)

    nodes = [
        helper.make_node("Conv", ["input", "w1", "b1"], ["c1"], kernel_shape=[3, 3], pads=[1, 1, 1, 1]),
        helper.make_node("BatchNormalization", ["c1", "bn_scale", "bn_bias", "bn_mean", "bn_var"], ["bn1"]),
        helper.make_node("Relu", ["bn1"], ["r1"]),
        helper.make_node("Conv", ["r1", "w2", "b2"], ["c2"], kernel_shape=[3, 3], pads=[1, 1, 1, 1]),
        helper.make_node("Add", ["c2", "input"], ["skip"]),
        helper.make_node("Relu", ["skip"], ["output"]),
    ]
    inits = [make_initializer("w1", w1), make_initializer("b1", b1),
             make_initializer("w2", w2), make_initializer("b2", b2),
             make_initializer("bn_scale", bn_scale), make_initializer("bn_bias", bn_bias),
             make_initializer("bn_mean", bn_mean), make_initializer("bn_var", bn_var)]
    build_and_save("full_models/cnn", "cnn_residual_block.onnx", [x], [y], nodes, inits,
                   "ResNet-style residual block: Conv, BatchNormalization, Relu, Add (skip connection)")


def gen_cnn_inception():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 4, 16, 16])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 6])

    w1x1 = const("w1x1", (4, 4, 1, 1))
    b1x1 = const("b1x1", (4,))
    w3x3 = const("w3x3", (4, 4, 3, 3))
    b3x3 = const("b3x3", (4,))
    w5x5 = const("w5x5", (4, 4, 5, 5))
    b5x5 = const("b5x5", (4,))
    fc_w = const("fc_w", (12, 6))
    fc_b = const("fc_b", (6,))

    nodes = [
        helper.make_node("Conv", ["input", "w1x1", "b1x1"], ["b1"], kernel_shape=[1, 1]),
        helper.make_node("Conv", ["input", "w3x3", "b3x3"], ["b2"], kernel_shape=[3, 3], pads=[1, 1, 1, 1]),
        helper.make_node("Conv", ["input", "w5x5", "b5x5"], ["b3"], kernel_shape=[5, 5], pads=[2, 2, 2, 2]),
        helper.make_node("Concat", ["b1", "b2", "b3"], ["cat"], axis=1),
        helper.make_node("LeakyRelu", ["cat"], ["act"], alpha=0.1),
        helper.make_node("GlobalAveragePool", ["act"], ["gap"]),
        helper.make_node("Flatten", ["gap"], ["flat"]),
        helper.make_node("Gemm", ["flat", "fc_w", "fc_b"], ["output"]),
    ]
    inits = [make_initializer("w1x1", w1x1), make_initializer("b1x1", b1x1),
             make_initializer("w3x3", w3x3), make_initializer("b3x3", b3x3),
             make_initializer("w5x5", w5x5), make_initializer("b5x5", b5x5),
             make_initializer("fc_w", fc_w), make_initializer("fc_b", fc_b)]
    build_and_save("full_models/cnn", "cnn_inception_block.onnx", [x], [y], nodes, inits,
                   "Multi-branch inception block: parallel Conv (1x1/3x3/5x5), Concat, LeakyRelu")


def gen_cnn_depthwise():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 8, 16, 16])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 16, 8, 8])

    dw_w = const("dw_w", (8, 1, 3, 3))
    dw_b = const("dw_b", (8,))
    pw_w = const("pw_w", (16, 8, 1, 1))
    pw_b = const("pw_b", (16,))

    nodes = [
        helper.make_node("Pad", ["input", "pads"], ["padded"], mode="constant"),
        helper.make_node("Conv", ["padded", "dw_w", "dw_b"], ["dw"], kernel_shape=[3, 3], group=8, strides=[1, 1]),
        helper.make_node("Clip", ["dw", "clip_min", "clip_max"], ["dw_clipped"]),
        helper.make_node("Conv", ["dw_clipped", "pw_w", "pw_b"], ["pw"], kernel_shape=[1, 1]),
        helper.make_node("MaxPool", ["pw"], ["output"], kernel_shape=[2, 2], strides=[2, 2]),
    ]
    pads = np.array([0, 0, 1, 1, 0, 0, 1, 1], dtype=np.int64)
    inits = [
        make_initializer("dw_w", dw_w), make_initializer("dw_b", dw_b),
        make_initializer("pw_w", pw_w), make_initializer("pw_b", pw_b),
        helper.make_tensor("pads", TensorProto.INT64, [8], pads.tolist()),
        helper.make_tensor("clip_min", TensorProto.FLOAT, [], [0.0]),
        helper.make_tensor("clip_max", TensorProto.FLOAT, [], [6.0]),
    ]
    build_and_save("full_models/cnn", "cnn_depthwise_separable.onnx", [x], [y], nodes, inits,
                   "MobileNet-style separable convolution: Pad, depthwise Conv (group), Clip (ReLU6), pointwise Conv, MaxPool")


# ---------------------------------------------------------------------------
# 3. RNN
# ---------------------------------------------------------------------------

def gen_rnn_lstm():
    seq_len, batch, input_size, hidden_size = 5, 1, 8, 16
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [seq_len, batch, input_size])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [batch, 4])

    w = const("W", (1, 4 * hidden_size, input_size))
    r = const("R", (1, 4 * hidden_size, hidden_size))
    b = const("B", (1, 8 * hidden_size,))
    fc_w = const("fc_w", (hidden_size, 4))
    fc_b = const("fc_b", (4,))

    nodes = [
        helper.make_node("LSTM", ["input", "W", "R", "B"], ["Y", "Y_h", "Y_c"],
                          hidden_size=hidden_size),
        helper.make_node("Squeeze", ["Y_h", "axis0"], ["h_last"]),
        helper.make_node("Gemm", ["h_last", "fc_w", "fc_b"], ["output"]),
    ]
    inits = [make_initializer("W", w), make_initializer("R", r), make_initializer("B", b),
             make_initializer("fc_w", fc_w), make_initializer("fc_b", fc_b),
             helper.make_tensor("axis0", TensorProto.INT64, [1], [0])]
    build_and_save("full_models/rnn", "rnn_lstm_classifier.onnx", [x], [y], nodes, inits,
                   "LSTM followed by a dense layer: LSTM, Squeeze, Gemm")


def gen_rnn_gru():
    seq_len, batch, input_size, hidden_size = 5, 1, 8, 12
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [seq_len, batch, input_size])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [batch, 3])

    w = const("W", (1, 3 * hidden_size, input_size))
    r = const("R", (1, 3 * hidden_size, hidden_size))
    b = const("B", (1, 6 * hidden_size,))
    fc_w = const("fc_w", (hidden_size, 3))
    fc_b = const("fc_b", (3,))

    nodes = [
        helper.make_node("GRU", ["input", "W", "R", "B"], ["Y", "Y_h"], hidden_size=hidden_size),
        helper.make_node("Squeeze", ["Y_h", "axis0"], ["h_last"]),
        helper.make_node("Gemm", ["h_last", "fc_w", "fc_b"], ["logits"]),
        helper.make_node("Sigmoid", ["logits"], ["output"]),
    ]
    inits = [make_initializer("W", w), make_initializer("R", r), make_initializer("B", b),
             make_initializer("fc_w", fc_w), make_initializer("fc_b", fc_b),
             helper.make_tensor("axis0", TensorProto.INT64, [1], [0])]
    build_and_save("full_models/rnn", "rnn_gru_classifier.onnx", [x], [y], nodes, inits,
                   "GRU followed by a dense layer: GRU, Squeeze, Gemm, Sigmoid")


# ---------------------------------------------------------------------------
# 4. Transformer / Attention
# ---------------------------------------------------------------------------

def gen_attention_block():
    batch, seq, dim = 1, 6, 16
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [batch, seq, dim])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [batch, seq, dim])

    wq = const("wq", (dim, dim))
    wk = const("wk", (dim, dim))
    wv = const("wv", (dim, dim))
    ln1_scale = np.ones(dim, dtype=np.float32)
    ln1_bias = np.zeros(dim, dtype=np.float32)
    ff_w1 = const("ff_w1", (dim, dim * 2))
    ff_b1 = const("ff_b1", (dim * 2,))
    ff_w2 = const("ff_w2", (dim * 2, dim))
    ff_b2 = const("ff_b2", (dim,))
    scale = np.array([1.0 / np.sqrt(dim)], dtype=np.float32)

    nodes = [
        helper.make_node("MatMul", ["input", "wq"], ["q"]),
        helper.make_node("MatMul", ["input", "wk"], ["k"]),
        helper.make_node("MatMul", ["input", "wv"], ["v"]),
        helper.make_node("Transpose", ["k"], ["kt"], perm=[0, 2, 1]),
        helper.make_node("MatMul", ["q", "kt"], ["scores"]),
        helper.make_node("Mul", ["scores", "scale"], ["scaled"]),
        helper.make_node("Softmax", ["scaled"], ["attn"], axis=-1),
        helper.make_node("MatMul", ["attn", "v"], ["ctx"]),
        helper.make_node("Add", ["ctx", "input"], ["res1"]),
        helper.make_node("ReduceMean", ["res1"], ["mean1"], axes=[-1], keepdims=1),
        helper.make_node("Sub", ["res1", "mean1"], ["centered1"]),
        helper.make_node("Mul", ["centered1", "centered1"], ["sq1"]),
        helper.make_node("ReduceMean", ["sq1"], ["var1"], axes=[-1], keepdims=1),
        helper.make_node("Add", ["var1", "eps"], ["var1_eps"]),
        helper.make_node("Sqrt", ["var1_eps"], ["std1"]),
        helper.make_node("Div", ["centered1", "std1"], ["norm1"]),
        helper.make_node("Mul", ["norm1", "ln1_scale"], ["norm1_scaled"]),
        helper.make_node("Add", ["norm1_scaled", "ln1_bias"], ["ln1"]),
        helper.make_node("MatMul", ["ln1", "ff_w1"], ["ff1"]),
        helper.make_node("Add", ["ff1", "ff_b1"], ["ff1b"]),
        helper.make_node("Erf", ["ff1b"], ["ff1_erf"]),
        helper.make_node("Mul", ["ff1_erf", "half"], ["ff1_erf_half"]),
        helper.make_node("Add", ["ff1_erf_half", "half"], ["ff1_gate"]),
        helper.make_node("Mul", ["ff1b", "ff1_gate"], ["ff1_gelu"]),
        helper.make_node("MatMul", ["ff1_gelu", "ff_w2"], ["ff2"]),
        helper.make_node("Add", ["ff2", "ff_b2"], ["ff2b"]),
        helper.make_node("Add", ["ff2b", "ln1"], ["output"]),
    ]
    inits = [
        make_initializer("wq", wq), make_initializer("wk", wk), make_initializer("wv", wv),
        helper.make_tensor("scale", TensorProto.FLOAT, [1], scale.tolist()),
        make_initializer("ln1_scale", ln1_scale), make_initializer("ln1_bias", ln1_bias),
        helper.make_tensor("eps", TensorProto.FLOAT, [], [1e-5]),
        helper.make_tensor("half", TensorProto.FLOAT, [], [0.5]),
        make_initializer("ff_w1", ff_w1), make_initializer("ff_b1", ff_b1),
        make_initializer("ff_w2", ff_w2), make_initializer("ff_b2", ff_b2),
    ]
    build_and_save("full_models/transformer", "attention_encoder_block.onnx", [x], [y], nodes, inits,
                   "Transformer-style encoder block: self-attention (MatMul/Transpose/Softmax), "
                   "manual normalization (ReduceMean/Sub/Sqrt/Div), feed-forward with GELU (Erf)")


# ---------------------------------------------------------------------------
# 5. Autoencoder
# ---------------------------------------------------------------------------

def gen_autoencoder():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 1, 16, 16])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 1, 16, 16])

    enc_w1 = const("enc_w1", (4, 1, 3, 3))
    enc_b1 = const("enc_b1", (4,))
    enc_w2 = const("enc_w2", (8, 4, 3, 3))
    enc_b2 = const("enc_b2", (8,))
    dec_w1 = const("dec_w1", (8, 4, 2, 2))
    dec_b1 = const("dec_b1", (4,))
    dec_w2 = const("dec_w2", (4, 1, 2, 2))
    dec_b2 = const("dec_b2", (1,))

    nodes = [
        helper.make_node("Conv", ["input", "enc_w1", "enc_b1"], ["e1"], kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[2, 2]),
        helper.make_node("Relu", ["e1"], ["e1r"]),
        helper.make_node("Conv", ["e1r", "enc_w2", "enc_b2"], ["e2"], kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[2, 2]),
        helper.make_node("Relu", ["e2"], ["latent"]),
        helper.make_node("ConvTranspose", ["latent", "dec_w1", "dec_b1"], ["d1"], kernel_shape=[2, 2], strides=[2, 2]),
        helper.make_node("Relu", ["d1"], ["d1r"]),
        helper.make_node("ConvTranspose", ["d1r", "dec_w2", "dec_b2"], ["d2"], kernel_shape=[2, 2], strides=[2, 2]),
        helper.make_node("Sigmoid", ["d2"], ["output"]),
    ]
    inits = [
        make_initializer("enc_w1", enc_w1), make_initializer("enc_b1", enc_b1),
        make_initializer("enc_w2", enc_w2), make_initializer("enc_b2", enc_b2),
        make_initializer("dec_w1", dec_w1), make_initializer("dec_b1", dec_b1),
        make_initializer("dec_w2", dec_w2), make_initializer("dec_b2", dec_b2),
    ]
    build_and_save("full_models/autoencoder", "conv_autoencoder.onnx", [x], [y], nodes, inits,
                   "Convolutional autoencoder: Conv (encoder), ConvTranspose (decoder), Relu, Sigmoid")


# ---------------------------------------------------------------------------
# 6. Composite operator-family graphs (broad coverage for the converter)
# ---------------------------------------------------------------------------

def gen_ops_elementwise():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 8])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 8])
    c = const("c", (8,), 0.5, 1.5)

    nodes = [
        helper.make_node("Add", ["input", "c"], ["a"]),
        helper.make_node("Sub", ["a", "c"], ["s"]),
        helper.make_node("Mul", ["s", "c"], ["m"]),
        helper.make_node("Div", ["m", "c"], ["d"]),
        helper.make_node("Abs", ["d"], ["ab"]),
        helper.make_node("Pow", ["ab", "two"], ["p"]),
        helper.make_node("Sqrt", ["p"], ["sq"]),
        helper.make_node("Neg", ["sq"], ["n"]),
        helper.make_node("Exp", ["n"], ["e"]),
        helper.make_node("Log", ["e"], ["output"]),
    ]
    inits = [make_initializer("c", c), helper.make_tensor("two", TensorProto.FLOAT, [], [2.0])]
    build_and_save("operators/composite", "ops_elementwise.onnx", [x], [y], nodes, inits,
                   "Chain of elementwise operators: Add, Sub, Mul, Div, Abs, Pow, Sqrt, Neg, Exp, Log")


def gen_ops_shape():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 2, 4, 4])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 16, 2])

    nodes = [
        helper.make_node("Transpose", ["input"], ["t"], perm=[0, 2, 3, 1]),
        helper.make_node("Reshape", ["t", "shape1"], ["r"]),
        helper.make_node("Split", ["r", "split_sizes"], ["s1", "s2"], axis=2),
        helper.make_node("Concat", ["s1", "s2"], ["cat"], axis=2),
        helper.make_node("Unsqueeze", ["cat", "axis0"], ["u"]),
        helper.make_node("Squeeze", ["u", "axis0"], ["sq"]),
        helper.make_node("Slice", ["sq", "starts", "ends", "axes"], ["output"]),
    ]
    inits = [
        helper.make_tensor("shape1", TensorProto.INT64, [3], [1, 16, 2]),
        helper.make_tensor("split_sizes", TensorProto.INT64, [2], [1, 1]),
        helper.make_tensor("axis0", TensorProto.INT64, [1], [0]),
        helper.make_tensor("starts", TensorProto.INT64, [1], [0]),
        helper.make_tensor("ends", TensorProto.INT64, [1], [16]),
        helper.make_tensor("axes", TensorProto.INT64, [1], [1]),
    ]
    build_and_save("operators/composite", "ops_shape_manipulation.onnx", [x], [y], nodes, inits,
                   "Shape manipulation operators: Transpose, Reshape, Split, Concat, Unsqueeze, Squeeze, Slice")


def gen_ops_activation():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 8])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 8])
    prelu_slope = const("prelu_slope", (8,), 0.05, 0.2)

    nodes = [
        helper.make_node("LeakyRelu", ["input"], ["a1"], alpha=0.1),
        helper.make_node("PRelu", ["a1", "prelu_slope"], ["a2"]),
        helper.make_node("Elu", ["a2"], ["a3"], alpha=1.0),
        helper.make_node("Selu", ["a3"], ["a4"]),
        helper.make_node("Softplus", ["a4"], ["a5"]),
        helper.make_node("Softsign", ["a5"], ["a6"]),
        helper.make_node("HardSigmoid", ["a6"], ["a7"], alpha=0.2, beta=0.5),
        helper.make_node("Clip", ["a7", "cmin", "cmax"], ["output"]),
    ]
    inits = [make_initializer("prelu_slope", prelu_slope),
             helper.make_tensor("cmin", TensorProto.FLOAT, [], [-1.0]),
             helper.make_tensor("cmax", TensorProto.FLOAT, [], [1.0])]
    build_and_save("operators/composite", "ops_activations.onnx", [x], [y], nodes, inits,
                   "Overview of activation functions: LeakyRelu, PRelu, Elu, Selu, Softplus, Softsign, HardSigmoid, Clip")


def gen_ops_reduction():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 4, 6])
    y_mean = helper.make_tensor_value_info("out_mean", TensorProto.FLOAT, [1, 4, 1])
    y_argmax = helper.make_tensor_value_info("out_argmax", TensorProto.INT64, [1, 4, 1])
    y_topk = helper.make_tensor_value_info("out_topk_values", TensorProto.FLOAT, [1, 4, 3])

    nodes = [
        helper.make_node("ReduceMean", ["input"], ["out_mean"], axes=[-1], keepdims=1),
        helper.make_node("ReduceSum", ["input", "axes"], ["rsum"], keepdims=1),
        helper.make_node("ReduceMax", ["input"], ["rmax"], axes=[-1], keepdims=1),
        helper.make_node("ReduceMin", ["input"], ["rmin"], axes=[-1], keepdims=1),
        helper.make_node("ArgMax", ["input"], ["out_argmax"], axis=-1, keepdims=1),
        helper.make_node("TopK", ["input", "k"], ["out_topk_values", "out_topk_indices"], axis=-1),
    ]
    inits = [helper.make_tensor("k", TensorProto.INT64, [1], [3]),
             helper.make_tensor("axes", TensorProto.INT64, [1], [-1])]
    build_and_save("operators/composite", "ops_reduction.onnx", [x], [y_mean, y_argmax, y_topk], nodes, inits,
                   "Reduction operators: ReduceMean, ReduceSum, ReduceMax, ReduceMin, ArgMax, TopK")


def gen_ops_conditional():
    x = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 8])
    y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 8])

    nodes = [
        helper.make_node("Greater", ["input", "zero"], ["cond"]),
        helper.make_node("Where", ["cond", "input", "neg_input"], ["w"]),
        helper.make_node("Cast", ["w"], ["casted"], to=TensorProto.FLOAT),
        helper.make_node("Expand", ["casted", "target_shape"], ["exp"]),
        helper.make_node("Tile", ["exp", "repeats"], ["tiled"]),
        helper.make_node("Slice", ["tiled", "starts", "ends", "axes"], ["output"]),
    ]
    inits = [
        helper.make_tensor("zero", TensorProto.FLOAT, [], [0.0]),
        helper.make_tensor("target_shape", TensorProto.INT64, [2], [1, 8]),
        helper.make_tensor("repeats", TensorProto.INT64, [2], [1, 2]),
        helper.make_tensor("starts", TensorProto.INT64, [1], [0]),
        helper.make_tensor("ends", TensorProto.INT64, [1], [8]),
        helper.make_tensor("axes", TensorProto.INT64, [1], [1]),
    ]
    nodes.insert(1, helper.make_node("Neg", ["input"], ["neg_input"]))
    build_and_save("operators/composite", "ops_conditional_broadcast.onnx", [x], [y], nodes, inits,
                   "Conditional and broadcast operators: Greater, Where, Cast, Expand, Tile, Slice")


if __name__ == "__main__":
    gen_mlp_classifier()
    gen_mlp_residual()

    gen_cnn_basic()
    gen_cnn_residual()
    gen_cnn_inception()
    gen_cnn_depthwise()

    gen_rnn_lstm()
    gen_rnn_gru()

    gen_attention_block()

    gen_autoencoder()

    gen_ops_elementwise()
    gen_ops_shape()
    gen_ops_activation()
    gen_ops_reduction()
    gen_ops_conditional()

    print("\nDone.")
