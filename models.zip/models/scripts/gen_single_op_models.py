"""
Generator for "one operator per model" ONNX files.

Each file contains a single compute node (plus, where needed, the
initializers required for its weights/attributes). The goal is to be able
to unit-test the conversion of each operator by the Aidge framework,
independently of any full-model context.

Run:  python gen_single_op_models.py
"""
import os

import numpy as np
import onnx
from onnx import TensorProto, checker, helper

from _common import io_entry_from_value_info, write_json_metadata

MODELS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(MODELS_DIR, "operators", "single_op")
rng = np.random.default_rng(7)


def const(shape, low=-0.5, high=0.5):
    return rng.uniform(low, high, size=shape).astype(np.float32)


def tensor(name, arr, dtype=TensorProto.FLOAT):
    arr = np.asarray(arr)
    return helper.make_tensor(name, dtype, list(arr.shape), arr.flatten().tolist())


def build_single_op(op_type, filename, inputs, outputs, node_inputs, node_outputs,
                     initializers, doc, node_kwargs=None):
    node = helper.make_node(op_type, node_inputs, node_outputs, **(node_kwargs or {}))
    graph = helper.make_graph(
        [node], filename.replace(".onnx", ""), inputs, outputs, initializers,
        doc_string=doc,
    )
    model = helper.make_model(
        graph,
        producer_name="aidge-test-model-generator",
        opset_imports=[helper.make_opsetid("", 17)],
    )
    model.ir_version = 8
    checker.check_model(model)

    os.makedirs(OUT_DIR, exist_ok=True)
    out_path = os.path.join(OUT_DIR, filename)
    onnx.save(model, out_path)

    io_inputs = [io_entry_from_value_info(v, f"Graph input '{v.name}' consumed by the {op_type} operator.") for v in inputs]
    io_outputs = [io_entry_from_value_info(v, f"Graph output '{v.name}' produced by the {op_type} operator.") for v in outputs]
    write_json_metadata(out_path, doc, io_inputs, io_outputs)

    size_b = os.path.getsize(out_path)
    print(f"{filename:<28} {size_b:6d} B  - {doc}")


def vi(name, shape, dtype=TensorProto.FLOAT):
    return helper.make_tensor_value_info(name, dtype, shape)


# ---------------------------------------------------------------------------
# Binary elementwise operators: A, B (broadcast) -> C
# ---------------------------------------------------------------------------

def gen_binary_elementwise():
    b_val = const((8,), 0.5, 1.5)
    for op_type, doc in [
        ("Add", "Elementwise addition (broadcast)"),
        ("Sub", "Elementwise subtraction (broadcast)"),
        ("Mul", "Elementwise multiplication (broadcast)"),
        ("Div", "Elementwise division (broadcast)"),
        ("Pow", "Elementwise exponentiation (broadcast)"),
        ("Greater", "Elementwise comparison (broadcast)"),
    ]:
        out_dtype = TensorProto.BOOL if op_type == "Greater" else TensorProto.FLOAT
        x = vi("input", [1, 8])
        y = vi("output", [1, 8], out_dtype)
        build_single_op(
            op_type, f"{op_type.lower()}.onnx", [x], [y],
            ["input", "b"], ["output"], [tensor("b", b_val)], doc,
        )


# ---------------------------------------------------------------------------
# Unary elementwise operators: X -> Y
# ---------------------------------------------------------------------------

def gen_unary_elementwise():
    for op_type, doc in [
        ("Abs", "Elementwise absolute value"),
        ("Neg", "Elementwise negation"),
        ("Sqrt", "Elementwise square root"),
        ("Exp", "Elementwise exponential"),
        ("Log", "Elementwise natural logarithm"),
        ("Reciprocal", "Elementwise reciprocal (1/x)"),
        ("Erf", "Error function (used for GELU)"),
        ("Relu", "Rectified Linear Unit"),
        ("Sigmoid", "Sigmoid function"),
        ("Tanh", "Hyperbolic tangent"),
        ("Selu", "Scaled Exponential Linear Unit"),
        ("Softplus", "Softplus: log(1+exp(x))"),
        ("Softsign", "Softsign: x/(1+|x|)"),
        ("Identity", "Pass-through (identity)"),
    ]:
        x = vi("input", [1, 8])
        y = vi("output", [1, 8])
        build_single_op(op_type, f"{op_type.lower()}.onnx", [x], [y],
                         ["input"], ["output"], [], doc)


def gen_activation_with_attrs():
    x = vi("input", [1, 8])
    y = vi("output", [1, 8])
    build_single_op("LeakyRelu", "leakyrelu.onnx", [x], [y], ["input"], ["output"], [],
                     "Leaky ReLU (alpha attribute)", {"alpha": 0.1})
    build_single_op("Elu", "elu.onnx", [x], [y], ["input"], ["output"], [],
                     "Exponential Linear Unit (alpha attribute)", {"alpha": 1.0})
    build_single_op("HardSigmoid", "hardsigmoid.onnx", [x], [y], ["input"], ["output"], [],
                     "Piecewise-linear approximation of the sigmoid", {"alpha": 0.2, "beta": 0.5})

    slope = const((8,), 0.05, 0.2)
    build_single_op("PRelu", "prelu.onnx", [x], [y], ["input", "slope"], ["output"],
                     [tensor("slope", slope)], "Parametric ReLU (learned slope)")

    cmin = tensor("cmin", np.float32(-1.0))
    cmax = tensor("cmax", np.float32(1.0))
    build_single_op("Clip", "clip.onnx", [x], [y], ["input", "cmin", "cmax"], ["output"],
                     [cmin, cmax], "Value clamping within [min, max]")

    build_single_op("Softmax", "softmax.onnx", [x], [y], ["input"], ["output"], [],
                     "Exponential normalization (Softmax)", {"axis": -1})


# ---------------------------------------------------------------------------
# Convolution / pooling / normalization
# ---------------------------------------------------------------------------

def gen_conv_family():
    x = vi("input", [1, 4, 8, 8])

    w = const((8, 4, 3, 3))
    b = const((8,))
    y = vi("output", [1, 8, 8, 8])
    build_single_op("Conv", "conv.onnx", [x], [y], ["input", "w", "b"], ["output"],
                     [tensor("w", w), tensor("b", b)], "Standard 2D convolution",
                     {"kernel_shape": [3, 3], "pads": [1, 1, 1, 1]})

    wt = const((4, 8, 2, 2))
    bt = const((8,))
    yt = vi("output", [1, 8, 16, 16])
    build_single_op("ConvTranspose", "convtranspose.onnx", [x], [yt], ["input", "wt", "bt"], ["output"],
                     [tensor("wt", wt), tensor("bt", bt)], "Transposed convolution (upsampling)",
                     {"kernel_shape": [2, 2], "strides": [2, 2]})

    y_pool = vi("output", [1, 4, 4, 4])
    build_single_op("MaxPool", "maxpool.onnx", [x], [y_pool], ["input"], ["output"], [],
                     "2D max pooling", {"kernel_shape": [2, 2], "strides": [2, 2]})
    build_single_op("AveragePool", "averagepool.onnx", [x], [y_pool], ["input"], ["output"], [],
                     "2D average pooling", {"kernel_shape": [2, 2], "strides": [2, 2]})

    y_gap = vi("output", [1, 4, 1, 1])
    build_single_op("GlobalAveragePool", "globalaveragepool.onnx", [x], [y_gap], ["input"], ["output"], [],
                     "Global average over the spatial dimensions")

    scale = np.ones(4, dtype=np.float32)
    bias = np.zeros(4, dtype=np.float32)
    mean = np.zeros(4, dtype=np.float32)
    var = np.ones(4, dtype=np.float32)
    y_bn = vi("output", [1, 4, 8, 8])
    build_single_op("BatchNormalization", "batchnormalization.onnx", [x], [y_bn],
                     ["input", "scale", "bias", "mean", "var"], ["output"],
                     [tensor("scale", scale), tensor("bias", bias),
                      tensor("mean", mean), tensor("var", var)],
                     "Batch normalization (inference mode)")

    y_flat = vi("output", [1, 256])
    build_single_op("Flatten", "flatten.onnx", [x], [y_flat], ["input"], ["output"], [],
                     "Flattening to 2D", {"axis": 1})


# ---------------------------------------------------------------------------
# Linear algebra
# ---------------------------------------------------------------------------

def gen_linear_algebra():
    x = vi("input", [1, 16])
    w = const((16, 10))
    b = const((10,))
    y = vi("output", [1, 10])
    build_single_op("Gemm", "gemm.onnx", [x], [y], ["input", "w", "b"], ["output"],
                     [tensor("w", w), tensor("b", b)], "Generalized matrix multiplication (dense layer)")

    build_single_op("MatMul", "matmul.onnx", [x], [y], ["input", "w"], ["output"],
                     [tensor("w", w)], "Plain matrix multiplication")


# ---------------------------------------------------------------------------
# Shape manipulation
# ---------------------------------------------------------------------------

def gen_shape_ops():
    x = vi("input", [1, 2, 4, 4])

    build_single_op("Transpose", "transpose.onnx", [x], [vi("output", [1, 4, 4, 2])],
                     ["input"], ["output"], [], "Axis permutation", {"perm": [0, 2, 3, 1]})

    build_single_op("Reshape", "reshape.onnx", [x], [vi("output", [1, 32])],
                     ["input", "shape"], ["output"], [tensor("shape", np.array([1, 32]), TensorProto.INT64)],
                     "Shape change without data copy")

    build_single_op("Squeeze", "squeeze.onnx", [vi("input", [1, 1, 8])], [vi("output", [1, 8])],
                     ["input", "axes"], ["output"], [tensor("axes", np.array([1]), TensorProto.INT64)],
                     "Removal of a size-1 dimension")

    build_single_op("Unsqueeze", "unsqueeze.onnx", [vi("input", [1, 8])], [vi("output", [1, 1, 8])],
                     ["input", "axes"], ["output"], [tensor("axes", np.array([1]), TensorProto.INT64)],
                     "Insertion of a size-1 dimension")

    build_single_op("Concat", "concat.onnx", [vi("input", [1, 4]), vi("input2", [1, 4])],
                     [vi("output", [1, 8])], ["input", "input2"], ["output"], [],
                     "Concatenation of two tensors", {"axis": 1})

    build_single_op("Split", "split.onnx", [vi("input", [1, 8])],
                     [vi("output", [1, 4]), vi("output2", [1, 4])],
                     ["input"], ["output", "output2"], [], "Splitting a tensor into several",
                     {"axis": 1})

    build_single_op("Slice", "slice.onnx", [vi("input", [1, 8])], [vi("output", [1, 4])],
                     ["input", "starts", "ends", "axes"], ["output"],
                     [tensor("starts", np.array([0]), TensorProto.INT64),
                      tensor("ends", np.array([4]), TensorProto.INT64),
                      tensor("axes", np.array([1]), TensorProto.INT64)],
                     "Extraction of a sub-region of a tensor")

    build_single_op("Gather", "gather.onnx", [vi("input", [8])], [vi("output", [3])],
                     ["input", "indices"], ["output"],
                     [tensor("indices", np.array([0, 2, 5]), TensorProto.INT64)],
                     "Advanced indexing (lookup) along an axis", {"axis": 0})

    build_single_op("Expand", "expand.onnx", [vi("input", [1, 1])], [vi("output", [1, 8])],
                     ["input", "shape"], ["output"], [tensor("shape", np.array([1, 8]), TensorProto.INT64)],
                     "Explicit broadcast to a target shape")

    build_single_op("Tile", "tile.onnx", [vi("input", [1, 4])], [vi("output", [1, 8])],
                     ["input", "repeats"], ["output"], [tensor("repeats", np.array([1, 2]), TensorProto.INT64)],
                     "Repetition of a tensor along each axis")

    build_single_op("Pad", "pad.onnx", [vi("input", [1, 4])], [vi("output", [1, 6])],
                     ["input", "pads"], ["output"], [tensor("pads", np.array([0, 1, 0, 1]), TensorProto.INT64)],
                     "Constant padding around a tensor")


# ---------------------------------------------------------------------------
# Reductions
# ---------------------------------------------------------------------------

def gen_reduction_ops():
    x = vi("input", [1, 4, 6])
    axes = tensor("axes", np.array([-1]), TensorProto.INT64)
    y = vi("output", [1, 4, 1])

    # ReduceSum takes "axes" as an input since opset 13.
    build_single_op("ReduceSum", "reducesum.onnx", [x], [y],
                     ["input", "axes"], ["output"], [axes],
                     "Sum along an axis", {"keepdims": 1})

    # ReduceMean/Max/Min still use the "axes" attribute at opset 17.
    for op_type, doc in [
        ("ReduceMean", "Mean along an axis"),
        ("ReduceMax", "Maximum along an axis"),
        ("ReduceMin", "Minimum along an axis"),
    ]:
        build_single_op(op_type, f"{op_type.lower()}.onnx", [x], [y],
                         ["input"], ["output"], [], doc, {"axes": [-1], "keepdims": 1})

    y_argmax = vi("output", [1, 4, 1], TensorProto.INT64)
    build_single_op("ArgMax", "argmax.onnx", [x], [y_argmax], ["input"], ["output"], [],
                     "Index of the maximum value along an axis", {"axis": -1, "keepdims": 1})

    k = tensor("k", np.array([3]), TensorProto.INT64)
    build_single_op("TopK", "topk.onnx", [x],
                     [vi("output", [1, 4, 3]), vi("output_indices", [1, 4, 3], TensorProto.INT64)],
                     ["input", "k"], ["output", "output_indices"], [k],
                     "Extraction of the K largest values along an axis", {"axis": -1})


# ---------------------------------------------------------------------------
# Misc (conditional, cast, recurrent)
# ---------------------------------------------------------------------------

def gen_misc_ops():
    cond = vi("cond", [1, 8], TensorProto.BOOL)
    a = vi("a", [1, 8])
    b = vi("b", [1, 8])
    y = vi("output", [1, 8])
    build_single_op("Where", "where.onnx", [cond, a, b], [y], ["cond", "a", "b"], ["output"], [],
                     "Elementwise conditional selection")

    x = vi("input", [1, 8])
    y_int = vi("output", [1, 8], TensorProto.INT64)
    build_single_op("Cast", "cast.onnx", [x], [y_int], ["input"], ["output"], [],
                     "Data type conversion", {"to": TensorProto.INT64})

    seq_len, batch, input_size, hidden_size = 5, 1, 8, 16
    xr = vi("input", [seq_len, batch, input_size])
    w = const((1, 4 * hidden_size, input_size))
    r = const((1, 4 * hidden_size, hidden_size))
    bias = const((1, 8 * hidden_size))
    y_all = vi("output", [seq_len, 1, batch, hidden_size])
    build_single_op("LSTM", "lstm.onnx", [xr], [y_all], ["input", "W", "R", "B"], ["output"],
                     [tensor("W", w), tensor("R", r), tensor("B", bias)],
                     "Recurrent LSTM cell (single layer)", {"hidden_size": hidden_size})

    hidden_size_gru = 12
    w_gru = const((1, 3 * hidden_size_gru, input_size))
    r_gru = const((1, 3 * hidden_size_gru, hidden_size_gru))
    b_gru = const((1, 6 * hidden_size_gru))
    y_gru = vi("output", [seq_len, 1, batch, hidden_size_gru])
    build_single_op("GRU", "gru.onnx", [xr], [y_gru], ["input", "W", "R", "B"], ["output"],
                     [tensor("W", w_gru), tensor("R", r_gru), tensor("B", b_gru)],
                     "Recurrent GRU cell (single layer)", {"hidden_size": hidden_size_gru})


if __name__ == "__main__":
    gen_binary_elementwise()
    gen_unary_elementwise()
    gen_activation_with_attrs()
    gen_conv_family()
    gen_linear_algebra()
    gen_shape_ops()
    gen_reduction_ops()
    gen_misc_ops()
    print("\nDone.")
