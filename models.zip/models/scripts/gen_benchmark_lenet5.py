"""
Generator for a faithful LeNet-5 (LeCun et al., 1998, "Gradient-Based
Learning Applied to Document Recognition"), trained on the real MNIST
dataset. This is the classic literature reference architecture, distinct
from the compact custom CNN in `gen_mnist_model.py`: same task, but the
original -- larger -- topology, useful as a size/accuracy reference point
and as a well-known target for testing an ONNX converter.

Original topology (adapted to a modern softmax output instead of the
paper's RBF output layer, and ReLU instead of the paper's scaled-tanh --
both extremely common, well documented modernizations):
  Input 32x32x1 (MNIST's 28x28 zero-padded by 2px on each side)
  -> C1: Conv 6@5x5              -> S2: AvgPool 2x2
  -> C3: Conv 16@5x5             -> S4: AvgPool 2x2
  -> C5: Conv 120@5x5 (-> 1x1, acts as a dense layer)
  -> F6: Dense 84
  -> Output: Dense 10 -> Softmax

~61.7k parameters, ~240 KB in float32 -- comfortably over the "under
100 KB" soft budget used elsewhere in this folder, which is the point:
`scripts/gen_benchmark_quantize.py` produces an int8 QDQ version of this
model that fits well under it.

Requires:  pip install torch torchvision
Run:       python gen_benchmark_lenet5.py
"""
import os
import tempfile

import onnx
import torch
import torch.nn as nn
import torchvision

from _common import io_entry, simplify_onnx_model, write_json_metadata

MODELS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATEGORY = "benchmarks"
DATA_DIR = os.path.join(tempfile.gettempdir(), "aidge_mnist_data")

torch.manual_seed(0)


class LeNet5(nn.Module):
    def __init__(self):
        super().__init__()
        self.c1 = nn.Conv2d(1, 6, kernel_size=5)
        self.s2 = nn.AvgPool2d(2)
        self.c3 = nn.Conv2d(6, 16, kernel_size=5)
        self.s4 = nn.AvgPool2d(2)
        self.c5 = nn.Conv2d(16, 120, kernel_size=5)
        self.f6 = nn.Linear(120, 84)
        self.out = nn.Linear(84, 10)

    def forward(self, x):  # x: (N, 1, 32, 32), already in [0, 1]
        h = self.s2(torch.relu(self.c1(x)))
        h = self.s4(torch.relu(self.c3(h)))
        h = torch.relu(self.c5(h))  # (N, 120, 1, 1)
        h = h.flatten(1)
        h = torch.relu(self.f6(h))
        return self.out(h)  # logits


class ExportWrapper(nn.Module):
    """Pads 28x28 to 32x32, normalizes [0,255] -> [0,1], and adds Softmax --
    all inside the exported graph, so raw MNIST pixel values go straight in.
    """

    def __init__(self, base):
        super().__init__()
        self.base = base
        self.pad = nn.ConstantPad2d(2, 0.0)

    def forward(self, x):  # x: (N, 1, 28, 28), raw [0, 255]
        x = self.pad(x)
        x = x / 255.0
        return torch.softmax(self.base(x), dim=1)


def load_mnist():
    train_ds = torchvision.datasets.MNIST(root=DATA_DIR, train=True, download=True)
    test_ds = torchvision.datasets.MNIST(root=DATA_DIR, train=False, download=True)
    x_train = train_ds.data.float().unsqueeze(1)
    y_train = train_ds.targets.long()
    x_test = test_ds.data.float().unsqueeze(1)
    y_test = test_ds.targets.long()
    return x_train, y_train, x_test, y_test


def preprocess(x):
    return torch.nn.functional.pad(x, (2, 2, 2, 2)) / 255.0


def evaluate(model, x, y, batch_size=1000):
    model.eval()
    correct = 0
    with torch.no_grad():
        for i in range(0, x.shape[0], batch_size):
            logits = model(preprocess(x[i:i + batch_size]))
            correct += (logits.argmax(dim=1) == y[i:i + batch_size]).sum().item()
    model.train()
    return correct / x.shape[0]


def train(model, x_train, y_train, x_test, y_test, epochs=5, batch_size=128, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n = x_train.shape[0]

    model.train()
    for epoch in range(epochs):
        perm = torch.randperm(n)
        total_loss = 0.0
        for i in range(0, n, batch_size):
            idx = perm[i:i + batch_size]
            xb, yb = preprocess(x_train[idx]), y_train[idx]
            optimizer.zero_grad()
            loss = loss_fn(model(xb), yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(idx)
        test_acc = evaluate(model, x_test, y_test)
        print(f"epoch {epoch + 1}/{epochs}  train_loss={total_loss / n:.4f}  test_acc={test_acc:.4f}")

    return evaluate(model, x_test, y_test)


def export_model(model, test_acc, example_image, example_label):
    wrapper = ExportWrapper(model)
    wrapper.eval()

    out_dir = os.path.join(MODELS_DIR, CATEGORY)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "lenet5_mnist.onnx")

    dummy = torch.zeros((1, 1, 28, 28), dtype=torch.float32)
    torch.onnx.export(
        wrapper, dummy, out_path,
        input_names=["input"], output_names=["output"],
        opset_version=17, dynamo=False, external_data=False,
    )

    doc = (
        f"LeNet-5 (LeCun et al., 1998), the classic literature reference CNN, faithfully "
        f"reproduced (Conv6-AvgPool-Conv16-AvgPool-Conv120-FC84-FC10, ReLU + Softmax output "
        f"instead of the original scaled-tanh + RBF) and trained with PyTorch on the real "
        f"MNIST training set (60000 images). Test accuracy={test_acc:.4f} on the official "
        f"10000-image test set. ~61.7k parameters, ~240 KB float32 -- see "
        f"lenet5_mnist_int8.onnx for a quantized version under 100 KB."
    )
    onnx_model = onnx.load(out_path)
    onnx_model = simplify_onnx_model(onnx_model)
    onnx_model.graph.doc_string = doc
    onnx_model.producer_name = "aidge-test-model-generator"
    onnx.checker.check_model(onnx_model)
    onnx.save(onnx_model, out_path)

    with torch.no_grad():
        example_out = wrapper(example_image).numpy()

    io_inputs = [io_entry(
        "input", [1, 1, 28, 28], "float32",
        "A single grayscale 28x28 handwritten digit image, raw pixel values in [0, 255] "
        "(float32), layout (batch, channel, height, width). Zero-padding to 32x32 and /255 "
        "normalization both happen inside the graph (Pad, Div nodes).",
        example=example_image.numpy(),
    )]
    io_outputs = [io_entry(
        "output", [1, 10], "float32",
        f"Softmax probabilities over the 10 digit classes (index = digit 0-9). "
        f"Predicted digit = argmax. (Example input above is a real test-set '{example_label}'.)",
        example=example_out,
    )]
    write_json_metadata(out_path, doc, io_inputs, io_outputs)

    size_kb = os.path.getsize(out_path) / 1024
    print(f"[{CATEGORY}] lenet5_mnist.onnx  {size_kb:.1f} KB  - {doc}")


if __name__ == "__main__":
    x_train, y_train, x_test, y_test = load_mnist()
    print(f"MNIST loaded: {x_train.shape[0]} train / {x_test.shape[0]} test images")

    model = LeNet5()
    test_acc = train(model, x_train, y_train, x_test, y_test, epochs=5)

    example_idx = int((y_test == 3).nonzero()[0].item())
    export_model(model, test_acc, x_test[example_idx:example_idx + 1], y_test[example_idx].item())

    print("\nDone.")
