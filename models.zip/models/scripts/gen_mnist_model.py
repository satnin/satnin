"""
Generator for a real, actually-trained MNIST digit classifier, input shape
(1, 1, 28, 28) -- the classic small benchmark used to sanity-check an ONNX
converter end to end (real dataset, real training, real accuracy), as
opposed to the domain-specific `real_world/` models or the structural,
random-weight models elsewhere in this folder.

Downloads the real MNIST dataset via torchvision (cached outside the repo,
under the system temp directory) and trains a small LeNet-style CNN with
PyTorch, then exports it to ONNX with `torch.onnx.export`.

Requires:  pip install torch torchvision
Run:       python gen_mnist_model.py
"""
import os
import tempfile

import numpy as np
import onnx
import torch
import torch.nn as nn
import torchvision

from _common import io_entry, simplify_onnx_model, write_json_metadata

MODELS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATEGORY = "benchmarks"
DATA_DIR = os.path.join(tempfile.gettempdir(), "aidge_mnist_data")

torch.manual_seed(0)


class MNISTCNN(nn.Module):
    """LeNet-style CNN: Conv/Relu/MaxPool x2, then a small dense head.
    Operates on inputs already normalized to [0, 1] (see `ExportWrapper`,
    which does that normalization inside the exported graph).
    """

    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=5, padding=2)
        self.pool1 = nn.MaxPool2d(2)
        self.conv2 = nn.Conv2d(8, 8, kernel_size=5, padding=2)
        self.pool2 = nn.MaxPool2d(2)
        self.fc1 = nn.Linear(8 * 7 * 7, 32)
        self.fc2 = nn.Linear(32, 10)

    def forward(self, x):  # x: (N, 1, 28, 28), already in [0, 1]
        h = self.pool1(torch.relu(self.conv1(x)))
        h = self.pool2(torch.relu(self.conv2(h)))
        h = h.flatten(1)
        h = torch.relu(self.fc1(h))
        return self.fc2(h)  # logits


class ExportWrapper(nn.Module):
    """Wraps the trained model so the exported ONNX graph accepts raw
    [0, 255] pixel values directly (the /255 normalization becomes a Div
    node in the graph) and outputs class probabilities (Softmax node).
    """

    def __init__(self, base):
        super().__init__()
        self.base = base

    def forward(self, x):
        x = x / 255.0
        return torch.softmax(self.base(x), dim=1)


def load_mnist():
    train_ds = torchvision.datasets.MNIST(root=DATA_DIR, train=True, download=True)
    test_ds = torchvision.datasets.MNIST(root=DATA_DIR, train=False, download=True)

    x_train = train_ds.data.float().unsqueeze(1)  # (60000, 1, 28, 28), 0-255
    y_train = train_ds.targets.long()
    x_test = test_ds.data.float().unsqueeze(1)     # (10000, 1, 28, 28), 0-255
    y_test = test_ds.targets.long()
    return x_train, y_train, x_test, y_test


def train(model, x_train, y_train, x_test, y_test, epochs=3, batch_size=128, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n = x_train.shape[0]

    model.train()
    for epoch in range(epochs):
        perm = torch.randperm(n)
        total_loss = 0.0
        for i in range(0, n, batch_size):
            idx = perm[i:i + batch_size]
            xb, yb = x_train[idx] / 255.0, y_train[idx]
            optimizer.zero_grad()
            logits = model(xb)
            loss = loss_fn(logits, yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(idx)
        train_loss = total_loss / n
        test_acc = evaluate(model, x_test, y_test)
        print(f"epoch {epoch + 1}/{epochs}  train_loss={train_loss:.4f}  test_acc={test_acc:.4f}")

    return evaluate(model, x_test, y_test)


def evaluate(model, x, y, batch_size=1000):
    model.eval()
    correct = 0
    with torch.no_grad():
        for i in range(0, x.shape[0], batch_size):
            logits = model(x[i:i + batch_size] / 255.0)
            correct += (logits.argmax(dim=1) == y[i:i + batch_size]).sum().item()
    model.train()
    return correct / x.shape[0]


def export_mnist_model(model, test_acc, example_image, example_label):
    wrapper = ExportWrapper(model)
    wrapper.eval()

    out_dir = os.path.join(MODELS_DIR, CATEGORY)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "mnist_cnn.onnx")

    dummy = torch.zeros((1, 1, 28, 28), dtype=torch.float32)
    torch.onnx.export(
        wrapper, dummy, out_path,
        input_names=["input"], output_names=["output"],
        opset_version=17, dynamo=False, external_data=False,
    )

    doc = (
        f"MNIST handwritten-digit classifier. Real LeNet-style CNN "
        f"(Conv8-Pool-Conv8-Pool-FC32-FC10) trained with PyTorch on the real "
        f"MNIST training set (60000 images), test accuracy={test_acc:.4f} on the "
        f"official 10000-image test set."
    )
    onnx_model = onnx.load(out_path)
    onnx_model = simplify_onnx_model(onnx_model)
    onnx_model.graph.doc_string = doc
    onnx_model.producer_name = "aidge-test-model-generator"
    onnx.checker.check_model(onnx_model)
    onnx.save(onnx_model, out_path)

    with torch.no_grad():
        example_out = wrapper(example_image).numpy()

    io_inputs = [io_entry(
        "input", [1, 1, 28, 28], "float32",
        "A single grayscale 28x28 handwritten digit image, raw pixel values in "
        "[0, 255] (float32), layout (batch, channel, height, width). The /255 "
        "normalization is done inside the graph (Div node), so no external "
        "preprocessing is needed beyond feeding the raw pixel values.",
        example=example_image.numpy(),
    )]
    io_outputs = [io_entry(
        "output", [1, 10], "float32",
        f"Softmax probabilities over the 10 digit classes (index = digit 0-9). "
        f"Predicted digit = argmax. (Example input above is a real test-set "
        f"'{example_label}'.)",
        example=example_out,
    )]
    write_json_metadata(out_path, doc, io_inputs, io_outputs)

    size_kb = os.path.getsize(out_path) / 1024
    print(f"[{CATEGORY}] mnist_cnn.onnx  {size_kb:.1f} KB  - {doc}")


if __name__ == "__main__":
    x_train, y_train, x_test, y_test = load_mnist()
    print(f"MNIST loaded: {x_train.shape[0]} train / {x_test.shape[0]} test images")

    model = MNISTCNN()
    test_acc = train(model, x_train, y_train, x_test, y_test, epochs=3)

    example_idx = int((y_test == 7).nonzero()[0].item())  # a real "7" from the test set
    example_image = x_test[example_idx:example_idx + 1]
    example_label = y_test[example_idx].item()

    export_mnist_model(model, test_acc, example_image, example_label)

    print("\nDone.")
