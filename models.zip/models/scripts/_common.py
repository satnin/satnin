"""
Shared helpers for the ONNX model generator scripts in this folder.

Every generator writes, next to each `<model>.onnx` file, a `<model>.json`
sidecar describing its inputs and outputs (name, shape, dtype, a human
-readable description, and a concrete example value), so a converter or a
reader can know what a tensor means -- and see a valid value for it --
without opening the graph in a viewer or writing test code.
"""
import json
import os
import zlib

import numpy as np
from onnx import TensorProto

_DTYPE_NAMES = {
    TensorProto.FLOAT: "float32",
    TensorProto.DOUBLE: "float64",
    TensorProto.INT64: "int64",
    TensorProto.INT32: "int32",
    TensorProto.INT8: "int8",
    TensorProto.UINT8: "uint8",
    TensorProto.BOOL: "bool",
}
_NAME_TO_DTYPE = {v: k for k, v in _DTYPE_NAMES.items()}


def dtype_name(dtype):
    """Return a readable dtype string from an onnx.TensorProto enum value (or pass through a string)."""
    if isinstance(dtype, str):
        return dtype
    return _DTYPE_NAMES.get(dtype, str(dtype))


def _stable_seed(name):
    """Deterministic per-tensor-name seed, stable across regenerations (unlike Python's hash())."""
    return zlib.crc32(name.encode("utf-8"))


def random_example(name, shape, dtype):
    """Generate a small, deterministic, dtype-appropriate example array for
    a tensor -- used when no real value is available (structural/operator
    -coverage models). Same `name` + `shape` + `dtype` always yields the
    same example, so regenerating a model doesn't needlessly change its
    sidecar.
    """
    onnx_dtype = _NAME_TO_DTYPE.get(dtype, dtype) if isinstance(dtype, str) else dtype
    shape = [d if isinstance(d, int) and d > 0 else 1 for d in shape]
    rng = np.random.default_rng(_stable_seed(name))

    if onnx_dtype == TensorProto.BOOL:
        arr = rng.integers(0, 2, size=shape).astype(bool)
    elif onnx_dtype == TensorProto.INT64:
        arr = rng.integers(-4, 5, size=shape).astype(np.int64)
    elif onnx_dtype == TensorProto.INT32:
        arr = rng.integers(-1000, 1000, size=shape).astype(np.int32)
    elif onnx_dtype == TensorProto.INT8:
        arr = rng.integers(-128, 127, size=shape, endpoint=True).astype(np.int8)
    elif onnx_dtype == TensorProto.UINT8:
        arr = rng.integers(0, 255, size=shape, endpoint=True).astype(np.uint8)
    else:
        arr = rng.uniform(-1.0, 1.0, size=shape).astype(np.float32)
    return arr.tolist()


def io_entry(name, shape, dtype, description, example=None):
    """Build one `inputs`/`outputs` JSON entry.

    `example` may be a numpy array / nested list matching `shape`; if
    omitted, a deterministic dtype-appropriate example is generated.
    """
    if example is None:
        example = random_example(name, shape, dtype)
    else:
        example = np.asarray(example).tolist()
    return {
        "name": name,
        "shape": list(shape),
        "dtype": dtype_name(dtype),
        "description": description,
        "example": example,
    }


def shape_from_value_info(value_info):
    dims = value_info.type.tensor_type.shape.dim
    shape = []
    for d in dims:
        shape.append(d.dim_value if d.HasField("dim_value") else (d.dim_param or "?"))
    return shape


def dtype_from_value_info(value_info):
    return value_info.type.tensor_type.elem_type


def io_entry_from_value_info(value_info, description, example=None):
    return io_entry(value_info.name, shape_from_value_info(value_info),
                     dtype_from_value_info(value_info), description, example=example)


def simplify_onnx_model(onnx_model):
    """Run onnx-simplifier (constant folding + dead-node elimination) on a
    freshly `torch.onnx.export`-ed model. PyTorch's exporter often emits a
    verbose dynamic-shape preamble (Constant/Slice/Transpose/Reshape/Cast...)
    for ops with a statically-known configuration (e.g. constant padding);
    onnxsim folds that away, leaving just the semantically meaningful nodes.
    Falls back to returning the model unchanged if onnxsim isn't installed
    or fails on this graph (never fatal -- the unsimplified graph is still
    correct, just more verbose).
    """
    try:
        from onnxsim import simplify
    except ImportError:
        return onnx_model
    try:
        simplified, ok = simplify(onnx_model)
        return simplified if ok else onnx_model
    except Exception:
        return onnx_model


def write_json_metadata(onnx_path, description, inputs, outputs):
    """Write a `<model>.json` sidecar next to `onnx_path`.

    `inputs` / `outputs` are lists built with `io_entry(...)`.
    """
    metadata = {
        "model": os.path.basename(onnx_path),
        "description": description,
        "inputs": inputs,
        "outputs": outputs,
    }
    json_path = os.path.splitext(onnx_path)[0] + ".json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
        f.write("\n")
