"""
Generator for two classic keyword-spotting (KWS) literature architectures,
trained on the real Google Speech Commands dataset (v0.02) via `torchaudio`:

- DS-CNN-S: the "small" Depthwise-Separable CNN from Zhang, Suda, Lai &
  Chandra, "Hello Edge: Keyword Spotting on Microcontrollers" (2018,
  https://arxiv.org/abs/1711.07128). Architecture reproduced from the
  paper's description (initial standard conv, 4 depthwise-separable
  conv/BN/ReLU blocks, global average pool, dense+softmax) and sized to
  match the paper's ~24k-parameter "S" configuration -- an approximate
  reproduction (exact per-layer hyperparameters in the paper's appendix
  aren't guaranteed bit-for-bit here), not an official checkpoint.
- TinyConv: the minimal reference model from TensorFlow Lite for
  Microcontrollers' `micro_speech` example (a single Conv2D + dense layer,
  ~1500x smaller than DS-CNN-S) -- the simplest possible KWS baseline.

Both consume the same 12-class task (10 target words + "_silence_" +
"_unknown_", the standard Hello Edge setup): "yes, no, up, down, left,
right, on, off, stop, go" plus silence (background noise clips) and
unknown (a sample of the dataset's other words).

Requires:  pip install torch torchaudio
Run:       python gen_benchmark_kws.py   (downloads ~2.4 GB on first run)
"""
import os
import random
import tarfile
import tempfile
import urllib.request
import wave

import numpy as np
import onnx
import torch
import torch.nn as nn
import torchaudio

from _common import io_entry, simplify_onnx_model, write_json_metadata

MODELS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATEGORY = "benchmarks"
DATA_DIR = os.path.join(tempfile.gettempdir(), "aidge_speech_commands")
DATA_URL = "https://storage.googleapis.com/download.tensorflow.org/data/speech_commands_v0.02.tar.gz"
DATA_ROOT = os.path.join(DATA_DIR, "speech_commands_v0.02")

torch.manual_seed(0)

TARGET_WORDS = ["yes", "no", "up", "down", "left", "right", "on", "off", "stop", "go"]
CLASSES = TARGET_WORDS + ["_silence_", "_unknown_"]  # 12 classes, Hello Edge-style
SAMPLE_RATE = 16000
CLIP_SAMPLES = SAMPLE_RATE  # 1 second
MAX_PER_TARGET_WORD = 260
MAX_UNKNOWN = 320
MAX_SILENCE = 320


# ---------------------------------------------------------------------------
# Data loading: real WAV files read directly with the stdlib `wave` module
# (bypassing `torchaudio.load`, which on this system requires an FFmpeg
# -backed `torchcodec` install we don't have) -- fixed-length 1s waveforms
# + integer labels, following the dataset's own train/val/test split files.
# ---------------------------------------------------------------------------

def ensure_speech_commands_downloaded():
    if os.path.isdir(DATA_ROOT):
        return
    os.makedirs(DATA_DIR, exist_ok=True)
    archive = os.path.join(DATA_DIR, "speech_commands_v0.02.tar.gz")
    if not os.path.exists(archive):
        print(f"Downloading Speech Commands v0.02 (~2.4 GB) to {archive} ...")
        urllib.request.urlretrieve(DATA_URL, archive)
    print("Extracting Speech Commands archive...")
    os.makedirs(DATA_ROOT, exist_ok=True)
    with tarfile.open(archive) as tar:
        tar.extractall(DATA_ROOT)


def read_wav(path):
    with wave.open(path, "rb") as w:
        assert w.getsampwidth() == 2 and w.getframerate() == SAMPLE_RATE, path
        raw = w.readframes(w.getnframes())
    audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    return torch.from_numpy(audio).unsqueeze(0)  # (1, n_samples)


def _fixed_length(waveform):
    n = waveform.shape[-1]
    if n >= CLIP_SAMPLES:
        return waveform[..., :CLIP_SAMPLES]
    return torch.nn.functional.pad(waveform, (0, CLIP_SAMPLES - n))


def _split_membership():
    with open(os.path.join(DATA_ROOT, "testing_list.txt")) as f:
        testing = set(line.strip().replace("\\", "/") for line in f if line.strip())
    with open(os.path.join(DATA_ROOT, "validation_list.txt")) as f:
        validation = set(line.strip().replace("\\", "/") for line in f if line.strip())
    return testing, validation


def _list_word_files(subset):
    testing, validation = _split_membership()
    by_word = {}
    for word in sorted(os.listdir(DATA_ROOT)):
        word_dir = os.path.join(DATA_ROOT, word)
        if not os.path.isdir(word_dir) or word.startswith("_"):
            continue
        files = []
        for fname in sorted(os.listdir(word_dir)):
            if not fname.endswith(".wav"):
                continue
            rel = f"{word}/{fname}"
            in_test, in_val = rel in testing, rel in validation
            if subset == "testing" and not in_test:
                continue
            if subset == "validation" and not in_val:
                continue
            if subset == "training" and (in_test or in_val):
                continue
            files.append(os.path.join(word_dir, fname))
        by_word[word] = files
    return by_word


def _list_background_noise():
    bg_dir = os.path.join(DATA_ROOT, "_background_noise_")
    return [os.path.join(bg_dir, f) for f in sorted(os.listdir(bg_dir)) if f.endswith(".wav")]


def build_split(subset, max_per_word, max_unknown, max_silence, seed):
    rng = random.Random(seed)
    by_word = _list_word_files(subset)

    target_paths = {w: by_word.get(w, [])[:] for w in TARGET_WORDS}
    for w in target_paths:
        rng.shuffle(target_paths[w])
        target_paths[w] = target_paths[w][:max_per_word]

    unknown_paths = []
    for word, files in by_word.items():
        if word not in TARGET_WORDS:
            unknown_paths.extend(files)
    rng.shuffle(unknown_paths)
    unknown_paths = unknown_paths[:max_unknown]

    noise_paths = _list_background_noise()

    clips, labels = [], []
    for label_idx, w in enumerate(TARGET_WORDS):
        for path in target_paths[w]:
            clips.append(_fixed_length(read_wav(path)))
            labels.append(label_idx)

    silence_idx = CLASSES.index("_silence_")
    for i in range(max_silence):
        waveform = read_wav(noise_paths[i % len(noise_paths)])
        n = waveform.shape[-1]
        start = rng.randint(0, max(n - CLIP_SAMPLES, 0))
        clips.append(_fixed_length(waveform[..., start:start + CLIP_SAMPLES]))
        labels.append(silence_idx)

    unknown_idx = CLASSES.index("_unknown_")
    for path in unknown_paths:
        clips.append(_fixed_length(read_wav(path)))
        labels.append(unknown_idx)

    x = torch.cat(clips, dim=0).unsqueeze(1)  # (N, 1, CLIP_SAMPLES)
    y = torch.tensor(labels, dtype=torch.long)
    return x, y


def load_speech_commands():
    ensure_speech_commands_downloaded()
    x_train, y_train = build_split("training", MAX_PER_TARGET_WORD, MAX_UNKNOWN, MAX_SILENCE, seed=0)
    x_test, y_test = build_split("testing", 40, 60, 60, seed=1)
    return x_train, y_train, x_test, y_test


# ---------------------------------------------------------------------------
# Feature front ends (not part of the exported graph -- see each model's
# doc string: these models expect pre-computed features as input, matching
# how such models are actually deployed: a fixed-point DSP feature
# extraction stage feeds the neural net)
# ---------------------------------------------------------------------------

mfcc_transform = torchaudio.transforms.MFCC(
    sample_rate=SAMPLE_RATE, n_mfcc=10,
    melkwargs=dict(n_fft=480, hop_length=320, n_mels=40, center=False),
)  # -> (..., 10, 49)

mel_transform = torchaudio.transforms.MelSpectrogram(
    sample_rate=SAMPLE_RATE, n_fft=480, hop_length=320, n_mels=40, center=False,
)  # -> (..., 40, 49)


def mfcc_features(waveform):
    feat = mfcc_transform(waveform)  # (N, 1, 10, 49)
    return feat.transpose(-1, -2)  # (N, 1, 49, 10) time x mfcc


def log_mel_features(waveform):
    feat = mel_transform(waveform)  # (N, 1, 40, 49)
    feat = torch.log(feat.clamp_min(1e-6))
    return feat.transpose(-1, -2)  # (N, 1, 49, 40) time x mel


# ---------------------------------------------------------------------------
# DS-CNN-S (Zhang et al., 2018)
# ---------------------------------------------------------------------------

class DepthwiseSeparableBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.dw = nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.bn1 = nn.BatchNorm2d(channels)
        self.pw = nn.Conv2d(channels, channels, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(channels)

    def forward(self, x):
        h = torch.relu(self.bn1(self.dw(x)))
        return torch.relu(self.bn2(self.pw(h)))


class DSCNN_S(nn.Module):
    def __init__(self, num_classes=12, channels=64):
        super().__init__()
        self.conv1 = nn.Conv2d(1, channels, (10, 4), stride=(2, 2), padding=(4, 1), bias=False)
        self.bn1 = nn.BatchNorm2d(channels)
        self.blocks = nn.Sequential(*[DepthwiseSeparableBlock(channels) for _ in range(4)])
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(channels, num_classes)

    def forward(self, x):  # x: (N, 1, 49, 10) MFCC features
        h = torch.relu(self.bn1(self.conv1(x)))
        h = self.blocks(h)
        h = self.gap(h).flatten(1)
        return self.fc(h)  # logits


# ---------------------------------------------------------------------------
# TinyConv (TFLite Micro `micro_speech` reference model)
# ---------------------------------------------------------------------------

class TinyConv(nn.Module):
    def __init__(self, num_classes=12, in_h=49, in_w=40):
        super().__init__()
        self.conv = nn.Conv2d(1, 8, (10, 8), stride=(2, 2), padding=(4, 3))
        out_h = (in_h + 2 * 4 - 10) // 2 + 1
        out_w = (in_w + 2 * 3 - 8) // 2 + 1
        self.fc = nn.Linear(8 * out_h * out_w, num_classes)

    def forward(self, x):  # x: (N, 1, 49, 40) log-mel features
        h = torch.relu(self.conv(x))
        h = h.flatten(1)
        return self.fc(h)  # logits


# ---------------------------------------------------------------------------
# Training / export
# ---------------------------------------------------------------------------

def evaluate(model, feature_fn, x, y, batch_size=128):
    model.eval()
    correct = 0
    with torch.no_grad():
        for i in range(0, x.shape[0], batch_size):
            logits = model(feature_fn(x[i:i + batch_size]))
            correct += (logits.argmax(dim=1) == y[i:i + batch_size]).sum().item()
    model.train()
    return correct / x.shape[0]


def train(model, feature_fn, x_train, y_train, x_test, y_test, epochs, batch_size=64, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    n = x_train.shape[0]

    model.train()
    for epoch in range(epochs):
        perm = torch.randperm(n)
        total_loss = 0.0
        for i in range(0, n, batch_size):
            idx = perm[i:i + batch_size]
            xb, yb = feature_fn(x_train[idx]), y_train[idx]
            optimizer.zero_grad()
            loss = loss_fn(model(xb), yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(idx)
        test_acc = evaluate(model, feature_fn, x_test, y_test)
        print(f"  epoch {epoch + 1}/{epochs}  train_loss={total_loss / n:.4f}  test_acc={test_acc:.4f}")

    return evaluate(model, feature_fn, x_test, y_test)


class FeatureAndSoftmaxWrapper(nn.Module):
    """Bundles the feature-extraction front end + trained model + Softmax so
    the exported graph takes pre-computed features (see the doc string of
    each model) directly to class probabilities.
    """

    def __init__(self, base):
        super().__init__()
        self.base = base

    def forward(self, features):
        return torch.softmax(self.base(features), dim=1)


def export_model(filename, model, feature_shape, feature_desc, doc, example_features, example_label):
    wrapper = FeatureAndSoftmaxWrapper(model)
    wrapper.eval()

    out_dir = os.path.join(MODELS_DIR, CATEGORY)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, filename)

    dummy = torch.zeros(feature_shape, dtype=torch.float32)
    torch.onnx.export(
        wrapper, dummy, out_path,
        input_names=["input"], output_names=["output"],
        opset_version=17, dynamo=False, external_data=False,
    )

    onnx_model = onnx.load(out_path)
    onnx_model = simplify_onnx_model(onnx_model)
    onnx_model.graph.doc_string = doc
    onnx_model.producer_name = "aidge-test-model-generator"
    onnx.checker.check_model(onnx_model)
    onnx.save(onnx_model, out_path)

    with torch.no_grad():
        example_out = wrapper(example_features).numpy()

    io_inputs = [io_entry("input", list(feature_shape), "float32", feature_desc, example=example_features.numpy())]
    io_outputs = [io_entry(
        "output", [1, len(CLASSES)], "float32",
        f"Softmax probabilities over {len(CLASSES)} keyword classes, in class-index "
        f"order: {CLASSES}. Predicted class = argmax. (Example input above is a real "
        f"Speech Commands '{example_label}' clip.)",
        example=example_out,
    )]
    write_json_metadata(out_path, doc, io_inputs, io_outputs)

    size_kb = os.path.getsize(out_path) / 1024
    print(f"[{CATEGORY}] {filename}  {size_kb:.1f} KB  - {doc}")


if __name__ == "__main__":
    print("Loading Speech Commands (downloads ~2.4 GB on first run)...")
    x_train, y_train, x_test, y_test = load_speech_commands()
    print(f"Speech Commands loaded: {x_train.shape[0]} train / {x_test.shape[0]} test clips, "
          f"{len(CLASSES)} classes: {CLASSES}")

    example_idx = int((y_test == CLASSES.index("yes")).nonzero()[0].item())
    example_waveform = x_test[example_idx:example_idx + 1]

    print("\nTraining DS-CNN-S...")
    dscnn = DSCNN_S(num_classes=len(CLASSES))
    n_params = sum(p.numel() for p in dscnn.parameters())
    print(f"  DS-CNN-S parameter count: {n_params}")
    dscnn_acc = train(dscnn, mfcc_features, x_train, y_train, x_test, y_test, epochs=12)
    export_model(
        "ds_cnn_s_kws.onnx", dscnn, (1, 1, 49, 10),
        "Pre-computed 10-coefficient MFCC features over 49 time frames (1 second of "
        "16 kHz audio, 30 ms window / 20 ms hop), layout (batch, channel, time, mfcc). "
        "Feature extraction (MFCC) happens upstream (typically fixed-point DSP on "
        "device); this graph only covers the classifier itself.",
        f"DS-CNN-S, the 'small' depthwise-separable CNN keyword spotter from Zhang et al. "
        f"2018 'Hello Edge: Keyword Spotting on Microcontrollers' (approximate "
        f"reproduction of the published architecture: Conv-BN-ReLU stem + 4x "
        f"depthwise-separable Conv-BN-ReLU blocks + global average pool + dense, "
        f"{n_params} parameters, sized to match the paper's ~24k-parameter 'S' "
        f"configuration). Trained with PyTorch on the real Google Speech Commands v0.02 "
        f"dataset ({len(TARGET_WORDS)} target words + silence + unknown, "
        f"{len(CLASSES)} classes). Test accuracy={dscnn_acc:.4f}.",
        mfcc_features(example_waveform), CLASSES[y_test[example_idx].item()],
    )

    print("\nTraining TinyConv...")
    tinyconv = TinyConv(num_classes=len(CLASSES))
    n_params = sum(p.numel() for p in tinyconv.parameters())
    print(f"  TinyConv parameter count: {n_params}")
    tinyconv_acc = train(tinyconv, log_mel_features, x_train, y_train, x_test, y_test, epochs=12)
    export_model(
        "tinyconv_kws.onnx", tinyconv, (1, 1, 49, 40),
        "Pre-computed 40-band log-mel-spectrogram features over 49 time frames (1 second "
        "of 16 kHz audio, 30 ms window / 20 ms hop), layout (batch, channel, time, mel). "
        "Feature extraction happens upstream (typically fixed-point DSP on device); this "
        "graph only covers the classifier itself.",
        f"TinyConv, the minimal reference keyword-spotting model from TensorFlow Lite for "
        f"Microcontrollers' `micro_speech` example (a single Conv2D layer directly into a "
        f"dense output layer -- the simplest possible KWS baseline, {n_params} "
        f"parameters). Trained with PyTorch on the real Google Speech Commands v0.02 "
        f"dataset ({len(TARGET_WORDS)} target words + silence + unknown, "
        f"{len(CLASSES)} classes). Test accuracy={tinyconv_acc:.4f}.",
        log_mel_features(example_waveform), CLASSES[y_test[example_idx].item()],
    )

    print("\nDone.")
