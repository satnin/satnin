"""
Generator for small, ACTUALLY TRAINED ONNX models representative of real
embedded use cases: home appliances, home automation, smart watches, audio
event detection, and energy metering.

Unlike the other generators in this folder (which use random weights to
exercise operator conversion), the models here are trained with PyTorch on
synthetic-but-domain-realistic data, so their weights encode an actual
decision function instead of noise, and exported to ONNX with
`torch.onnx.export`.

Each model consumes a **raw sensor sample sequence** (a window of L
consecutive readings) rather than pre-computed summary statistics
(mean/std/max/...). On device this window is expected to be held in a
circular buffer: each new sample overwrites the oldest entry in place, and
the buffer is *linearized* (read out starting from the oldest sample, in
chronological order) before being copied into the model's input tensor.
The model itself only ever sees a plain chronologically-ordered vector of
L values, it has no notion of the physical ring/wrap-around indexing used
to maintain that buffer.

Three architectures are used, depending on whether the underlying signal
is quasi-periodic with an arbitrary phase (in which case a 1D-CNN + max
-pool front end is used, since it is naturally tolerant to the sample-to
-sample phase shift a plain dense layer cannot handle), rich enough to
warrant two conv/pool stages, or not periodic at all (a plain logistic
regression / small dense MLP directly on the raw window is enough):
- washing_machine_cycle_classifier, activity_recognition,
  appliance_load_classifier, voltage_anomaly_detector, glass_break_detector:
  1D-CNN front end, single conv/pool block (periodic or transient patterns
  at an arbitrary phase/position within the window).
- audio_event_classifier: 1D-CNN front end, two conv/pool blocks (richer
  broadband signal, larger window, benefits from a deeper feature extractor
  -- this is also the category's size ceiling, ~100 KB, allowed by the
  larger raw audio window and hidden layer).
- fridge_compressor_anomaly_detector, occupancy_detector: plain logistic
  regression on the raw window (amplitude/duration-driven decision).
- smoke_co_alarm_classifier, heart_rate_anomaly_detector: plain dense MLP
  on the raw window (trend/shape-driven decision, not periodic).

Run:  python gen_real_world_models.py
"""
import os

import numpy as np
import onnx
import torch
import torch.nn as nn

from _common import io_entry, write_json_metadata

MODELS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATEGORY = "real_world"

torch.manual_seed(0)


# ---------------------------------------------------------------------------
# Model architectures (forward() returns raw logits; the final
# Sigmoid/Softmax is added by a wrapper at export time, see `export_model`)
# ---------------------------------------------------------------------------

class LogisticSeq(nn.Module):
    """Plain logistic regression over a raw sequence window: Gemm -> (Sigmoid)."""

    def __init__(self, length):
        super().__init__()
        self.fc = nn.Linear(length, 1)

    def forward(self, x):
        return self.fc(x)


class MLPBinarySeq(nn.Module):
    """1-hidden-layer MLP over a raw sequence window: Gemm/Relu/Gemm -> (Sigmoid)."""

    def __init__(self, length, hidden=8):
        super().__init__()
        self.fc1 = nn.Linear(length, hidden)
        self.fc2 = nn.Linear(hidden, 1)

    def forward(self, x):
        h = torch.relu(self.fc1(x))
        return self.fc2(h)


class CNN1BlockSeq(nn.Module):
    """1D-CNN front end over a raw sequence window, tolerant to the sample
    phase/position of a periodic or transient signal: a single conv/pool
    block followed by a dense head: Conv/Relu/MaxPool/Flatten/Gemm/Relu/Gemm
    -> (Sigmoid or Softmax, added by the export wrapper). `num_outputs=1`
    for a binary detector, `num_outputs=num_classes` for a multiclass one.
    """

    def __init__(self, length, num_outputs, channels=8, hidden=16, kernel=5, pool=2):
        super().__init__()
        assert length % pool == 0, "length must be a multiple of pool"
        self.conv = nn.Conv1d(1, channels, kernel_size=kernel, padding=kernel // 2)
        self.pool = nn.MaxPool1d(pool)
        pooled_len = length // pool
        self.fc1 = nn.Linear(channels * pooled_len, hidden)
        self.fc2 = nn.Linear(hidden, num_outputs)

    def forward(self, x):  # x: (N, 1, L)
        h = torch.relu(self.conv(x))
        h = self.pool(h)
        h = h.flatten(1)
        h = torch.relu(self.fc1(h))
        return self.fc2(h)


class CNN2BlockSeq(nn.Module):
    """1D-CNN front end with two conv/pool blocks, for richer/broadband raw
    windows (larger L) where a single conv layer is not expressive enough:
    Conv/Relu/MaxPool/Conv/Relu/MaxPool/Flatten/Gemm/Relu/Gemm -> (Sigmoid
    or Softmax, added by the export wrapper).
    """

    def __init__(self, length, num_outputs, channels1=8, channels2=16, hidden=32,
                 kernel1=9, kernel2=5, pool1=4, pool2=4):
        super().__init__()
        assert length % (pool1 * pool2) == 0, "length must be a multiple of pool1*pool2"
        self.conv1 = nn.Conv1d(1, channels1, kernel_size=kernel1, padding=kernel1 // 2)
        self.pool1 = nn.MaxPool1d(pool1)
        self.conv2 = nn.Conv1d(channels1, channels2, kernel_size=kernel2, padding=kernel2 // 2)
        self.pool2 = nn.MaxPool1d(pool2)
        pooled_len = length // (pool1 * pool2)
        self.fc1 = nn.Linear(channels2 * pooled_len, hidden)
        self.fc2 = nn.Linear(hidden, num_outputs)

    def forward(self, x):  # x: (N, 1, L)
        h = torch.relu(self.conv1(x))
        h = self.pool1(h)
        h = torch.relu(self.conv2(h))
        h = self.pool2(h)
        h = h.flatten(1)
        h = torch.relu(self.fc1(h))
        return self.fc2(h)


class SigmoidWrapper(nn.Module):
    def __init__(self, base):
        super().__init__()
        self.base = base

    def forward(self, x):
        return torch.sigmoid(self.base(x))


class SoftmaxWrapper(nn.Module):
    def __init__(self, base):
        super().__init__()
        self.base = base

    def forward(self, x):
        return torch.softmax(self.base(x), dim=1)


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------

def train_model(model, X, y, multiclass, epochs=800, lr=0.01):
    X_t = torch.as_tensor(X, dtype=torch.float32)
    if multiclass:
        y_t = torch.as_tensor(y, dtype=torch.long)
        loss_fn = nn.CrossEntropyLoss()
    else:
        y_t = torch.as_tensor(y, dtype=torch.float32).unsqueeze(1)
        loss_fn = nn.BCEWithLogitsLoss()

    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    model.train()
    for _ in range(epochs):
        optimizer.zero_grad()
        logits = model(X_t)
        loss = loss_fn(logits, y_t)
        loss.backward()
        optimizer.step()

    model.eval()
    with torch.no_grad():
        logits = model(X_t)
        if multiclass:
            preds = logits.argmax(dim=1)
            accuracy = (preds == y_t).float().mean().item()
        else:
            preds = (torch.sigmoid(logits) > 0.5).float()
            accuracy = (preds == y_t).float().mean().item()
    return accuracy


# ---------------------------------------------------------------------------
# ONNX export
# ---------------------------------------------------------------------------

def export_model(domain, filename, base_model, input_shape, multiclass, doc, feature_desc, output_desc,
                  example_input=None):
    """`example_input`, when given, should be one real sample from the
    training set (matching `input_shape`) so the JSON sidecar's example is
    an actual, meaningful window rather than noise -- and its example
    output is the model's real prediction for that window.
    """
    wrapper = SoftmaxWrapper(base_model) if multiclass else SigmoidWrapper(base_model)
    wrapper.eval()
    dummy = torch.zeros(input_shape, dtype=torch.float32)

    out_dir = os.path.join(MODELS_DIR, CATEGORY, domain)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, filename)

    torch.onnx.export(
        wrapper, dummy, out_path,
        input_names=["input"], output_names=["output"],
        opset_version=17, dynamo=False, external_data=False,
    )

    model = onnx.load(out_path)
    model.graph.doc_string = doc
    model.producer_name = "aidge-test-model-generator"
    onnx.checker.check_model(model)
    onnx.save(model, out_path)

    if example_input is None:
        example_np = dummy.numpy()
    else:
        example_np = np.asarray(example_input, dtype=np.float32).reshape(input_shape)
    with torch.no_grad():
        example_out_np = wrapper(torch.as_tensor(example_np)).numpy()
        out_shape = list(example_out_np.shape)

    io_inputs = [io_entry("input", list(input_shape), "float32", feature_desc, example=example_np)]
    io_outputs = [io_entry("output", out_shape, "float32", output_desc, example=example_out_np)]
    write_json_metadata(out_path, doc, io_inputs, io_outputs)

    size_b = os.path.getsize(out_path)
    print(f"[{domain}] {filename:<38} {size_b:6d} B  - {doc}")


def circular_buffer_desc(length, unit_desc, sample_desc):
    return (
        f"Raw sequence of the last {length} {sample_desc}, in chronological order "
        f"(oldest sample at index 0, most recent at index {length - 1}), {unit_desc}. "
        f"On device this window is held in a circular buffer that is overwritten "
        f"sample-by-sample; the buffer is linearized (read out oldest-to-newest from "
        f"the current write pointer) into this flat vector before inference."
    )


# ---------------------------------------------------------------------------
# 1. Home appliances
# ---------------------------------------------------------------------------

def gen_washing_machine_cycle_classifier():
    """4-class classifier of the washing machine cycle phase from a raw
    motor current-draw sequence (circular buffer of L samples).
    Classes: 0=idle, 1=wash, 2=rinse, 3=spin.
    """
    rng = np.random.default_rng(1)
    L = 24
    n_per_class = 300
    t = np.arange(L)
    # (base current, oscillation amplitude, oscillation cycles over the window, noise std, ramp)
    profiles = [
        dict(base=0.05, amp=0.00, cycles=0.0, noise=0.02, ramp=0.0),   # idle
        dict(base=1.00, amp=0.40, cycles=3.0, noise=0.15, ramp=0.0),   # wash (agitation)
        dict(base=0.70, amp=0.20, cycles=4.0, noise=0.10, ramp=0.0),   # rinse
        dict(base=2.50, amp=0.10, cycles=0.5, noise=0.20, ramp=1.0),   # spin (ramp-up then steady)
    ]
    X, y = [], []
    for label, prof in enumerate(profiles):
        base = rng.normal(prof["base"], prof["base"] * 0.08 + 0.01, n_per_class)[:, None]
        amp = prof["amp"] * (1 + rng.normal(0, 0.1, (n_per_class, 1)))
        phase = rng.uniform(0, 2 * np.pi, (n_per_class, 1))
        osc = amp * np.sin(2 * np.pi * prof["cycles"] * t[None, :] / L + phase)
        ramp = prof["ramp"] * np.clip(t[None, :] / (L * 0.3), 0, 1)
        noise = rng.normal(0, prof["noise"], (n_per_class, L))
        seq = np.clip(base + base * ramp + osc + noise, 0, None)
        X.append(seq)
        y.append(np.full(n_per_class, label))
    X = np.concatenate(X, axis=0).astype(np.float32)[:, None, :]  # (N, 1, L) for Conv1d
    y = np.concatenate(y, axis=0)

    model = CNN1BlockSeq(L, num_outputs=4, channels=8, hidden=16)
    acc = train_model(model, X, y, multiclass=True, epochs=1200, lr=0.01)
    export_model(
        "home_appliances", "washing_machine_cycle_classifier.onnx", model, (1, 1, L), True,
        f"Washing machine cycle phase classifier (idle/wash/rinse/spin) from a raw "
        f"motor current-draw sequence. Trained 1D-CNN (Conv8-Pool-FC16-FC4), "
        f"train accuracy={acc:.3f}",
        feature_desc=circular_buffer_desc(L, "in amperes", "motor current-draw samples (~1 sample/15 s)"),
        output_desc=(
            "Softmax probabilities over 4 washing-machine cycle phases, in "
            "class-index order: [0]=idle, [1]=wash, [2]=rinse, [3]=spin. "
            "Predicted class = argmax."
        ),
        example_input=X[n_per_class:n_per_class + 1],  # a "wash" phase sample
    )


def gen_fridge_compressor_anomaly_detector():
    """Binary classifier (normal / anomaly) of a fridge compressor cycle
    from a raw current-draw sequence (circular buffer of L samples spanning
    one on/off duty cycle).
    """
    rng = np.random.default_rng(2)
    L = 32
    n = 500

    def make_cycle(amplitude, duty_ratio, noise, off_leak, count):
        on_samples = np.clip((duty_ratio * L).astype(int), 1, L - 1)
        seq = np.zeros((count, L))
        for i in range(count):
            k = on_samples[i]
            seq[i, :k] = amplitude[i] + rng.normal(0, noise, k)
            seq[i, k:] = off_leak + rng.normal(0, noise * 0.3, L - k)
        return seq

    amp_ok = rng.normal(0.60, 0.05, n)
    duty_ok = np.clip(rng.normal(0.35, 0.05, n), 0.1, 0.6)
    seq_ok = make_cycle(amp_ok, duty_ok, 0.03, 0.02, n)

    amp_bad = rng.normal(1.10, 0.15, n)
    duty_bad = np.clip(rng.normal(0.75, 0.10, n), 0.5, 1.0)
    seq_bad = make_cycle(amp_bad, duty_bad, 0.08, 0.05, n)

    X = np.concatenate([seq_ok, seq_bad], axis=0).astype(np.float32)
    y = np.concatenate([np.zeros(n), np.ones(n)])

    model = LogisticSeq(L)
    acc = train_model(model, X, y, multiclass=False, epochs=800, lr=0.05)
    export_model(
        "home_appliances", "fridge_compressor_anomaly_detector.onnx", model, (1, L), False,
        f"Fridge compressor anomaly detector (normal vs. anomalous cycle) from a raw "
        f"current-draw sequence spanning one on/off duty cycle. Trained logistic "
        f"regression, train accuracy={acc:.3f}",
        feature_desc=circular_buffer_desc(L, "in amperes", "compressor current-draw samples spanning one on/off duty cycle"),
        output_desc=(
            "Sigmoid probability that the cycle is anomalous (0=normal, 1=anomaly). "
            "Threshold at 0.5 for a binary decision."
        ),
        example_input=X[n:n + 1],  # an anomalous-cycle sample
    )


# ---------------------------------------------------------------------------
# 2. Home automation
# ---------------------------------------------------------------------------

def gen_occupancy_detector():
    """Binary room occupancy detector (empty / occupied) from a raw PIR
    motion-intensity sequence (circular buffer of L samples).
    """
    rng = np.random.default_rng(3)
    L = 16
    n = 500

    empty = np.clip(rng.normal(0.02, 0.02, (n, L)), 0, 1)
    # occasional tiny spurious blips
    blips = rng.random((n, L)) < 0.03
    empty = np.where(blips, empty + rng.uniform(0.1, 0.3, (n, L)), empty)

    occupied = np.clip(rng.normal(0.05, 0.03, (n, L)), 0, 1)
    n_bursts = rng.integers(2, 6, n)
    for i in range(n):
        burst_idx = rng.choice(L, size=n_bursts[i], replace=False)
        occupied[i, burst_idx] = np.clip(rng.normal(0.7, 0.15, n_bursts[i]), 0, 1)

    X = np.concatenate([empty, occupied], axis=0).astype(np.float32)
    y = np.concatenate([np.zeros(n), np.ones(n)])

    model = LogisticSeq(L)
    acc = train_model(model, X, y, multiclass=False, epochs=800, lr=0.05)
    export_model(
        "home_automation", "occupancy_detector.onnx", model, (1, L), False,
        f"Room occupancy detector (empty vs. occupied) from a raw PIR motion-intensity "
        f"sequence. Trained logistic regression, train accuracy={acc:.3f}",
        feature_desc=circular_buffer_desc(L, "normalized to [0,1]", "PIR motion-intensity samples (~1 sample/4 s)"),
        output_desc=(
            "Sigmoid probability that the room is occupied (0=empty, 1=occupied). "
            "Threshold at 0.5 for a binary decision."
        ),
        example_input=X[n:n + 1],  # an "occupied" sample
    )


def gen_smoke_co_alarm_classifier():
    """Binary smoke/CO alarm classifier (safe / alarm) from a raw smoke
    density sequence (circular buffer of L samples).
    """
    rng = np.random.default_rng(4)
    L = 16
    n = 500
    t = np.arange(L)

    safe = np.clip(rng.normal(0.05, 0.03, (n, L)), 0, None)

    start_level = rng.uniform(0.0, 0.15, (n, 1))
    end_level = rng.uniform(0.6, 0.95, (n, 1))
    trend = start_level + (end_level - start_level) * (t[None, :] / (L - 1))
    alarm = np.clip(trend + rng.normal(0, 0.05, (n, L)), 0, 1)

    X = np.concatenate([safe, alarm], axis=0).astype(np.float32)
    y = np.concatenate([np.zeros(n), np.ones(n)])

    model = MLPBinarySeq(L, hidden=8)
    acc = train_model(model, X, y, multiclass=False, epochs=1000, lr=0.02)
    export_model(
        "home_automation", "smoke_co_alarm_classifier.onnx", model, (1, L), False,
        f"Smoke/CO alarm classifier (safe vs. alarm) from a raw smoke-density sequence. "
        f"Trained MLP ({L}-8-1), train accuracy={acc:.3f}",
        feature_desc=circular_buffer_desc(L, "normalized to [0,1]", "smoke-density samples (~1 sample/s)"),
        output_desc=(
            "Sigmoid probability of an alarm condition (0=safe, 1=alarm). "
            "Threshold at 0.5 for a binary decision."
        ),
        example_input=X[n:n + 1],  # an "alarm" sample
    )


# ---------------------------------------------------------------------------
# 3. Smart watch
# ---------------------------------------------------------------------------

def gen_activity_recognition():
    """3-class activity recognizer (resting/walking/running) from a raw
    accelerometer magnitude sequence (circular buffer of L samples).
    """
    rng = np.random.default_rng(5)
    L = 32
    n_per_class = 300
    t = np.arange(L)
    # (baseline ~1g, oscillation amplitude, step cycles over the window, noise std)
    profiles = [
        dict(base=1.00, amp=0.03, cycles=0.0, noise=0.02),   # resting
        dict(base=1.00, amp=0.30, cycles=2.0, noise=0.08),   # walking
        dict(base=1.00, amp=0.80, cycles=3.5, noise=0.15),   # running
    ]
    X, y = [], []
    for label, prof in enumerate(profiles):
        base = rng.normal(prof["base"], 0.03, (n_per_class, 1))
        amp = prof["amp"] * (1 + rng.normal(0, 0.1, (n_per_class, 1)))
        phase = rng.uniform(0, 2 * np.pi, (n_per_class, 1))
        osc = amp * np.abs(np.sin(2 * np.pi * prof["cycles"] * t[None, :] / L + phase))
        noise = rng.normal(0, prof["noise"], (n_per_class, L))
        seq = np.clip(base + osc + noise, 0, None)
        X.append(seq)
        y.append(np.full(n_per_class, label))
    X = np.concatenate(X, axis=0).astype(np.float32)[:, None, :]  # (N, 1, L) for Conv1d
    y = np.concatenate(y, axis=0)

    model = CNN1BlockSeq(L, num_outputs=3, channels=8, hidden=16)
    acc = train_model(model, X, y, multiclass=True, epochs=1200, lr=0.01)
    export_model(
        "smart_watch", "activity_recognition.onnx", model, (1, 1, L), True,
        f"Activity recognizer (resting/walking/running) from a raw accelerometer "
        f"magnitude sequence. Trained 1D-CNN (Conv8-Pool-FC16-FC3), train accuracy={acc:.3f}",
        feature_desc=circular_buffer_desc(L, "in g (9.81 m/s^2)", "accelerometer-magnitude samples (~32 Hz)"),
        output_desc=(
            "Softmax probabilities over 3 activity classes, in class-index order: "
            "[0]=resting, [1]=walking, [2]=running. Predicted class = argmax."
        ),
        example_input=X[n_per_class:n_per_class + 1],  # a "walking" sample
    )


def gen_heart_rate_anomaly_detector():
    """Binary heart-rate anomaly detector (normal / abnormal) from a raw
    beat-to-beat heart-rate sequence (circular buffer of L samples).
    """
    rng = np.random.default_rng(6)
    L = 16
    n = 500

    normal = 0.45 + np.cumsum(rng.normal(0, 0.015, (n, L)), axis=1)
    normal = np.clip(normal, 0.2, 0.8)

    abnormal_base = rng.normal(0.45, 0.05, (n, 1))
    abnormal = abnormal_base + np.cumsum(rng.normal(0, 0.05, (n, L)), axis=1)
    spike_idx = rng.integers(0, L, n)
    for i in range(n):
        abnormal[i, spike_idx[i]:] += rng.choice([-1, 1]) * rng.uniform(0.2, 0.4)
    abnormal = np.clip(abnormal, 0.05, 0.95)

    X = np.concatenate([normal, abnormal], axis=0).astype(np.float32)
    y = np.concatenate([np.zeros(n), np.ones(n)])

    model = MLPBinarySeq(L, hidden=8)
    acc = train_model(model, X, y, multiclass=False, epochs=1000, lr=0.02)
    export_model(
        "smart_watch", "heart_rate_anomaly_detector.onnx", model, (1, L), False,
        f"Heart-rate anomaly detector (normal vs. abnormal) from a raw beat-to-beat "
        f"heart-rate sequence. Trained MLP ({L}-8-1), train accuracy={acc:.3f}",
        feature_desc=circular_buffer_desc(
            L, "normalized so that ~0.45 corresponds to a resting baseline around 60-100 bpm",
            "consecutive beat-to-beat heart-rate samples",
        ),
        output_desc=(
            "Sigmoid probability of an abnormal heart-rate pattern (0=normal, "
            "1=abnormal). Threshold at 0.5 for a binary decision."
        ),
        example_input=X[n:n + 1],  # an "abnormal" sample
    )


# ---------------------------------------------------------------------------
# 4. Audio
# ---------------------------------------------------------------------------

def gen_audio_event_classifier():
    """3-class audio event classifier (background noise / speech-like babble
    / siren-alarm tone) from a raw audio waveform sequence (circular buffer
    of L samples at a virtual 8 kHz sample rate, i.e. a 32 ms window).
    """
    rng = np.random.default_rng(7)
    fs = 8000
    L = 256  # 32 ms @ 8 kHz
    n_per_class = 300
    t = np.arange(L) / fs

    X, y = [], []

    # class 0: background noise -- low-amplitude broadband noise, no tone
    noise = rng.normal(0, 0.04, (n_per_class, L))
    X.append(noise)
    y.append(np.full(n_per_class, 0))

    # class 1: speech-like babble -- a handful of random-frequency
    # harmonics with a slow amplitude envelope (formant-like richness),
    # phase and frequencies drawn independently per sample
    babble = np.zeros((n_per_class, L))
    for i in range(n_per_class):
        n_tones = rng.integers(3, 6)
        freqs = rng.uniform(200, 2000, n_tones)
        phases = rng.uniform(0, 2 * np.pi, n_tones)
        amps = rng.uniform(0.1, 0.3, n_tones)
        sig = sum(a * np.sin(2 * np.pi * f * t + p) for a, f, p in zip(amps, freqs, phases))
        envelope = 0.5 + 0.5 * np.abs(np.sin(2 * np.pi * rng.uniform(4, 10) * t + rng.uniform(0, 2 * np.pi)))
        babble[i] = sig * envelope
    babble += rng.normal(0, 0.03, (n_per_class, L))
    X.append(babble)
    y.append(np.full(n_per_class, 1))

    # class 2: siren/alarm -- a clean two-tone / frequency-sweep warble,
    # more tonal and less noisy than babble
    siren = np.zeros((n_per_class, L))
    for i in range(n_per_class):
        f_low, f_high = rng.uniform(500, 700), rng.uniform(1000, 1300)
        sweep_rate = rng.uniform(3, 6)  # sweeps over the window
        phase0 = rng.uniform(0, 2 * np.pi)
        freq_t = f_low + (f_high - f_low) * 0.5 * (1 + np.sin(2 * np.pi * sweep_rate * t + phase0))
        inst_phase = 2 * np.pi * np.cumsum(freq_t) / fs
        amp = rng.uniform(0.5, 0.8)
        siren[i] = amp * np.sin(inst_phase)
    siren += rng.normal(0, 0.03, (n_per_class, L))
    X.append(siren)
    y.append(np.full(n_per_class, 2))

    X = np.concatenate(X, axis=0).astype(np.float32)[:, None, :]  # (N, 1, L) for Conv1d
    y = np.concatenate(y, axis=0)

    model = CNN2BlockSeq(L, num_outputs=3, channels1=8, channels2=16, hidden=32,
                          kernel1=9, kernel2=5, pool1=4, pool2=4)
    acc = train_model(model, X, y, multiclass=True, epochs=1500, lr=0.01)
    export_model(
        "audio", "audio_event_classifier.onnx", model, (1, 1, L), True,
        f"Audio event classifier (background noise / speech-like babble / siren-alarm "
        f"tone) from a raw audio waveform sequence. Trained 1D-CNN "
        f"(Conv8-Pool4-Conv16-Pool4-FC32-FC3), train accuracy={acc:.3f}",
        feature_desc=circular_buffer_desc(
            L, "amplitude normalized to roughly [-1, 1]",
            f"raw audio waveform samples at a virtual {fs} Hz sample rate ({1000*L/fs:.0f} ms window)",
        ),
        output_desc=(
            "Softmax probabilities over 3 audio event classes, in class-index order: "
            "[0]=background noise, [1]=speech-like babble, [2]=siren/alarm tone. "
            "Predicted class = argmax."
        ),
        example_input=X[2 * n_per_class:2 * n_per_class + 1],  # a "siren" sample
    )


def gen_glass_break_detector():
    """Binary glass-break sound detector (normal ambient sound / glass-break
    impact) from a raw audio waveform sequence (circular buffer of L samples
    at a virtual 8 kHz sample rate, i.e. a 16 ms window).
    """
    rng = np.random.default_rng(8)
    fs = 8000
    L = 128  # 16 ms @ 8 kHz
    n = 400
    t = np.arange(L) / fs

    # normal: low-level ambient noise plus an optional faint low-frequency hum
    normal = rng.normal(0, 0.04, (n, L))
    hum_freq = rng.uniform(50, 150, n)
    hum_amp = rng.uniform(0, 0.05, n)
    hum_phase = rng.uniform(0, 2 * np.pi, n)
    for i in range(n):
        normal[i] += hum_amp[i] * np.sin(2 * np.pi * hum_freq[i] * t + hum_phase[i])

    # glass break: a sharp impulse at a random position followed by a
    # decaying high-frequency ringing, on top of ambient noise
    glass = rng.normal(0, 0.04, (n, L))
    impact_idx = rng.integers(L // 4, L - L // 4, n)
    ring_freq = rng.uniform(2500, 4000, n)
    ring_amp = rng.uniform(0.6, 1.0, n)
    decay = rng.uniform(150, 400, n)  # decay rate, in 1/s
    for i in range(n):
        idx = impact_idx[i]
        tail = np.arange(L - idx) / fs
        ring = ring_amp[i] * np.exp(-decay[i] * tail) * np.sin(2 * np.pi * ring_freq[i] * tail)
        glass[i, idx:] += ring
        glass[i, idx] += rng.uniform(0.3, 0.6)  # the impact click itself

    X = np.concatenate([normal, glass], axis=0).astype(np.float32)[:, None, :]  # (N, 1, L)
    y = np.concatenate([np.zeros(n), np.ones(n)])

    model = CNN1BlockSeq(L, num_outputs=1, channels=12, hidden=16, kernel=7, pool=8)
    acc = train_model(model, X, y, multiclass=False, epochs=1200, lr=0.01)
    export_model(
        "audio", "glass_break_detector.onnx", model, (1, 1, L), False,
        f"Glass-break sound detector (normal ambient sound vs. glass-break impact) "
        f"from a raw audio waveform sequence. Trained 1D-CNN (Conv12-Pool8-FC16-FC1), "
        f"train accuracy={acc:.3f}",
        feature_desc=circular_buffer_desc(
            L, "amplitude normalized to roughly [-1, 1]",
            f"raw audio waveform samples at a virtual {fs} Hz sample rate ({1000*L/fs:.0f} ms window)",
        ),
        output_desc=(
            "Sigmoid probability of a glass-break impact sound (0=normal ambient "
            "sound, 1=glass break). Threshold at 0.5 for a binary decision."
        ),
        example_input=X[n:n + 1],  # a glass-break sample
    )


# ---------------------------------------------------------------------------
# 5. Energy metering
# ---------------------------------------------------------------------------

def gen_appliance_load_classifier():
    """4-class NILM-style appliance load classifier (idle / resistive heater
    / kettle / motor start-up) from a raw mains current waveform sequence
    (circular buffer of L samples spanning ~2 mains cycles).
    """
    rng = np.random.default_rng(9)
    L = 128
    n_per_class = 300
    t = np.arange(L)
    cycles = 2.0  # 2 mains cycles across the window

    X, y = [], []

    # class 0: idle / standby -- near-zero leakage current, no clean sinusoid
    idle = rng.normal(0, 0.02, (n_per_class, L))
    X.append(idle)
    y.append(np.full(n_per_class, 0))

    # class 1: resistive heater -- clean, low-distortion sinusoid, moderate amplitude
    phase = rng.uniform(0, 2 * np.pi, (n_per_class, 1))
    amp = rng.normal(1.0, 0.05, (n_per_class, 1))
    heater = amp * np.sin(2 * np.pi * cycles * t[None, :] / L + phase) + rng.normal(0, 0.03, (n_per_class, L))
    X.append(heater)
    y.append(np.full(n_per_class, 1))

    # class 2: kettle -- also resistive, but higher amplitude (higher power)
    phase = rng.uniform(0, 2 * np.pi, (n_per_class, 1))
    amp = rng.normal(1.8, 0.08, (n_per_class, 1))
    kettle = amp * np.sin(2 * np.pi * cycles * t[None, :] / L + phase) + rng.normal(0, 0.05, (n_per_class, L))
    X.append(kettle)
    y.append(np.full(n_per_class, 2))

    # class 3: motor start-up -- high-amplitude inrush that decays quickly
    # to a steady, mildly distorted running current
    phase = rng.uniform(0, 2 * np.pi, (n_per_class, 1))
    inrush_amp = rng.normal(3.0, 0.3, (n_per_class, 1))
    steady_amp = rng.normal(0.8, 0.1, (n_per_class, 1))
    decay = rng.uniform(4.0, 8.0, (n_per_class, 1))  # decay rate over the window (in window-fractions)
    envelope = steady_amp + (inrush_amp - steady_amp) * np.exp(-decay * t[None, :] / L)
    third_harm = 0.15 * np.sin(2 * np.pi * (3 * cycles) * t[None, :] / L + phase)
    motor = envelope * np.sin(2 * np.pi * cycles * t[None, :] / L + phase) + envelope * third_harm
    motor += rng.normal(0, 0.08, (n_per_class, L))
    X.append(motor)
    y.append(np.full(n_per_class, 3))

    X = np.concatenate(X, axis=0).astype(np.float32)[:, None, :]  # (N, 1, L)
    y = np.concatenate(y, axis=0)

    model = CNN1BlockSeq(L, num_outputs=4, channels=16, hidden=32, kernel=7, pool=4)
    acc = train_model(model, X, y, multiclass=True, epochs=1200, lr=0.01)
    export_model(
        "energy", "appliance_load_classifier.onnx", model, (1, 1, L), True,
        f"NILM-style appliance load classifier (idle / resistive heater / kettle / "
        f"motor start-up) from a raw mains current waveform sequence. Trained 1D-CNN "
        f"(Conv16-Pool4-FC32-FC4), train accuracy={acc:.3f}",
        feature_desc=circular_buffer_desc(
            L, "normalized to a per-unit current scale (1.0 ~ rated resistive load current)",
            f"raw mains current waveform samples spanning ~{cycles:.0f} mains cycles",
        ),
        output_desc=(
            "Softmax probabilities over 4 appliance-load classes, in class-index "
            "order: [0]=idle/standby, [1]=resistive heater, [2]=kettle, "
            "[3]=motor start-up. Predicted class = argmax."
        ),
        example_input=X[2 * n_per_class:2 * n_per_class + 1],  # a "kettle" sample
    )


def gen_voltage_anomaly_detector():
    """Binary power-quality anomaly detector (normal / anomalous: sag, swell,
    or transient spike) from a raw mains voltage waveform sequence (circular
    buffer of L samples spanning ~2 mains cycles).
    """
    rng = np.random.default_rng(10)
    L = 64
    n = 500
    t = np.arange(L)
    cycles = 2.0

    phase = rng.uniform(0, 2 * np.pi, (n, 1))
    normal = np.sin(2 * np.pi * cycles * t[None, :] / L + phase) + rng.normal(0, 0.02, (n, L))

    phase = rng.uniform(0, 2 * np.pi, (n, 1))
    base = np.sin(2 * np.pi * cycles * t[None, :] / L + phase)
    anomaly_kind = rng.integers(0, 3, n)
    anomaly = base.copy()
    for i in range(n):
        if anomaly_kind[i] == 0:  # sag
            anomaly[i] *= rng.uniform(0.4, 0.75)
        elif anomaly_kind[i] == 1:  # swell
            anomaly[i] *= rng.uniform(1.2, 1.5)
        else:  # transient spike
            spike_idx = rng.integers(0, L)
            anomaly[i, spike_idx] += rng.choice([-1, 1]) * rng.uniform(1.0, 2.0)
    anomaly += rng.normal(0, 0.03, (n, L))

    X = np.concatenate([normal, anomaly], axis=0).astype(np.float32)[:, None, :]  # (N, 1, L)
    y = np.concatenate([np.zeros(n), np.ones(n)])

    model = CNN1BlockSeq(L, num_outputs=1, channels=8, hidden=16, kernel=5, pool=2)
    acc = train_model(model, X, y, multiclass=False, epochs=1000, lr=0.01)
    export_model(
        "energy", "voltage_anomaly_detector.onnx", model, (1, 1, L), False,
        f"Power-quality anomaly detector (normal vs. sag/swell/transient spike) from a "
        f"raw mains voltage waveform sequence. Trained 1D-CNN (Conv8-Pool2-FC16-FC1), "
        f"train accuracy={acc:.3f}",
        feature_desc=circular_buffer_desc(
            L, "normalized to a per-unit voltage scale (1.0 = nominal amplitude)",
            f"raw mains voltage waveform samples spanning ~{cycles:.0f} mains cycles",
        ),
        output_desc=(
            "Sigmoid probability of a power-quality anomaly -- sag, swell, or "
            "transient spike -- (0=normal, 1=anomalous). Threshold at 0.5 for a "
            "binary decision."
        ),
        example_input=X[n:n + 1],  # an anomalous sample
    )


if __name__ == "__main__":
    gen_washing_machine_cycle_classifier()
    gen_fridge_compressor_anomaly_detector()

    gen_occupancy_detector()
    gen_smoke_co_alarm_classifier()

    gen_activity_recognition()
    gen_heart_rate_anomaly_detector()

    gen_audio_event_classifier()
    gen_glass_break_detector()

    gen_appliance_load_classifier()
    gen_voltage_anomaly_detector()

    print("\nDone.")
