"""
Generator for int8-quantized variants of the larger `benchmarks/` models
(LeNet-5, ResNet-8, DS-CNN-S, and the DCASE autoencoder), using
onnxruntime's static post-training quantization (real calibration data,
reused from each model's own training script) rather than hand-built
quantized graphs.

Produces BOTH of onnxruntime's quantized graph representations for each
model, since they look quite different and a converter may handle one
better than the other:
- `_int8_qdq.onnx`   -- QDQ format: the original float-typed graph, with
  QuantizeLinear/DequantizeLinear pairs inserted around each quantized op
  (weights and activations alike). Same style as `quantized_int8/`
  elsewhere in this folder.
- `_int8_qoperator.onnx` -- QOperator format: ops are directly replaced by
  their integer-native counterparts (QLinearConv, QLinearMatMul,
  ConvInteger, QGemm, ...), no separate Quantize/Dequantize nodes; the
  graph's tensors are int8/uint8-typed end to end between quantized ops.

Run AFTER the corresponding fp32 model(s) have been generated (this script
imports their training modules to reuse their data-loading code, but does
NOT retrain anything -- it only loads real held-out samples for
calibration).

Requires:  pip install onnxruntime torch torchvision torchaudio
Run:       python gen_benchmark_quantize.py
"""
import json
import os

import onnx
import onnxruntime as ort
from onnxruntime.quantization import CalibrationDataReader, QuantFormat, QuantType, quantize_static

from _common import io_entry, write_json_metadata

MODELS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATEGORY = "benchmarks"

FORMATS = {
    "qdq": (QuantFormat.QDQ,
            "QDQ format (QuantizeLinear/DequantizeLinear pairs inserted around each "
            "quantized op; the graph otherwise keeps its original float32 op types)"),
    "qoperator": (QuantFormat.QOperator,
                  "QOperator format (ops directly replaced by their integer-native "
                  "counterparts -- QLinearConv, QLinearMatMul, ConvInteger, QGemm, "
                  "etc. -- no separate Quantize/Dequantize nodes)"),
}


class ArrayCalibrationDataReader(CalibrationDataReader):
    """Feeds a fixed list of (already batched, shape (1, ...)) numpy arrays
    as calibration data for onnxruntime's static quantizer. Since a single
    reader is exhausted after one pass, a fresh instance is built per call.
    """

    def __init__(self, input_name, batched_arrays):
        self.input_name = input_name
        self._iter = iter(batched_arrays)

    def get_next(self):
        arr = next(self._iter, None)
        return None if arr is None else {self.input_name: arr}


def quantize_one_format(fp32_path, out_path, input_name, calibration_arrays,
                         fmt_key, doc_prefix):
    quant_format, fmt_desc = FORMATS[fmt_key]
    reader = ArrayCalibrationDataReader(input_name, iter(calibration_arrays))
    quantize_static(
        fp32_path, out_path, reader,
        quant_format=quant_format,
        per_channel=True,
        activation_type=QuantType.QInt8,
        weight_type=QuantType.QInt8,
    )

    fp32_model = onnx.load(fp32_path)
    int8_model = onnx.load(out_path)
    doc = f"{fp32_model.graph.doc_string} {doc_prefix} INT8, {fmt_desc}."
    int8_model.graph.doc_string = doc
    int8_model.producer_name = "aidge-test-model-generator"
    onnx.save(int8_model, out_path)

    sess = ort.InferenceSession(out_path, providers=["CPUExecutionProvider"])
    example_in = calibration_arrays[0]
    example_out = sess.run(None, {input_name: example_in})[0]

    fp32_json_path = os.path.splitext(fp32_path)[0] + ".json"
    if os.path.exists(fp32_json_path):
        fp32_meta = json.load(open(fp32_json_path, encoding="utf-8"))
        io_inputs = [io_entry(e["name"], e["shape"], e["dtype"], e["description"], example=example_in)
                     for e in fp32_meta["inputs"]]
        io_outputs = [io_entry(e["name"], list(example_out.shape), "float32", e["description"], example=example_out)
                      for e in fp32_meta["outputs"]]
    else:
        io_inputs = [io_entry(input_name, list(example_in.shape), "float32", "See fp32 sibling model.", example=example_in)]
        io_outputs = [io_entry("output", list(example_out.shape), "float32", "See fp32 sibling model.", example=example_out)]
    write_json_metadata(out_path, doc, io_inputs, io_outputs)

    fp32_kb = os.path.getsize(fp32_path) / 1024
    int8_kb = os.path.getsize(out_path) / 1024
    ops = sorted(set(n.op_type for n in int8_model.graph.node))
    print(f"[{CATEGORY}] {os.path.basename(out_path)}  {int8_kb:.1f} KB  "
          f"(fp32 sibling: {fp32_kb:.1f} KB, {fp32_kb / int8_kb:.1f}x smaller)  ops={ops}")


def quantize_model(fp32_name, base_int8_name, input_name, calibration_arrays, doc_prefix):
    fp32_path = os.path.join(MODELS_DIR, CATEGORY, fp32_name)
    if not os.path.exists(fp32_path):
        print(f"[skip] {fp32_name} not found -- generate it first.")
        return

    for fmt_key in FORMATS:
        out_path = os.path.join(MODELS_DIR, CATEGORY, f"{base_int8_name}_{fmt_key}.onnx")
        quantize_one_format(fp32_path, out_path, input_name, calibration_arrays, fmt_key, doc_prefix)


def quantize_lenet5():
    import gen_benchmark_lenet5 as m
    x_train, y_train, x_test, y_test = m.load_mnist()
    calib = [x_test[i:i + 1].numpy() for i in range(200)]
    quantize_model(
        "lenet5_mnist.onnx", "lenet5_mnist_int8", "input", calib,
        "Quantized (onnxruntime static PTQ, 200 real MNIST test images for calibration) --",
    )


def quantize_resnet8():
    import gen_benchmark_resnet8 as m
    x_train, y_train, x_test, y_test = m.load_cifar10()
    calib = [x_test[i:i + 1].numpy() for i in range(200)]
    quantize_model(
        "resnet8_cifar10.onnx", "resnet8_cifar10_int8", "input", calib,
        "Quantized (onnxruntime static PTQ, 200 real CIFAR-10 test images for calibration) --",
    )


def quantize_ds_cnn_s():
    import gen_benchmark_kws as m
    x_train, y_train, x_test, y_test = m.load_speech_commands()
    feats = m.mfcc_features(x_test[:200])
    calib = [feats[i:i + 1].numpy() for i in range(feats.shape[0])]
    quantize_model(
        "ds_cnn_s_kws.onnx", "ds_cnn_s_kws_int8", "input", calib,
        "Quantized (onnxruntime static PTQ, 200 real Speech Commands test-clip MFCC "
        "features for calibration) --",
    )


def quantize_dcase_ae():
    import gen_benchmark_dcase_ae as m
    x_normal, x_anom = m.make_synthetic_data()
    calib = [x_normal[i:i + 1].numpy() for i in range(200)]
    quantize_model(
        "dcase_baseline_autoencoder.onnx", "dcase_baseline_autoencoder_int8", "input", calib,
        "Quantized (onnxruntime static PTQ, 200 synthetic 'normal' calibration vectors, "
        "same synthetic-data caveat as the float32 original applies) --",
    )


if __name__ == "__main__":
    quantize_lenet5()
    quantize_resnet8()
    quantize_ds_cnn_s()
    quantize_dcase_ae()
    print("\nDone.")
