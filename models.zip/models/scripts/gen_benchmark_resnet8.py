"""
Generator for ResNet-8, the reference "image classification" model of the
MLPerf Tiny benchmark suite (https://github.com/mlcommons/tiny -- the
"resnet" reference model, itself the standard CIFAR-10 parametrization of
He et al.'s ResNet-v1 family with depth = 6n+2, n=1, i.e. 8 weighted
layers), trained on the real CIFAR-10 dataset.

Topology:
  Input 32x32x3
  -> Conv 3x3, 16 filters, stride 1, BN, ReLU
  -> Stage 1 (16 filters, stride 1): 1 residual block (2x Conv3x3 + BN, ReLU)
  -> Stage 2 (32 filters, stride 2): 1 residual block (downsampling shortcut)
  -> Stage 3 (64 filters, stride 2): 1 residual block (downsampling shortcut)
  -> Global average pool -> Dense 10 -> Softmax

conv1 (1) + 3 stages x 2 convs (6) + final dense (1) = 8 weighted layers,
hence "ResNet-8". ~78k parameters, ~310 KB in float32 -- like LeNet-5,
this comfortably exceeds the "under 100 KB" soft budget on purpose: see
`scripts/gen_benchmark_quantize.py` for an int8 QDQ version that fits well
under it (~80 KB).

Requires:  pip install torch torchvision
Run:       python gen_benchmark_resnet8.py
"""
import os
import tempfile

import onnx
import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as T

from _common import io_entry, simplify_onnx_model, write_json_metadata

MODELS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATEGORY = "benchmarks"
DATA_DIR = os.path.join(tempfile.gettempdir(), "aidge_cifar10_data")

torch.manual_seed(0)

CLASSES = ["airplane", "automobile", "bird", "cat", "deer",
           "dog", "frog", "horse", "ship", "truck"]


class ResidualBlock(nn.Module):
    def __init__(self, in_ch, out_ch, stride):
        super().__init__()
        self.conv1 = nn.Conv2d(in_ch, out_ch, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_ch)
        self.conv2 = nn.Conv2d(out_ch, out_ch, 3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_ch)
        if stride != 1 or in_ch != out_ch:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1, stride=stride, bias=False),
                nn.BatchNorm2d(out_ch),
            )
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        h = torch.relu(self.bn1(self.conv1(x)))
        h = self.bn2(self.conv2(h))
        return torch.relu(h + self.shortcut(x))


class ResNet8(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 16, 3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(16)
        self.stage1 = ResidualBlock(16, 16, stride=1)
        self.stage2 = ResidualBlock(16, 32, stride=2)
        self.stage3 = ResidualBlock(32, 64, stride=2)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(64, num_classes)

    def forward(self, x):  # x: (N, 3, 32, 32), already normalized
        h = torch.relu(self.bn1(self.conv1(x)))
        h = self.stage1(h)
        h = self.stage2(h)
        h = self.stage3(h)
        h = self.gap(h).flatten(1)
        return self.fc(h)  # logits


class ExportWrapper(nn.Module):
    """Normalizes raw [0, 255] uint8-range pixels to the training
    distribution and adds Softmax, both inside the exported graph.
    """

    def __init__(self, base, mean, std):
        super().__init__()
        self.base = base
        self.register_buffer("mean", torch.tensor(mean).view(1, 3, 1, 1) * 255.0)
        self.register_buffer("std", torch.tensor(std).view(1, 3, 1, 1) * 255.0)

    def forward(self, x):  # x: (N, 3, 32, 32), raw [0, 255]
        x = (x - self.mean) / self.std
        return torch.softmax(self.base(x), dim=1)


MEAN = (0.4914, 0.4822, 0.4465)
STD = (0.2470, 0.2435, 0.2616)


def load_cifar10():
    train_ds = torchvision.datasets.CIFAR10(root=DATA_DIR, train=True, download=True)
    test_ds = torchvision.datasets.CIFAR10(root=DATA_DIR, train=False, download=True)
    x_train = torch.from_numpy(train_ds.data).permute(0, 3, 1, 2).float()  # (50000,3,32,32) 0-255
    y_train = torch.tensor(train_ds.targets, dtype=torch.long)
    x_test = torch.from_numpy(test_ds.data).permute(0, 3, 1, 2).float()
    y_test = torch.tensor(test_ds.targets, dtype=torch.long)
    return x_train, y_train, x_test, y_test


def normalize(x):
    mean = torch.tensor(MEAN).view(1, 3, 1, 1) * 255.0
    std = torch.tensor(STD).view(1, 3, 1, 1) * 255.0
    return (x - mean) / std


def evaluate(model, x, y, batch_size=1000):
    model.eval()
    correct = 0
    with torch.no_grad():
        for i in range(0, x.shape[0], batch_size):
            logits = model(normalize(x[i:i + batch_size]))
            correct += (logits.argmax(dim=1) == y[i:i + batch_size]).sum().item()
    model.train()
    return correct / x.shape[0]


def train(model, x_train, y_train, x_test, y_test, epochs=10, batch_size=128, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    loss_fn = nn.CrossEntropyLoss()
    n = x_train.shape[0]

    model.train()
    for epoch in range(epochs):
        perm = torch.randperm(n)
        # cheap augmentation: random horizontal flip (no extra deps)
        total_loss = 0.0
        for i in range(0, n, batch_size):
            idx = perm[i:i + batch_size]
            xb = x_train[idx]
            flip = torch.rand(xb.shape[0]) < 0.5
            xb = xb.clone()
            xb[flip] = xb[flip].flip(-1)
            xb, yb = normalize(xb), y_train[idx]
            optimizer.zero_grad()
            loss = loss_fn(model(xb), yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(idx)
        scheduler.step()
        test_acc = evaluate(model, x_test, y_test)
        print(f"epoch {epoch + 1}/{epochs}  train_loss={total_loss / n:.4f}  test_acc={test_acc:.4f}")

    return evaluate(model, x_test, y_test)


def export_model(model, test_acc, example_image, example_label):
    wrapper = ExportWrapper(model, MEAN, STD)
    wrapper.eval()

    out_dir = os.path.join(MODELS_DIR, CATEGORY)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "resnet8_cifar10.onnx")

    dummy = torch.zeros((1, 3, 32, 32), dtype=torch.float32)
    torch.onnx.export(
        wrapper, dummy, out_path,
        input_names=["input"], output_names=["output"],
        opset_version=17, dynamo=False, external_data=False,
    )

    doc = (
        f"ResNet-8, the MLPerf Tiny 'image classification' reference model (CIFAR-10 "
        f"ResNet-v1, depth 6n+2 with n=1: Conv-BN-ReLU stem, 3 residual stages at "
        f"16/32/64 filters, global average pool, dense+softmax), trained with PyTorch on "
        f"the real CIFAR-10 training set (50000 images, random horizontal flip "
        f"augmentation). Test accuracy={test_acc:.4f} on the official 10000-image test "
        f"set. ~78k parameters, ~310 KB float32 -- see resnet8_cifar10_int8.onnx for a "
        f"quantized version under 100 KB."
    )
    onnx_model = onnx.load(out_path)
    onnx_model = simplify_onnx_model(onnx_model)
    onnx_model.graph.doc_string = doc
    onnx_model.producer_name = "aidge-test-model-generator"
    onnx.checker.check_model(onnx_model)
    onnx.save(onnx_model, out_path)

    with torch.no_grad():
        example_out = wrapper(example_image).numpy()

    io_inputs = [io_entry(
        "input", [1, 3, 32, 32], "float32",
        "A single 32x32 RGB image, raw pixel values in [0, 255] (float32), layout "
        "(batch, channel, height, width), channel order RGB. Per-channel "
        "standardization (CIFAR-10 mean/std) happens inside the graph (Sub, Div nodes).",
        example=example_image.numpy(),
    )]
    io_outputs = [io_entry(
        "output", [1, 10], "float32",
        f"Softmax probabilities over the 10 CIFAR-10 classes, in class-index order: "
        f"{CLASSES}. Predicted class = argmax. (Example input above is a real test-set "
        f"'{example_label}'.)",
        example=example_out,
    )]
    write_json_metadata(out_path, doc, io_inputs, io_outputs)

    size_kb = os.path.getsize(out_path) / 1024
    print(f"[{CATEGORY}] resnet8_cifar10.onnx  {size_kb:.1f} KB  - {doc}")


if __name__ == "__main__":
    x_train, y_train, x_test, y_test = load_cifar10()
    print(f"CIFAR-10 loaded: {x_train.shape[0]} train / {x_test.shape[0]} test images")

    model = ResNet8()
    test_acc = train(model, x_train, y_train, x_test, y_test, epochs=10)

    example_idx = int((y_test == CLASSES.index("cat")).nonzero()[0].item())
    export_model(model, test_acc, x_test[example_idx:example_idx + 1],
                 CLASSES[y_test[example_idx].item()])

    print("\nDone.")
