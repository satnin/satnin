"""
Generator for the DCASE Challenge Task 2 baseline autoencoder (anomalous
sound detection for machine condition monitoring -- see
https://dcase.community/challenge2020/task-unsupervised-detection-of-anomalous-sound-events,
baseline system description), the standard literature reference for
unsupervised, reconstruction-error-based anomaly detection on embedded /
edge audio.

Unlike the other `benchmarks/` models, this one is trained on SYNTHETIC
proxy data, not the real DCASE dataset (MIMII / ToyADMOS): that dataset is
tens of GB, far too large to fetch in this environment. The synthetic data
mimics the shape of the real input (5 stacked frames of 128-band log-mel
spectrogram = 640-dim vectors) with a "normal machine hum" cluster the
autoencoder learns to reconstruct well, and "anomalous" outliers it does
not -- enough to demonstrate the real published architecture and its
reconstruction-error decision rule, but the weights themselves are NOT a
real anomaly detector. See `real_world/` for models trained on
domain-realistic (if still synthetic) sensor data, and the other
`benchmarks/` models for ones trained on real public datasets.

Architecture (dense autoencoder, matching the DCASE 2020 baseline):
  Input 640 (5 frames x 128 mel bins)
  Encoder: Dense 128 -> BN -> ReLU  (x4, bottleneck-ward: 128,128,128,128)
  Bottleneck: Dense 8
  Decoder: Dense 128 -> BN -> ReLU  (x4)
  Output: Dense 640 (reconstruction)

Anomaly score = mean squared reconstruction error; a fixed or calibrated
threshold on that score is the actual detector (not part of the ONNX
graph, which just outputs the reconstruction).

Requires:  pip install torch
Run:       python gen_benchmark_dcase_ae.py
"""
import os

import numpy as np
import onnx
import torch
import torch.nn as nn

from _common import io_entry, simplify_onnx_model, write_json_metadata

MODELS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATEGORY = "benchmarks"

INPUT_DIM = 640  # 5 frames x 128 mel bins, per the DCASE baseline
HIDDEN = 128
BOTTLENECK = 8

torch.manual_seed(0)


class DCaseBaselineAE(nn.Module):
    def __init__(self, input_dim=INPUT_DIM, hidden=HIDDEN, bottleneck=BOTTLENECK):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden), nn.BatchNorm1d(hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.BatchNorm1d(hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.BatchNorm1d(hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.BatchNorm1d(hidden), nn.ReLU(),
            nn.Linear(hidden, bottleneck),
        )
        self.decoder = nn.Sequential(
            nn.Linear(bottleneck, hidden), nn.BatchNorm1d(hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.BatchNorm1d(hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.BatchNorm1d(hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.BatchNorm1d(hidden), nn.ReLU(),
            nn.Linear(hidden, input_dim),
        )

    def forward(self, x):
        return self.decoder(self.encoder(x))


def make_synthetic_data(n=4000, seed=0):
    """A cluster of correlated, smoothly-varying 'normal machine hum'
    log-mel-like vectors (built from a handful of random smooth basis
    functions, like a real spectral envelope would be), plus a smaller,
    more scattered set of 'anomalous' vectors the autoencoder never trains
    on -- used only to sanity-check that reconstruction error separates
    the two, not to claim a real detector.
    """
    rng = np.random.default_rng(seed)
    n_basis = 12
    t = np.linspace(0, 1, INPUT_DIM)
    basis = np.stack([np.sin(2 * np.pi * (k + 1) * t + rng.uniform(0, 2 * np.pi))
                       for k in range(n_basis)], axis=0)  # (n_basis, INPUT_DIM)

    coeffs_normal = rng.normal(0, 1.0, (n, n_basis))
    x_normal = coeffs_normal @ basis
    x_normal += rng.normal(0, 0.1, x_normal.shape)
    x_normal = (x_normal - x_normal.mean()) / x_normal.std()

    n_anom = n // 8
    coeffs_anom = rng.normal(0, 1.0, (n_anom, n_basis)) * rng.uniform(2.5, 4.0, (n_anom, 1))
    x_anom = coeffs_anom @ basis + rng.normal(0, 0.6, (n_anom, INPUT_DIM))
    x_anom = (x_anom - x_normal.mean()) / x_normal.std()  # same normalization as "normal"

    return (torch.as_tensor(x_normal, dtype=torch.float32),
            torch.as_tensor(x_anom, dtype=torch.float32))


def train(model, x_train, epochs=60, batch_size=128, lr=1e-3):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    n = x_train.shape[0]

    model.train()
    for epoch in range(epochs):
        perm = torch.randperm(n)
        total_loss = 0.0
        for i in range(0, n, batch_size):
            xb = x_train[perm[i:i + batch_size]]
            optimizer.zero_grad()
            loss = loss_fn(model(xb), xb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(xb)
        if (epoch + 1) % 10 == 0 or epoch == 0:
            print(f"  epoch {epoch + 1}/{epochs}  recon_mse={total_loss / n:.4f}")

    return total_loss / n


def reconstruction_error(model, x, batch_size=256):
    model.eval()
    errs = []
    with torch.no_grad():
        for i in range(0, x.shape[0], batch_size):
            xb = x[i:i + batch_size]
            recon = model(xb)
            errs.append(((recon - xb) ** 2).mean(dim=1))
    model.train()
    return torch.cat(errs)


if __name__ == "__main__":
    x_normal, x_anom = make_synthetic_data()
    n_train = int(len(x_normal) * 0.8)
    x_train, x_val_normal = x_normal[:n_train], x_normal[n_train:]
    print(f"Synthetic data: {len(x_train)} train / {len(x_val_normal)} val-normal / {len(x_anom)} anomalous")

    model = DCaseBaselineAE()
    n_params = sum(p.numel() for p in model.parameters())
    print(f"Parameter count: {n_params}")

    final_mse = train(model, x_train, epochs=60)

    err_normal = reconstruction_error(model, x_val_normal)
    err_anom = reconstruction_error(model, x_anom)
    auc_proxy = (err_anom.mean() / err_normal.mean()).item()
    print(f"Held-out normal recon MSE: {err_normal.mean():.4f}  |  "
          f"Anomalous recon MSE: {err_anom.mean():.4f}  |  ratio: {auc_proxy:.2f}x")

    model.eval()
    out_dir = os.path.join(MODELS_DIR, CATEGORY)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "dcase_baseline_autoencoder.onnx")

    dummy = torch.zeros((1, INPUT_DIM), dtype=torch.float32)
    torch.onnx.export(
        model, dummy, out_path,
        input_names=["input"], output_names=["output"],
        opset_version=17, dynamo=False, external_data=False,
    )

    doc = (
        f"DCASE Challenge Task 2 baseline autoencoder architecture (unsupervised "
        f"anomalous-machine-sound detection): dense encoder 640-128-128-128-128-8, "
        f"dense decoder 8-128-128-128-128-640, BatchNorm+ReLU between layers. "
        f"{n_params} parameters. IMPORTANT: trained on SYNTHETIC proxy data (smooth "
        f"random-basis 'normal hum' vectors vs. scattered 'anomalous' outliers), NOT the "
        f"real DCASE/MIMII/ToyADMOS dataset (tens of GB, not fetched in this "
        f"environment) -- this is a structurally faithful benchmark of the published "
        f"architecture, not a working anomaly detector. On the synthetic validation "
        f"split, mean reconstruction MSE was {err_normal.mean():.4f} for normal vs. "
        f"{err_anom.mean():.4f} for anomalous data ({auc_proxy:.1f}x higher), showing "
        f"the reconstruction-error decision rule behaves as expected on this proxy task."
    )
    onnx_model = onnx.load(out_path)
    onnx_model = simplify_onnx_model(onnx_model)
    onnx_model.graph.doc_string = doc
    onnx_model.producer_name = "aidge-test-model-generator"
    onnx.checker.check_model(onnx_model)
    onnx.save(onnx_model, out_path)

    example_input = x_anom[:1]
    with torch.no_grad():
        example_output = model(example_input).numpy()

    io_inputs = [io_entry(
        "input", [1, INPUT_DIM], "float32",
        "5 stacked frames of a 128-band log-mel spectrogram (640 = 5x128), flattened "
        "to a single feature vector, per the DCASE baseline's own front end. Feature "
        "extraction happens upstream; this graph only covers the autoencoder. "
        "SYNTHETIC example (see model description) -- not a real machine-sound frame.",
        example=example_input.numpy(),
    )]
    io_outputs = [io_entry(
        "output", [1, INPUT_DIM], "float32",
        "Reconstruction of the input vector. The anomaly score is the mean squared "
        "error between input and output (not computed inside this graph); a high "
        "error indicates a sound pattern the autoencoder wasn't trained to reproduce.",
        example=example_output,
    )]
    write_json_metadata(out_path, doc, io_inputs, io_outputs)

    size_kb = os.path.getsize(out_path) / 1024
    print(f"\n[{CATEGORY}] dcase_baseline_autoencoder.onnx  {size_kb:.1f} KB  - {doc}")
    print("\nDone.")
