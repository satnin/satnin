#ifndef _DIV_0_INPUT_0_H
#define _DIV_0_INPUT_0_H
#include <stdint.h>
#include <complex>

using namespace std::complex_literals;

 static const float _Div_0_input_0[1*28*28*1] __attribute__((section(".nn_data_dtype.float32"))) = {

};
#endif /* _DIV_0_INPUT_0_H */
