
#include <stdint.h>

#include "forward.hpp"

// Layer & memory configurations

#include "kernels/cpp/convolution.hpp"
#include "layers/_PadConvAct_0_biases.h"
#include "parameters/_PadConvAct_1_weights.hpp"
#include "layers/Constant_output_0.h"
#include "parameters/_PadConvAct_0_weights.hpp"
#include "layers/_PadConvAct_1_biases.h"
#include "layers/_PadConvAct_1_weights.h"
#include "layers/_MaxPooling2D_1.h"
#include "layers/_FCAct_0_biases.h"
#include "layers/_PadConvAct_1.h"
#include "layers/_Div_0.h"
#include "layers/_FCAct_0.h"
#include "kernels/cpp/pooling.hpp"
#include "kernels/cpp/softmax.hpp"
#include "layers/_FC_0.h"
#include "parameters/_FC_0_biases.hpp"
#include "parameters/_FC_0_weights.hpp"
#include "parameters/Constant_output_0.hpp"
#include "kernels/cpp/elemwise.hpp"
#include "layers/_MaxPooling2D_0.h"
#include "parameters/_FCAct_0_biases.hpp"
#include "layers/_FC_0_weights.h"
#include "parameters/_PadConvAct_1_biases.hpp"
#include "layers/_PadConvAct_0_weights.h"
#include "layers/_PadConvAct_0.h"
#include "layers/_Softmax_0.h"
#include "kernels/cpp/fullyconnected.hpp"
#include "layers/_FCAct_0_post_reshape_1.h"
#include "parameters/_PadConvAct_0_biases.hpp"
#include "layers/_FC_0_biases.h"
#include "parameters/_FCAct_0_post_reshape_1.hpp"

// Memory block
static unsigned char mem[34496];

void model_forward (const float* _Div_0_input_0,float** _Softmax_0_output_0_ptr)
{
    

    float* _Div_0_output_0 = (float*) (mem + _DIV_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::elemwise_forward<_DIV_0_NB_MAT,
                                 _DIV_0_ELEM_OP,
                                 _DIV_0_INPUT1_CONT_SIZE,
                                 _DIV_0_INPUT2_CONT_SIZE,
                                 _DIV_0_OUTPUT_CONT_SIZE,
                                 _DIV_0_OFFSET_IN1,
                                 _DIV_0_OFFSET_IN2,
                                 _DIV_0_ACTIVATION,
                                 _DIV_0_INPUT_0_MEM_CONT_OFFSET,
                                 _DIV_0_INPUT_0_MEM_CONT_SIZE,
                                 _DIV_0_INPUT_0_MEM_WRAP_OFFSET,
                                 _DIV_0_INPUT_0_MEM_WRAP_SIZE,
                                 _DIV_0_INPUT_0_MEM_STRIDE,
                                 CONSTANT_OUTPUT_0_OUTPUT_0_MEM_CONT_OFFSET,
                                 CONSTANT_OUTPUT_0_OUTPUT_0_MEM_CONT_SIZE,
                                 CONSTANT_OUTPUT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                 CONSTANT_OUTPUT_0_OUTPUT_0_MEM_WRAP_SIZE,
                                 CONSTANT_OUTPUT_0_OUTPUT_0_MEM_STRIDE,
                                 _DIV_0_OUTPUT_0_MEM_CONT_OFFSET,
                                 _DIV_0_OUTPUT_0_MEM_CONT_SIZE,
                                 _DIV_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                 _DIV_0_OUTPUT_0_MEM_WRAP_SIZE,
                                 _DIV_0_OUTPUT_0_MEM_STRIDE,
                                 float>
                                 (_Div_0_output_0, _DIV_0_RESCALING, _Div_0_input_0, Constant_output_0_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _Div_0\n");
    FILE* _DIV_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_Div_0_output_0.txt", "w");
    export_cpp::saveOutputs<_DIV_0_OUTPUT_0_NB_OUTPUTS,
                            _DIV_0_OUTPUT_0_OUT_HEIGHT,
                            _DIV_0_OUTPUT_0_OUT_WIDTH,
                            _DIV_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _DIV_0_OUTPUT_0_MEM_CONT_SIZE,
                            _DIV_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _DIV_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _DIV_0_OUTPUT_0_DEV_FMT>
                            (_Div_0_output_0,
                            _DIV_0_OUTPUT_0_STREAM);
    fclose(_DIV_0_OUTPUT_0_STREAM);
    #endif




    

    float* _PadConvAct_0_output_0 = (float*) (mem + _PADCONVACT_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_forward<_DIV_0_OUTPUT_0_NB_CHANNELS,
                           _DIV_0_OUTPUT_0_IN_HEIGHT,
                           _DIV_0_OUTPUT_0_IN_WIDTH,
                           _PADCONVACT_0_OUTPUT_0_NB_OUTPUTS,
                           _PADCONVACT_0_OUTPUT_0_OUT_HEIGHT,
                           _PADCONVACT_0_OUTPUT_0_OUT_WIDTH,
                           _PADCONVACT_0_PADDING_Y,
                           _PADCONVACT_0_PADDING_X,
                           _PADCONVACT_0_STRIDE_Y,
                           _PADCONVACT_0_STRIDE_X,
                           _PADCONVACT_0_DILATION_Y,
                           _PADCONVACT_0_DILATION_X,
                           _PADCONVACT_0_KERNEL_HEIGHT,
                           _PADCONVACT_0_KERNEL_WIDTH,
                           _PADCONVACT_0_ACTIVATION,
                           _DIV_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _DIV_0_OUTPUT_0_MEM_CONT_SIZE,
                           _DIV_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _DIV_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _DIV_0_OUTPUT_0_MEM_STRIDE,
                           _PADCONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVACT_0_OUTPUT_0_MEM_STRIDE>
                           (_Div_0_output_0, _PadConvAct_0_output_0, _PadConvAct_0_weights_output_0, _PadConvAct_0_biases_output_0, _PADCONVACT_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _PadConvAct_0\n");
    FILE* _PADCONVACT_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_PadConvAct_0_output_0.txt", "w");
    export_cpp::saveOutputs<_PADCONVACT_0_OUTPUT_0_NB_OUTPUTS,
                            _PADCONVACT_0_OUTPUT_0_OUT_HEIGHT,
                            _PADCONVACT_0_OUTPUT_0_OUT_WIDTH,
                            _PADCONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _PADCONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                            _PADCONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _PADCONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _PADCONVACT_0_OUTPUT_0_DEV_FMT>
                            (_PadConvAct_0_output_0,
                            _PADCONVACT_0_OUTPUT_0_STREAM);
    fclose(_PADCONVACT_0_OUTPUT_0_STREAM);
    #endif




    

    float* _MaxPooling2D_0_output_0 = (float*) (mem + _MAXPOOLING2D_0_OUTPUT_0_MEM_OFFSET);
    int64_t* _MaxPooling2D_0_output_1 = (int64_t*) (mem + _MAXPOOLING2D_0_OUTPUT_1_MEM_OFFSET);

    export_cpp::pooling_forward<_PADCONVACT_0_OUTPUT_0_NB_CHANNELS,
                                _PADCONVACT_0_OUTPUT_0_IN_HEIGHT,
                                _PADCONVACT_0_OUTPUT_0_IN_WIDTH,
                                _MAXPOOLING2D_0_OUTPUT_0_NB_OUTPUTS,
                                _MAXPOOLING2D_0_OUTPUT_0_OUT_HEIGHT,
                                _MAXPOOLING2D_0_OUTPUT_0_OUT_WIDTH,
                                _MAXPOOLING2D_0_PADDING_Y,
                                _MAXPOOLING2D_0_PADDING_X,
                                _MAXPOOLING2D_0_STRIDE_Y,
                                _MAXPOOLING2D_0_STRIDE_X,
                                _MAXPOOLING2D_0_KERNEL_HEIGHT,
                                _MAXPOOLING2D_0_KERNEL_WIDTH,
                                _MAXPOOLING2D_0_POOLING_TYPE,
                                _MAXPOOLING2D_0_ACTIVATION,
                                _PADCONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _PADCONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                                _PADCONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _PADCONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _PADCONVACT_0_OUTPUT_0_MEM_STRIDE,
                                _MAXPOOLING2D_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _MAXPOOLING2D_0_OUTPUT_0_MEM_CONT_SIZE,
                                _MAXPOOLING2D_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _MAXPOOLING2D_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _MAXPOOLING2D_0_OUTPUT_0_MEM_STRIDE>
                                (_PadConvAct_0_output_0, _MaxPooling2D_0_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _MaxPooling2D_0\n");
    FILE* _MAXPOOLING2D_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_MaxPooling2D_0_output_0.txt", "w");
    export_cpp::saveOutputs<_MAXPOOLING2D_0_OUTPUT_0_NB_OUTPUTS,
                            _MAXPOOLING2D_0_OUTPUT_0_OUT_HEIGHT,
                            _MAXPOOLING2D_0_OUTPUT_0_OUT_WIDTH,
                            _MAXPOOLING2D_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _MAXPOOLING2D_0_OUTPUT_0_MEM_CONT_SIZE,
                            _MAXPOOLING2D_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _MAXPOOLING2D_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _MAXPOOLING2D_0_OUTPUT_0_DEV_FMT>
                            (_MaxPooling2D_0_output_0,
                            _MAXPOOLING2D_0_OUTPUT_0_STREAM);
    fclose(_MAXPOOLING2D_0_OUTPUT_0_STREAM);
    #endif




    

    float* _PadConvAct_1_output_0 = (float*) (mem + _PADCONVACT_1_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_forward<_MAXPOOLING2D_0_OUTPUT_0_NB_CHANNELS,
                           _MAXPOOLING2D_0_OUTPUT_0_IN_HEIGHT,
                           _MAXPOOLING2D_0_OUTPUT_0_IN_WIDTH,
                           _PADCONVACT_1_OUTPUT_0_NB_OUTPUTS,
                           _PADCONVACT_1_OUTPUT_0_OUT_HEIGHT,
                           _PADCONVACT_1_OUTPUT_0_OUT_WIDTH,
                           _PADCONVACT_1_PADDING_Y,
                           _PADCONVACT_1_PADDING_X,
                           _PADCONVACT_1_STRIDE_Y,
                           _PADCONVACT_1_STRIDE_X,
                           _PADCONVACT_1_DILATION_Y,
                           _PADCONVACT_1_DILATION_X,
                           _PADCONVACT_1_KERNEL_HEIGHT,
                           _PADCONVACT_1_KERNEL_WIDTH,
                           _PADCONVACT_1_ACTIVATION,
                           _MAXPOOLING2D_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _MAXPOOLING2D_0_OUTPUT_0_MEM_CONT_SIZE,
                           _MAXPOOLING2D_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _MAXPOOLING2D_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _MAXPOOLING2D_0_OUTPUT_0_MEM_STRIDE,
                           _PADCONVACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVACT_1_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVACT_1_OUTPUT_0_MEM_STRIDE>
                           (_MaxPooling2D_0_output_0, _PadConvAct_1_output_0, _PadConvAct_1_weights_output_0, _PadConvAct_1_biases_output_0, _PADCONVACT_1_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _PadConvAct_1\n");
    FILE* _PADCONVACT_1_OUTPUT_0_STREAM = fopen("data/export_outputs/_PadConvAct_1_output_0.txt", "w");
    export_cpp::saveOutputs<_PADCONVACT_1_OUTPUT_0_NB_OUTPUTS,
                            _PADCONVACT_1_OUTPUT_0_OUT_HEIGHT,
                            _PADCONVACT_1_OUTPUT_0_OUT_WIDTH,
                            _PADCONVACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                            _PADCONVACT_1_OUTPUT_0_MEM_CONT_SIZE,
                            _PADCONVACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                            _PADCONVACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                            _PADCONVACT_1_OUTPUT_0_DEV_FMT>
                            (_PadConvAct_1_output_0,
                            _PADCONVACT_1_OUTPUT_0_STREAM);
    fclose(_PADCONVACT_1_OUTPUT_0_STREAM);
    #endif




    

    float* _MaxPooling2D_1_output_0 = (float*) (mem + _MAXPOOLING2D_1_OUTPUT_0_MEM_OFFSET);
    int64_t* _MaxPooling2D_1_output_1 = (int64_t*) (mem + _MAXPOOLING2D_1_OUTPUT_1_MEM_OFFSET);

    export_cpp::pooling_forward<_PADCONVACT_1_OUTPUT_0_NB_CHANNELS,
                                _PADCONVACT_1_OUTPUT_0_IN_HEIGHT,
                                _PADCONVACT_1_OUTPUT_0_IN_WIDTH,
                                _MAXPOOLING2D_1_OUTPUT_0_NB_OUTPUTS,
                                _MAXPOOLING2D_1_OUTPUT_0_OUT_HEIGHT,
                                _MAXPOOLING2D_1_OUTPUT_0_OUT_WIDTH,
                                _MAXPOOLING2D_1_PADDING_Y,
                                _MAXPOOLING2D_1_PADDING_X,
                                _MAXPOOLING2D_1_STRIDE_Y,
                                _MAXPOOLING2D_1_STRIDE_X,
                                _MAXPOOLING2D_1_KERNEL_HEIGHT,
                                _MAXPOOLING2D_1_KERNEL_WIDTH,
                                _MAXPOOLING2D_1_POOLING_TYPE,
                                _MAXPOOLING2D_1_ACTIVATION,
                                _PADCONVACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                                _PADCONVACT_1_OUTPUT_0_MEM_CONT_SIZE,
                                _PADCONVACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                                _PADCONVACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                                _PADCONVACT_1_OUTPUT_0_MEM_STRIDE,
                                _MAXPOOLING2D_1_OUTPUT_0_MEM_CONT_OFFSET,
                                _MAXPOOLING2D_1_OUTPUT_0_MEM_CONT_SIZE,
                                _MAXPOOLING2D_1_OUTPUT_0_MEM_WRAP_OFFSET,
                                _MAXPOOLING2D_1_OUTPUT_0_MEM_WRAP_SIZE,
                                _MAXPOOLING2D_1_OUTPUT_0_MEM_STRIDE>
                                (_PadConvAct_1_output_0, _MaxPooling2D_1_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _MaxPooling2D_1\n");
    FILE* _MAXPOOLING2D_1_OUTPUT_0_STREAM = fopen("data/export_outputs/_MaxPooling2D_1_output_0.txt", "w");
    export_cpp::saveOutputs<_MAXPOOLING2D_1_OUTPUT_0_NB_OUTPUTS,
                            _MAXPOOLING2D_1_OUTPUT_0_OUT_HEIGHT,
                            _MAXPOOLING2D_1_OUTPUT_0_OUT_WIDTH,
                            _MAXPOOLING2D_1_OUTPUT_0_MEM_CONT_OFFSET,
                            _MAXPOOLING2D_1_OUTPUT_0_MEM_CONT_SIZE,
                            _MAXPOOLING2D_1_OUTPUT_0_MEM_WRAP_OFFSET,
                            _MAXPOOLING2D_1_OUTPUT_0_MEM_WRAP_SIZE,
                            _MAXPOOLING2D_1_OUTPUT_0_DEV_FMT>
                            (_MaxPooling2D_1_output_0,
                            _MAXPOOLING2D_1_OUTPUT_0_STREAM);
    fclose(_MAXPOOLING2D_1_OUTPUT_0_STREAM);
    #endif




    

    float* _FCAct_0_output_0 = (float*) (mem + _FCACT_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_forward<_MAXPOOLING2D_1_OUTPUT_0_IN_BATCH,
                              _MAXPOOLING2D_1_OUTPUT_0_NB_CHANNELS,
                              _MAXPOOLING2D_1_OUTPUT_0_IN_HEIGHT,
                              _MAXPOOLING2D_1_OUTPUT_0_IN_WIDTH,
                              _FCACT_0_OUTPUT_0_NB_OUTPUTS,
                              _FCACT_0_OUTPUT_0_OUT_HEIGHT,
                              _FCACT_0_OUTPUT_0_OUT_WIDTH,
                              _FCACT_0_ACTIVATION,
                              _MAXPOOLING2D_1_OUTPUT_0_MEM_CONT_OFFSET,
                              _MAXPOOLING2D_1_OUTPUT_0_MEM_CONT_SIZE,
                              _MAXPOOLING2D_1_OUTPUT_0_MEM_WRAP_OFFSET,
                              _MAXPOOLING2D_1_OUTPUT_0_MEM_WRAP_SIZE,
                              _MAXPOOLING2D_1_OUTPUT_0_MEM_STRIDE,
                              _FCACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                              _FCACT_0_OUTPUT_0_MEM_CONT_SIZE,
                              _FCACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FCACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                              _FCACT_0_OUTPUT_0_MEM_STRIDE>
                              (_MaxPooling2D_1_output_0, _FCAct_0_output_0, _FCAct_0_post_reshape_1_output_0, _FCAct_0_biases_output_0, _FCACT_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FCAct_0\n");
    FILE* _FCACT_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_FCAct_0_output_0.txt", "w");
    export_cpp::saveOutputs<_FCACT_0_OUTPUT_0_NB_OUTPUTS,
                            _FCACT_0_OUTPUT_0_OUT_HEIGHT,
                            _FCACT_0_OUTPUT_0_OUT_WIDTH,
                            _FCACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _FCACT_0_OUTPUT_0_MEM_CONT_SIZE,
                            _FCACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FCACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _FCACT_0_OUTPUT_0_DEV_FMT>
                            (_FCAct_0_output_0,
                            _FCACT_0_OUTPUT_0_STREAM);
    fclose(_FCACT_0_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_0_output_0 = (float*) (mem + _FC_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_FCACT_0_OUTPUT_0_IN_BATCH,
                              _FCACT_0_OUTPUT_0_NB_CHANNELS,
                              _FCACT_0_OUTPUT_0_IN_HEIGHT,
                              _FCACT_0_OUTPUT_0_IN_WIDTH,
                              _FC_0_OUTPUT_0_NB_OUTPUTS,
                              _FC_0_OUTPUT_0_OUT_HEIGHT,
                              _FC_0_OUTPUT_0_OUT_WIDTH,
                              _FC_0_ACTIVATION,
                              _FCACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                              _FCACT_0_OUTPUT_0_MEM_CONT_SIZE,
                              _FCACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FCACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                              _FCACT_0_OUTPUT_0_MEM_STRIDE,
                              _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_0_OUTPUT_0_MEM_STRIDE>
                              (_FCAct_0_output_0, _FC_0_output_0, _FC_0_weights_output_0, _FC_0_biases_output_0, _FC_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_0\n");
    FILE* _FC_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_0_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_0_OUTPUT_0_NB_OUTPUTS,
                            _FC_0_OUTPUT_0_OUT_HEIGHT,
                            _FC_0_OUTPUT_0_OUT_WIDTH,
                            _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_0_OUTPUT_0_DEV_FMT>
                            (_FC_0_output_0,
                            _FC_0_OUTPUT_0_STREAM);
    fclose(_FC_0_OUTPUT_0_STREAM);
    #endif




    

    float* _Softmax_0_output_0 = (float*) (mem + _SOFTMAX_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::softmax_forward<_SOFTMAX_0_AXIS_SIZE,
                                _SOFTMAX_0_AXIS_SIZE_POST,
                                _SOFTMAX_0_AXIS_SIZE_PRE,
                                _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                                _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _FC_0_OUTPUT_0_MEM_STRIDE,
                                _SOFTMAX_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _SOFTMAX_0_OUTPUT_0_MEM_CONT_SIZE,
                                _SOFTMAX_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _SOFTMAX_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _SOFTMAX_0_OUTPUT_0_MEM_STRIDE>
                                (_FC_0_output_0, _Softmax_0_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _Softmax_0\n");
    FILE* _SOFTMAX_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_Softmax_0_output_0.txt", "w");
    export_cpp::saveOutputs<_SOFTMAX_0_OUTPUT_0_NB_OUTPUTS,
                            _SOFTMAX_0_OUTPUT_0_OUT_HEIGHT,
                            _SOFTMAX_0_OUTPUT_0_OUT_WIDTH,
                            _SOFTMAX_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _SOFTMAX_0_OUTPUT_0_MEM_CONT_SIZE,
                            _SOFTMAX_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _SOFTMAX_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _SOFTMAX_0_OUTPUT_0_DEV_FMT>
                            (_Softmax_0_output_0,
                            _SOFTMAX_0_OUTPUT_0_STREAM);
    fclose(_SOFTMAX_0_OUTPUT_0_STREAM);
    #endif



    *_Softmax_0_output_0_ptr = _Softmax_0_output_0;
}
