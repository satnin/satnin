
#include <cstdint>
#include "parameters/_PadConvAct_1_biases.hpp"
#include <complex>

using namespace std::complex_literals;

const float _PadConvAct_1_biases_output_0[8] __attribute__((section(".nn_data_dtype.float32"))) =
{
-0.053961873054504395, 0.08050425350666046,0.026923909783363342, 0.07678017020225525, 0.04304385930299759, 0.04008159413933754,-0.030897358432412148,-0.018556954339146614,
};
