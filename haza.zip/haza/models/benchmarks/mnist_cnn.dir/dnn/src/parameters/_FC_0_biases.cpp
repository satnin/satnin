
#include <cstdint>
#include "parameters/_FC_0_biases.hpp"
#include <complex>

using namespace std::complex_literals;

const float _FC_0_biases_output_0[10] __attribute__((section(".nn_data_dtype.float32"))) =
{
 0.09482794255018234, 0.13200372457504272, 0.15039876103401184, 0.09927032887935638,-0.10483346879482269,  0.1813897341489792, 0.12309306859970093, -0.0719333291053772, 0.06368745118379593,-0.11867595463991165,
};
