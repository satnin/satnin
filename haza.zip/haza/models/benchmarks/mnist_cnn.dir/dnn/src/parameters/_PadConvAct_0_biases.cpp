
#include <cstdint>
#include "parameters/_PadConvAct_0_biases.hpp"
#include <complex>

using namespace std::complex_literals;

const float _PadConvAct_0_biases_output_0[8] __attribute__((section(".nn_data_dtype.float32"))) =
{
0.011340360157191753, 0.20933182537555695,0.007331902626901865,0.010221396572887897,0.010998573154211044, 0.06632901728153229,0.055774908512830734, 0.17146410048007965,
};
