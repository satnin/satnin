#ifndef _PADCONVACT_1_WEIGHTS_OUTPUT_0_H
#define _PADCONVACT_1_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _PadConvAct_1_weights_output_0[8*5*5*8];

#endif /* _PADCONVACT_1_WEIGHTS_OUTPUT_0_H */
