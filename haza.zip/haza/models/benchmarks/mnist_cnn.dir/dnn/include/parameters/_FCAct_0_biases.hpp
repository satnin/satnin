#ifndef _FCACT_0_BIASES_OUTPUT_0_H
#define _FCACT_0_BIASES_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FCAct_0_biases_output_0[32];

#endif /* _FCACT_0_BIASES_OUTPUT_0_H */
