#ifndef _FCACT_0_POST_RESHAPE_1_OUTPUT_0_H
#define _FCACT_0_POST_RESHAPE_1_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FCAct_0_post_reshape_1_output_0[32*392];

#endif /* _FCACT_0_POST_RESHAPE_1_OUTPUT_0_H */
