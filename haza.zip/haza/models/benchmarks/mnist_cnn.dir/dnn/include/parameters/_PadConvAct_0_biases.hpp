#ifndef _PADCONVACT_0_BIASES_OUTPUT_0_H
#define _PADCONVACT_0_BIASES_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _PadConvAct_0_biases_output_0[8];

#endif /* _PADCONVACT_0_BIASES_OUTPUT_0_H */
