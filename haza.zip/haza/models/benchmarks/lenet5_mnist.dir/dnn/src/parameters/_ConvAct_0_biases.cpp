
#include <cstdint>
#include "parameters/_ConvAct_0_biases.hpp"
#include <complex>

using namespace std::complex_literals;

const float _ConvAct_0_biases_output_0[6] __attribute__((section(".nn_data_dtype.float32"))) =
{
0.006708127446472645,-0.0033397225197404623,0.023005548864603043, 0.15160496532917023, 0.22591854631900787,0.0023865639232099056,
};
