
#include <cstdint>
#include "parameters/pad_Constant_8_output_0.hpp"
#include <complex>

using namespace std::complex_literals;

const float pad_Constant_8_output_0_output_0[] __attribute__((section(".nn_data_dtype.float32"))) =
{

};
