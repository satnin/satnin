
#include <cstdint>
#include "parameters/_FC_0_biases.hpp"
#include <complex>

using namespace std::complex_literals;

const float _FC_0_biases_output_0[10] __attribute__((section(".nn_data_dtype.float32"))) =
{
-0.05586712062358856,-0.09385290741920471, 0.05329320579767227, 0.07008035480976105,-0.06366086006164551, 0.07757960259914398,-0.11159853637218475, 0.04300158843398094, 0.06870415061712265, 0.10803724080324173,
};
