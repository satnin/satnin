
#include <cstdint>
#include "parameters/pad_Reshape_1_output_0.hpp"
#include <complex>

using namespace std::complex_literals;

const int64_t pad_Reshape_1_output_0_output_0[8] __attribute__((section(".nn_data_dtype.int64"))) =
{
                   0,                   2,                   2,                   0,                   0,                   2,                   2,                   0,
};
