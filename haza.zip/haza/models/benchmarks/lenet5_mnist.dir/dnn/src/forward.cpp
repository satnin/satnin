
#include <stdint.h>

#include "forward.hpp"

// Layer & memory configurations

#include "kernels/cpp/convolution.hpp"
#include "layers/pad_Reshape_1_output_0.h"
#include "layers/_ConvAct_1_biases.h"
#include "layers/_Pad_0.h"
#include "layers/Constant_output_0.h"
#include "parameters/pad_Reshape_1_output_0.hpp"
#include "parameters/_ConvAct_2_biases.hpp"
#include "layers/_AvgPooling2D_1.h"
#include "layers/_ConvAct_2.h"
#include "layers/_ConvAct_2_weights.h"
#include "layers/_FCAct_0_biases.h"
#include "layers/_FCAct_0.h"
#include "layers/_Div_0.h"
#include "layers/_ConvAct_2_biases.h"
#include "kernels/cpp/pooling.hpp"
#include "parameters/_ConvAct_0_weights.hpp"
#include "kernels/cpp/softmax.hpp"
#include "layers/_ConvAct_0.h"
#include "layers/_FCAct_0_weights.h"
#include "layers/_FC_0.h"
#include "parameters/_FC_0_biases.hpp"
#include "kernels/cpp/pad.hpp"
#include "parameters/_FC_0_weights.hpp"
#include "parameters/Constant_output_0.hpp"
#include "kernels/cpp/elemwise.hpp"
#include "parameters/_FCAct_0_biases.hpp"
#include "layers/_FC_0_weights.h"
#include "parameters/_ConvAct_1_weights.hpp"
#include "parameters/_ConvAct_2_weights.hpp"
#include "layers/_AvgPooling2D_0.h"
#include "parameters/_ConvAct_1_biases.hpp"
#include "parameters/pad_Constant_8_output_0.hpp"
#include "layers/_ConvAct_1.h"
#include "layers/_ConvAct_1_weights.h"
#include "layers/_ConvAct_0_weights.h"
#include "parameters/_FCAct_0_weights.hpp"
#include "layers/_ConvAct_0_biases.h"
#include "layers/_Softmax_0.h"
#include "kernels/cpp/fullyconnected.hpp"
#include "layers/_FC_0_biases.h"
#include "parameters/_ConvAct_0_biases.hpp"
#include "layers/pad_Constant_8_output_0.h"

// Memory block
static unsigned char mem[27008];

void model_forward (const float* _Pad_0_input_0,float** _Softmax_0_output_0_ptr)
{
    

    float* _Pad_0_output_0 = (float*) (mem + _PAD_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::pad_forward<_PAD_0_INPUT_0_IN_BATCH,
                            _PAD_0_INPUT_0_NB_CHANNELS,
                            _PAD_0_INPUT_0_IN_HEIGHT,
                            _PAD_0_INPUT_0_IN_WIDTH,
                            _PAD_0_OUTPUT_0_NB_OUTPUTS,
                            _PAD_0_OUTPUT_0_OUT_HEIGHT,
                            _PAD_0_OUTPUT_0_OUT_WIDTH,
                            _PAD_0_PADDING_TOP,
                            _PAD_0_PADDING_LEFT,
                            _PAD_0_PADDING_BOTTOM,
                            _PAD_0_PADDING_RIGHT>
                            (_PAD_0_CONSTANT_VALUE, _Pad_0_input_0, _Pad_0_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _Pad_0\n");
    FILE* _PAD_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_Pad_0_output_0.txt", "w");
    export_cpp::saveOutputs<_PAD_0_OUTPUT_0_NB_OUTPUTS,
                            _PAD_0_OUTPUT_0_OUT_HEIGHT,
                            _PAD_0_OUTPUT_0_OUT_WIDTH,
                            _PAD_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _PAD_0_OUTPUT_0_MEM_CONT_SIZE,
                            _PAD_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _PAD_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _PAD_0_OUTPUT_0_DEV_FMT>
                            (_Pad_0_output_0,
                            _PAD_0_OUTPUT_0_STREAM);
    fclose(_PAD_0_OUTPUT_0_STREAM);
    #endif



    

    float* _Div_0_output_0 = (float*) (mem + _DIV_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::elemwise_forward<_DIV_0_NB_MAT,
                                 _DIV_0_ELEM_OP,
                                 _DIV_0_INPUT1_CONT_SIZE,
                                 _DIV_0_INPUT2_CONT_SIZE,
                                 _DIV_0_OUTPUT_CONT_SIZE,
                                 _DIV_0_OFFSET_IN1,
                                 _DIV_0_OFFSET_IN2,
                                 _DIV_0_ACTIVATION,
                                 _PAD_0_OUTPUT_0_MEM_CONT_OFFSET,
                                 _PAD_0_OUTPUT_0_MEM_CONT_SIZE,
                                 _PAD_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                 _PAD_0_OUTPUT_0_MEM_WRAP_SIZE,
                                 _PAD_0_OUTPUT_0_MEM_STRIDE,
                                 CONSTANT_OUTPUT_0_OUTPUT_0_MEM_CONT_OFFSET,
                                 CONSTANT_OUTPUT_0_OUTPUT_0_MEM_CONT_SIZE,
                                 CONSTANT_OUTPUT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                 CONSTANT_OUTPUT_0_OUTPUT_0_MEM_WRAP_SIZE,
                                 CONSTANT_OUTPUT_0_OUTPUT_0_MEM_STRIDE,
                                 _DIV_0_OUTPUT_0_MEM_CONT_OFFSET,
                                 _DIV_0_OUTPUT_0_MEM_CONT_SIZE,
                                 _DIV_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                 _DIV_0_OUTPUT_0_MEM_WRAP_SIZE,
                                 _DIV_0_OUTPUT_0_MEM_STRIDE,
                                 float>
                                 (_Div_0_output_0, _DIV_0_RESCALING, _Pad_0_output_0, Constant_output_0_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _Div_0\n");
    FILE* _DIV_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_Div_0_output_0.txt", "w");
    export_cpp::saveOutputs<_DIV_0_OUTPUT_0_NB_OUTPUTS,
                            _DIV_0_OUTPUT_0_OUT_HEIGHT,
                            _DIV_0_OUTPUT_0_OUT_WIDTH,
                            _DIV_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _DIV_0_OUTPUT_0_MEM_CONT_SIZE,
                            _DIV_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _DIV_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _DIV_0_OUTPUT_0_DEV_FMT>
                            (_Div_0_output_0,
                            _DIV_0_OUTPUT_0_STREAM);
    fclose(_DIV_0_OUTPUT_0_STREAM);
    #endif




    

    float* _ConvAct_0_output_0 = (float*) (mem + _CONVACT_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_forward<_DIV_0_OUTPUT_0_NB_CHANNELS,
                           _DIV_0_OUTPUT_0_IN_HEIGHT,
                           _DIV_0_OUTPUT_0_IN_WIDTH,
                           _CONVACT_0_OUTPUT_0_NB_OUTPUTS,
                           _CONVACT_0_OUTPUT_0_OUT_HEIGHT,
                           _CONVACT_0_OUTPUT_0_OUT_WIDTH,
                           _CONVACT_0_PADDING_Y,
                           _CONVACT_0_PADDING_X,
                           _CONVACT_0_STRIDE_Y,
                           _CONVACT_0_STRIDE_X,
                           _CONVACT_0_DILATION_Y,
                           _CONVACT_0_DILATION_X,
                           _CONVACT_0_KERNEL_HEIGHT,
                           _CONVACT_0_KERNEL_WIDTH,
                           _CONVACT_0_ACTIVATION,
                           _DIV_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _DIV_0_OUTPUT_0_MEM_CONT_SIZE,
                           _DIV_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _DIV_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _DIV_0_OUTPUT_0_MEM_STRIDE,
                           _CONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _CONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                           _CONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _CONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _CONVACT_0_OUTPUT_0_MEM_STRIDE>
                           (_Div_0_output_0, _ConvAct_0_output_0, _ConvAct_0_weights_output_0, _ConvAct_0_biases_output_0, _CONVACT_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ConvAct_0\n");
    FILE* _CONVACT_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_ConvAct_0_output_0.txt", "w");
    export_cpp::saveOutputs<_CONVACT_0_OUTPUT_0_NB_OUTPUTS,
                            _CONVACT_0_OUTPUT_0_OUT_HEIGHT,
                            _CONVACT_0_OUTPUT_0_OUT_WIDTH,
                            _CONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _CONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                            _CONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _CONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _CONVACT_0_OUTPUT_0_DEV_FMT>
                            (_ConvAct_0_output_0,
                            _CONVACT_0_OUTPUT_0_STREAM);
    fclose(_CONVACT_0_OUTPUT_0_STREAM);
    #endif




    

    float* _AvgPooling2D_0_output_0 = (float*) (mem + _AVGPOOLING2D_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::pooling_forward<_CONVACT_0_OUTPUT_0_NB_CHANNELS,
                                _CONVACT_0_OUTPUT_0_IN_HEIGHT,
                                _CONVACT_0_OUTPUT_0_IN_WIDTH,
                                _AVGPOOLING2D_0_OUTPUT_0_NB_OUTPUTS,
                                _AVGPOOLING2D_0_OUTPUT_0_OUT_HEIGHT,
                                _AVGPOOLING2D_0_OUTPUT_0_OUT_WIDTH,
                                _AVGPOOLING2D_0_PADDING_Y,
                                _AVGPOOLING2D_0_PADDING_X,
                                _AVGPOOLING2D_0_STRIDE_Y,
                                _AVGPOOLING2D_0_STRIDE_X,
                                _AVGPOOLING2D_0_KERNEL_HEIGHT,
                                _AVGPOOLING2D_0_KERNEL_WIDTH,
                                _AVGPOOLING2D_0_POOLING_TYPE,
                                _AVGPOOLING2D_0_ACTIVATION,
                                _CONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _CONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                                _CONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _CONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _CONVACT_0_OUTPUT_0_MEM_STRIDE,
                                _AVGPOOLING2D_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _AVGPOOLING2D_0_OUTPUT_0_MEM_CONT_SIZE,
                                _AVGPOOLING2D_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _AVGPOOLING2D_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _AVGPOOLING2D_0_OUTPUT_0_MEM_STRIDE>
                                (_ConvAct_0_output_0, _AvgPooling2D_0_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _AvgPooling2D_0\n");
    FILE* _AVGPOOLING2D_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_AvgPooling2D_0_output_0.txt", "w");
    export_cpp::saveOutputs<_AVGPOOLING2D_0_OUTPUT_0_NB_OUTPUTS,
                            _AVGPOOLING2D_0_OUTPUT_0_OUT_HEIGHT,
                            _AVGPOOLING2D_0_OUTPUT_0_OUT_WIDTH,
                            _AVGPOOLING2D_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _AVGPOOLING2D_0_OUTPUT_0_MEM_CONT_SIZE,
                            _AVGPOOLING2D_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _AVGPOOLING2D_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _AVGPOOLING2D_0_OUTPUT_0_DEV_FMT>
                            (_AvgPooling2D_0_output_0,
                            _AVGPOOLING2D_0_OUTPUT_0_STREAM);
    fclose(_AVGPOOLING2D_0_OUTPUT_0_STREAM);
    #endif




    

    float* _ConvAct_1_output_0 = (float*) (mem + _CONVACT_1_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_forward<_AVGPOOLING2D_0_OUTPUT_0_NB_CHANNELS,
                           _AVGPOOLING2D_0_OUTPUT_0_IN_HEIGHT,
                           _AVGPOOLING2D_0_OUTPUT_0_IN_WIDTH,
                           _CONVACT_1_OUTPUT_0_NB_OUTPUTS,
                           _CONVACT_1_OUTPUT_0_OUT_HEIGHT,
                           _CONVACT_1_OUTPUT_0_OUT_WIDTH,
                           _CONVACT_1_PADDING_Y,
                           _CONVACT_1_PADDING_X,
                           _CONVACT_1_STRIDE_Y,
                           _CONVACT_1_STRIDE_X,
                           _CONVACT_1_DILATION_Y,
                           _CONVACT_1_DILATION_X,
                           _CONVACT_1_KERNEL_HEIGHT,
                           _CONVACT_1_KERNEL_WIDTH,
                           _CONVACT_1_ACTIVATION,
                           _AVGPOOLING2D_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _AVGPOOLING2D_0_OUTPUT_0_MEM_CONT_SIZE,
                           _AVGPOOLING2D_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _AVGPOOLING2D_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _AVGPOOLING2D_0_OUTPUT_0_MEM_STRIDE,
                           _CONVACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                           _CONVACT_1_OUTPUT_0_MEM_CONT_SIZE,
                           _CONVACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                           _CONVACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                           _CONVACT_1_OUTPUT_0_MEM_STRIDE>
                           (_AvgPooling2D_0_output_0, _ConvAct_1_output_0, _ConvAct_1_weights_output_0, _ConvAct_1_biases_output_0, _CONVACT_1_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ConvAct_1\n");
    FILE* _CONVACT_1_OUTPUT_0_STREAM = fopen("data/export_outputs/_ConvAct_1_output_0.txt", "w");
    export_cpp::saveOutputs<_CONVACT_1_OUTPUT_0_NB_OUTPUTS,
                            _CONVACT_1_OUTPUT_0_OUT_HEIGHT,
                            _CONVACT_1_OUTPUT_0_OUT_WIDTH,
                            _CONVACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                            _CONVACT_1_OUTPUT_0_MEM_CONT_SIZE,
                            _CONVACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                            _CONVACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                            _CONVACT_1_OUTPUT_0_DEV_FMT>
                            (_ConvAct_1_output_0,
                            _CONVACT_1_OUTPUT_0_STREAM);
    fclose(_CONVACT_1_OUTPUT_0_STREAM);
    #endif




    

    float* _AvgPooling2D_1_output_0 = (float*) (mem + _AVGPOOLING2D_1_OUTPUT_0_MEM_OFFSET);

    export_cpp::pooling_forward<_CONVACT_1_OUTPUT_0_NB_CHANNELS,
                                _CONVACT_1_OUTPUT_0_IN_HEIGHT,
                                _CONVACT_1_OUTPUT_0_IN_WIDTH,
                                _AVGPOOLING2D_1_OUTPUT_0_NB_OUTPUTS,
                                _AVGPOOLING2D_1_OUTPUT_0_OUT_HEIGHT,
                                _AVGPOOLING2D_1_OUTPUT_0_OUT_WIDTH,
                                _AVGPOOLING2D_1_PADDING_Y,
                                _AVGPOOLING2D_1_PADDING_X,
                                _AVGPOOLING2D_1_STRIDE_Y,
                                _AVGPOOLING2D_1_STRIDE_X,
                                _AVGPOOLING2D_1_KERNEL_HEIGHT,
                                _AVGPOOLING2D_1_KERNEL_WIDTH,
                                _AVGPOOLING2D_1_POOLING_TYPE,
                                _AVGPOOLING2D_1_ACTIVATION,
                                _CONVACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                                _CONVACT_1_OUTPUT_0_MEM_CONT_SIZE,
                                _CONVACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                                _CONVACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                                _CONVACT_1_OUTPUT_0_MEM_STRIDE,
                                _AVGPOOLING2D_1_OUTPUT_0_MEM_CONT_OFFSET,
                                _AVGPOOLING2D_1_OUTPUT_0_MEM_CONT_SIZE,
                                _AVGPOOLING2D_1_OUTPUT_0_MEM_WRAP_OFFSET,
                                _AVGPOOLING2D_1_OUTPUT_0_MEM_WRAP_SIZE,
                                _AVGPOOLING2D_1_OUTPUT_0_MEM_STRIDE>
                                (_ConvAct_1_output_0, _AvgPooling2D_1_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _AvgPooling2D_1\n");
    FILE* _AVGPOOLING2D_1_OUTPUT_0_STREAM = fopen("data/export_outputs/_AvgPooling2D_1_output_0.txt", "w");
    export_cpp::saveOutputs<_AVGPOOLING2D_1_OUTPUT_0_NB_OUTPUTS,
                            _AVGPOOLING2D_1_OUTPUT_0_OUT_HEIGHT,
                            _AVGPOOLING2D_1_OUTPUT_0_OUT_WIDTH,
                            _AVGPOOLING2D_1_OUTPUT_0_MEM_CONT_OFFSET,
                            _AVGPOOLING2D_1_OUTPUT_0_MEM_CONT_SIZE,
                            _AVGPOOLING2D_1_OUTPUT_0_MEM_WRAP_OFFSET,
                            _AVGPOOLING2D_1_OUTPUT_0_MEM_WRAP_SIZE,
                            _AVGPOOLING2D_1_OUTPUT_0_DEV_FMT>
                            (_AvgPooling2D_1_output_0,
                            _AVGPOOLING2D_1_OUTPUT_0_STREAM);
    fclose(_AVGPOOLING2D_1_OUTPUT_0_STREAM);
    #endif




    

    float* _ConvAct_2_output_0 = (float*) (mem + _CONVACT_2_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_forward<_AVGPOOLING2D_1_OUTPUT_0_NB_CHANNELS,
                           _AVGPOOLING2D_1_OUTPUT_0_IN_HEIGHT,
                           _AVGPOOLING2D_1_OUTPUT_0_IN_WIDTH,
                           _CONVACT_2_OUTPUT_0_NB_OUTPUTS,
                           _CONVACT_2_OUTPUT_0_OUT_HEIGHT,
                           _CONVACT_2_OUTPUT_0_OUT_WIDTH,
                           _CONVACT_2_PADDING_Y,
                           _CONVACT_2_PADDING_X,
                           _CONVACT_2_STRIDE_Y,
                           _CONVACT_2_STRIDE_X,
                           _CONVACT_2_DILATION_Y,
                           _CONVACT_2_DILATION_X,
                           _CONVACT_2_KERNEL_HEIGHT,
                           _CONVACT_2_KERNEL_WIDTH,
                           _CONVACT_2_ACTIVATION,
                           _AVGPOOLING2D_1_OUTPUT_0_MEM_CONT_OFFSET,
                           _AVGPOOLING2D_1_OUTPUT_0_MEM_CONT_SIZE,
                           _AVGPOOLING2D_1_OUTPUT_0_MEM_WRAP_OFFSET,
                           _AVGPOOLING2D_1_OUTPUT_0_MEM_WRAP_SIZE,
                           _AVGPOOLING2D_1_OUTPUT_0_MEM_STRIDE,
                           _CONVACT_2_OUTPUT_0_MEM_CONT_OFFSET,
                           _CONVACT_2_OUTPUT_0_MEM_CONT_SIZE,
                           _CONVACT_2_OUTPUT_0_MEM_WRAP_OFFSET,
                           _CONVACT_2_OUTPUT_0_MEM_WRAP_SIZE,
                           _CONVACT_2_OUTPUT_0_MEM_STRIDE>
                           (_AvgPooling2D_1_output_0, _ConvAct_2_output_0, _ConvAct_2_weights_output_0, _ConvAct_2_biases_output_0, _CONVACT_2_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ConvAct_2\n");
    FILE* _CONVACT_2_OUTPUT_0_STREAM = fopen("data/export_outputs/_ConvAct_2_output_0.txt", "w");
    export_cpp::saveOutputs<_CONVACT_2_OUTPUT_0_NB_OUTPUTS,
                            _CONVACT_2_OUTPUT_0_OUT_HEIGHT,
                            _CONVACT_2_OUTPUT_0_OUT_WIDTH,
                            _CONVACT_2_OUTPUT_0_MEM_CONT_OFFSET,
                            _CONVACT_2_OUTPUT_0_MEM_CONT_SIZE,
                            _CONVACT_2_OUTPUT_0_MEM_WRAP_OFFSET,
                            _CONVACT_2_OUTPUT_0_MEM_WRAP_SIZE,
                            _CONVACT_2_OUTPUT_0_DEV_FMT>
                            (_ConvAct_2_output_0,
                            _CONVACT_2_OUTPUT_0_STREAM);
    fclose(_CONVACT_2_OUTPUT_0_STREAM);
    #endif




    

    float* _FCAct_0_output_0 = (float*) (mem + _FCACT_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_transpose_forward<_CONVACT_2_OUTPUT_0_IN_BATCH,
                              _CONVACT_2_OUTPUT_0_NB_CHANNELS,
                              _CONVACT_2_OUTPUT_0_IN_HEIGHT,
                              _CONVACT_2_OUTPUT_0_IN_WIDTH,
                              _FCACT_0_OUTPUT_0_NB_OUTPUTS,
                              _FCACT_0_OUTPUT_0_OUT_HEIGHT,
                              _FCACT_0_OUTPUT_0_OUT_WIDTH,
                              _FCACT_0_ACTIVATION,
                              _CONVACT_2_OUTPUT_0_MEM_CONT_OFFSET,
                              _CONVACT_2_OUTPUT_0_MEM_CONT_SIZE,
                              _CONVACT_2_OUTPUT_0_MEM_WRAP_OFFSET,
                              _CONVACT_2_OUTPUT_0_MEM_WRAP_SIZE,
                              _CONVACT_2_OUTPUT_0_MEM_STRIDE,
                              _FCACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                              _FCACT_0_OUTPUT_0_MEM_CONT_SIZE,
                              _FCACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FCACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                              _FCACT_0_OUTPUT_0_MEM_STRIDE>
                              (_ConvAct_2_output_0, _FCAct_0_output_0, _FCAct_0_weights_output_0, _FCAct_0_biases_output_0, _FCACT_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FCAct_0\n");
    FILE* _FCACT_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_FCAct_0_output_0.txt", "w");
    export_cpp::saveOutputs<_FCACT_0_OUTPUT_0_NB_OUTPUTS,
                            _FCACT_0_OUTPUT_0_OUT_HEIGHT,
                            _FCACT_0_OUTPUT_0_OUT_WIDTH,
                            _FCACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _FCACT_0_OUTPUT_0_MEM_CONT_SIZE,
                            _FCACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FCACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _FCACT_0_OUTPUT_0_DEV_FMT>
                            (_FCAct_0_output_0,
                            _FCACT_0_OUTPUT_0_STREAM);
    fclose(_FCACT_0_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_0_output_0 = (float*) (mem + _FC_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_FCACT_0_OUTPUT_0_IN_BATCH,
                              _FCACT_0_OUTPUT_0_NB_CHANNELS,
                              _FCACT_0_OUTPUT_0_IN_HEIGHT,
                              _FCACT_0_OUTPUT_0_IN_WIDTH,
                              _FC_0_OUTPUT_0_NB_OUTPUTS,
                              _FC_0_OUTPUT_0_OUT_HEIGHT,
                              _FC_0_OUTPUT_0_OUT_WIDTH,
                              _FC_0_ACTIVATION,
                              _FCACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                              _FCACT_0_OUTPUT_0_MEM_CONT_SIZE,
                              _FCACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FCACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                              _FCACT_0_OUTPUT_0_MEM_STRIDE,
                              _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_0_OUTPUT_0_MEM_STRIDE>
                              (_FCAct_0_output_0, _FC_0_output_0, _FC_0_weights_output_0, _FC_0_biases_output_0, _FC_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_0\n");
    FILE* _FC_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_0_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_0_OUTPUT_0_NB_OUTPUTS,
                            _FC_0_OUTPUT_0_OUT_HEIGHT,
                            _FC_0_OUTPUT_0_OUT_WIDTH,
                            _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_0_OUTPUT_0_DEV_FMT>
                            (_FC_0_output_0,
                            _FC_0_OUTPUT_0_STREAM);
    fclose(_FC_0_OUTPUT_0_STREAM);
    #endif




    

    float* _Softmax_0_output_0 = (float*) (mem + _SOFTMAX_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::softmax_forward<_SOFTMAX_0_AXIS_SIZE,
                                _SOFTMAX_0_AXIS_SIZE_POST,
                                _SOFTMAX_0_AXIS_SIZE_PRE,
                                _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                                _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _FC_0_OUTPUT_0_MEM_STRIDE,
                                _SOFTMAX_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _SOFTMAX_0_OUTPUT_0_MEM_CONT_SIZE,
                                _SOFTMAX_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _SOFTMAX_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _SOFTMAX_0_OUTPUT_0_MEM_STRIDE>
                                (_FC_0_output_0, _Softmax_0_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _Softmax_0\n");
    FILE* _SOFTMAX_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_Softmax_0_output_0.txt", "w");
    export_cpp::saveOutputs<_SOFTMAX_0_OUTPUT_0_NB_OUTPUTS,
                            _SOFTMAX_0_OUTPUT_0_OUT_HEIGHT,
                            _SOFTMAX_0_OUTPUT_0_OUT_WIDTH,
                            _SOFTMAX_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _SOFTMAX_0_OUTPUT_0_MEM_CONT_SIZE,
                            _SOFTMAX_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _SOFTMAX_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _SOFTMAX_0_OUTPUT_0_DEV_FMT>
                            (_Softmax_0_output_0,
                            _SOFTMAX_0_OUTPUT_0_STREAM);
    fclose(_SOFTMAX_0_OUTPUT_0_STREAM);
    #endif



    *_Softmax_0_output_0_ptr = _Softmax_0_output_0;
}
