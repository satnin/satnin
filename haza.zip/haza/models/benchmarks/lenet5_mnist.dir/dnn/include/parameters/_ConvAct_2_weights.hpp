#ifndef _CONVACT_2_WEIGHTS_OUTPUT_0_H
#define _CONVACT_2_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _ConvAct_2_weights_output_0[120*5*5*16];

#endif /* _CONVACT_2_WEIGHTS_OUTPUT_0_H */
