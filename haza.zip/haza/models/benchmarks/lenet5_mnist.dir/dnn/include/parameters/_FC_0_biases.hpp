#ifndef _FC_0_BIASES_OUTPUT_0_H
#define _FC_0_BIASES_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FC_0_biases_output_0[10];

#endif /* _FC_0_BIASES_OUTPUT_0_H */
