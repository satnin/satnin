#ifndef _CONVACT_0_WEIGHTS_OUTPUT_0_H
#define _CONVACT_0_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _ConvAct_0_weights_output_0[6*5*5*1];

#endif /* _CONVACT_0_WEIGHTS_OUTPUT_0_H */
