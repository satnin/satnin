#ifndef _CONVACT_1_BIASES_OUTPUT_0_H
#define _CONVACT_1_BIASES_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _ConvAct_1_biases_output_0[16];

#endif /* _CONVACT_1_BIASES_OUTPUT_0_H */
