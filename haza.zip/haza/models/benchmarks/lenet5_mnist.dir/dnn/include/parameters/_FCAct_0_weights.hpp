#ifndef _FCACT_0_WEIGHTS_OUTPUT_0_H
#define _FCACT_0_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FCAct_0_weights_output_0[84*120];

#endif /* _FCACT_0_WEIGHTS_OUTPUT_0_H */
