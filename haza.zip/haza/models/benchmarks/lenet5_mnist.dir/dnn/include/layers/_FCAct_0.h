#ifndef _FCACT_0_LAYER_H
#define _FCACT_0_LAYER_H

#include "utils/cpp/rescaling_utils.hpp"
#include "utils/cpp/typedefs.hpp"



// INPUT CONF
#define _CONVACT_2_OUTPUT_0_IN_BATCH 1
#define _CONVACT_2_OUTPUT_0_NB_CHANNELS 120
#define _CONVACT_2_OUTPUT_0_IN_HEIGHT 1
#define _CONVACT_2_OUTPUT_0_IN_WIDTH 1

// OUTPUT CONF
#define _FCACT_0_OUTPUT_0_NB_OUTPUTS 84
#define _FCACT_0_OUTPUT_0_OUT_HEIGHT 1
#define _FCACT_0_OUTPUT_0_OUT_WIDTH 1
#define _FCACT_0_OUTPUT_0_OUT_BATCH 1

// MEMINFO CONF





#define _FCACT_0_OUTPUT_0_MEM_SIZE 336
#define _FCACT_0_OUTPUT_0_MEM_OFFSET 0
#define _FCACT_0_OUTPUT_0_MEM_STRIDE 336
#define _FCACT_0_OUTPUT_0_MEM_LENGTH 1
#define _FCACT_0_OUTPUT_0_MEM_CONT_SIZE 336
#define _FCACT_0_OUTPUT_0_MEM_CONT_OFFSET 0
#define _FCACT_0_OUTPUT_0_MEM_WRAP_OFFSET 0
#define _FCACT_0_OUTPUT_0_MEM_WRAP_SIZE 0

#define _FCACT_0_ACTIVATION export_cpp::ActivationFunction_T::Rectifier

static const export_cpp::NoScaling _FCACT_0_RESCALING = {};
#define _FCACT_0_WEIGHTS_SIZE 10080
#define _FCACT_0_BIASES_SIZE 84

#define _FCACT_0_OUTPUT_0_DEV_FMT export_cpp::DataFormat_T::DEFAULT

#endif /* _FCACT_0_LAYER_H */
