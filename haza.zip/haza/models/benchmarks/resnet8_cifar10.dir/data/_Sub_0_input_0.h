#ifndef _SUB_0_INPUT_0_H
#define _SUB_0_INPUT_0_H
#include <stdint.h>
#include <complex>

using namespace std::complex_literals;

 static const float _Sub_0_input_0[1*32*32*3] __attribute__((section(".nn_data_dtype.float32"))) = {

};
#endif /* _SUB_0_INPUT_0_H */
