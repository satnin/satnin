#ifndef _ADDACT_0_LAYER_H
#define _ADDACT_0_LAYER_H

#include <cstddef>
#include "utils/cpp/rescaling_utils.hpp"
#include "utils/cpp/typedefs.hpp"



// INPUT CONF
#define _PADCONV_0_OUTPUT_0_IN_BATCH 1
#define _PADCONV_0_OUTPUT_0_NB_CHANNELS 16
#define _PADCONV_0_OUTPUT_0_IN_HEIGHT 32
#define _PADCONV_0_OUTPUT_0_IN_WIDTH 32

// OUTPUT CONF
#define _ADDACT_0_OUTPUT_0_NB_OUTPUTS 16
#define _ADDACT_0_OUTPUT_0_OUT_HEIGHT 32
#define _ADDACT_0_OUTPUT_0_OUT_WIDTH 32
#define _ADDACT_0_OUTPUT_0_OUT_BATCH 1

// MEMINFO CONF




#define _ADDACT_0_OUTPUT_0_MEM_SIZE 64
#define _ADDACT_0_OUTPUT_0_MEM_OFFSET 90112
#define _ADDACT_0_OUTPUT_0_MEM_STRIDE 64
#define _ADDACT_0_OUTPUT_0_MEM_LENGTH 32
#define _ADDACT_0_OUTPUT_0_MEM_CONT_SIZE 65536
#define _ADDACT_0_OUTPUT_0_MEM_CONT_OFFSET 90112
#define _ADDACT_0_OUTPUT_0_MEM_WRAP_OFFSET 90112
#define _ADDACT_0_OUTPUT_0_MEM_WRAP_SIZE 0

#define _ADDACT_0_NB_MAT 1
#define _ADDACT_0_INPUT1_CONT_SIZE 16384
#define _ADDACT_0_INPUT2_CONT_SIZE 16384
#define _ADDACT_0_OUTPUT_CONT_SIZE 16384

constexpr size_t _ADDACT_0_OFFSET_IN1[] =  { 0 };
constexpr size_t _ADDACT_0_OFFSET_IN2[] = { 0 };

#define _ADDACT_0_ACTIVATION export_cpp::ActivationFunction_T::Rectifier
#define _ADDACT_0_ELEM_OP export_cpp::ElemWise_T::Add

#define _ADDACT_0_OUTPUT_0_DEV_FMT export_cpp::DataFormat_T::NHWC

static const export_cpp::NoScaling _ADDACT_0_RESCALING = {};

#endif /* _ADDACT_0_LAYER_H */
