#ifndef _ADDACT_2_LAYER_H
#define _ADDACT_2_LAYER_H

#include <cstddef>
#include "utils/cpp/rescaling_utils.hpp"
#include "utils/cpp/typedefs.hpp"



// INPUT CONF
#define _PADCONV_2_OUTPUT_0_IN_BATCH 1
#define _PADCONV_2_OUTPUT_0_NB_CHANNELS 64
#define _PADCONV_2_OUTPUT_0_IN_HEIGHT 8
#define _PADCONV_2_OUTPUT_0_IN_WIDTH 8

// OUTPUT CONF
#define _ADDACT_2_OUTPUT_0_NB_OUTPUTS 64
#define _ADDACT_2_OUTPUT_0_OUT_HEIGHT 8
#define _ADDACT_2_OUTPUT_0_OUT_WIDTH 8
#define _ADDACT_2_OUTPUT_0_OUT_BATCH 1

// MEMINFO CONF




#define _ADDACT_2_OUTPUT_0_MEM_SIZE 256
#define _ADDACT_2_OUTPUT_0_MEM_OFFSET 16384
#define _ADDACT_2_OUTPUT_0_MEM_STRIDE 256
#define _ADDACT_2_OUTPUT_0_MEM_LENGTH 8
#define _ADDACT_2_OUTPUT_0_MEM_CONT_SIZE 16384
#define _ADDACT_2_OUTPUT_0_MEM_CONT_OFFSET 16384
#define _ADDACT_2_OUTPUT_0_MEM_WRAP_OFFSET 16384
#define _ADDACT_2_OUTPUT_0_MEM_WRAP_SIZE 0

#define _ADDACT_2_NB_MAT 1
#define _ADDACT_2_INPUT1_CONT_SIZE 4096
#define _ADDACT_2_INPUT2_CONT_SIZE 4096
#define _ADDACT_2_OUTPUT_CONT_SIZE 4096

constexpr size_t _ADDACT_2_OFFSET_IN1[] =  { 0 };
constexpr size_t _ADDACT_2_OFFSET_IN2[] = { 0 };

#define _ADDACT_2_ACTIVATION export_cpp::ActivationFunction_T::Rectifier
#define _ADDACT_2_ELEM_OP export_cpp::ElemWise_T::Add

#define _ADDACT_2_OUTPUT_0_DEV_FMT export_cpp::DataFormat_T::NHWC

static const export_cpp::NoScaling _ADDACT_2_RESCALING = {};

#endif /* _ADDACT_2_LAYER_H */
