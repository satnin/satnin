#ifndef _ADDACT_1_LAYER_H
#define _ADDACT_1_LAYER_H

#include <cstddef>
#include "utils/cpp/rescaling_utils.hpp"
#include "utils/cpp/typedefs.hpp"



// INPUT CONF
#define _PADCONV_1_OUTPUT_0_IN_BATCH 1
#define _PADCONV_1_OUTPUT_0_NB_CHANNELS 32
#define _PADCONV_1_OUTPUT_0_IN_HEIGHT 16
#define _PADCONV_1_OUTPUT_0_IN_WIDTH 16

// OUTPUT CONF
#define _ADDACT_1_OUTPUT_0_NB_OUTPUTS 32
#define _ADDACT_1_OUTPUT_0_OUT_HEIGHT 16
#define _ADDACT_1_OUTPUT_0_OUT_WIDTH 16
#define _ADDACT_1_OUTPUT_0_OUT_BATCH 1

// MEMINFO CONF




#define _ADDACT_1_OUTPUT_0_MEM_SIZE 128
#define _ADDACT_1_OUTPUT_0_MEM_OFFSET 32768
#define _ADDACT_1_OUTPUT_0_MEM_STRIDE 128
#define _ADDACT_1_OUTPUT_0_MEM_LENGTH 16
#define _ADDACT_1_OUTPUT_0_MEM_CONT_SIZE 32768
#define _ADDACT_1_OUTPUT_0_MEM_CONT_OFFSET 32768
#define _ADDACT_1_OUTPUT_0_MEM_WRAP_OFFSET 32768
#define _ADDACT_1_OUTPUT_0_MEM_WRAP_SIZE 0

#define _ADDACT_1_NB_MAT 1
#define _ADDACT_1_INPUT1_CONT_SIZE 8192
#define _ADDACT_1_INPUT2_CONT_SIZE 8192
#define _ADDACT_1_OUTPUT_CONT_SIZE 8192

constexpr size_t _ADDACT_1_OFFSET_IN1[] =  { 0 };
constexpr size_t _ADDACT_1_OFFSET_IN2[] = { 0 };

#define _ADDACT_1_ACTIVATION export_cpp::ActivationFunction_T::Rectifier
#define _ADDACT_1_ELEM_OP export_cpp::ElemWise_T::Add

#define _ADDACT_1_OUTPUT_0_DEV_FMT export_cpp::DataFormat_T::NHWC

static const export_cpp::NoScaling _ADDACT_1_RESCALING = {};

#endif /* _ADDACT_1_LAYER_H */
