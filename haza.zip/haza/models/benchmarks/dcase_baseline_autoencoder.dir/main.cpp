#include <cstdio>
#include "forward.hpp"
#include "data/_FC_0_input_0.h"

int main()
{
    // Initialize the output arrays
    float* _FC_9_output_0 = nullptr;
    

    // Call the forward function
    model_forward(_FC_0_input_0, &_FC_9_output_0);

    // Print the results

    printf("_FC_9_output_0:\n");
    for (int o = 0; o < 640; ++o) {
        printf("%f ", _FC_9_output_0[o]);
    }
    printf("\n");
    return 0;
}
