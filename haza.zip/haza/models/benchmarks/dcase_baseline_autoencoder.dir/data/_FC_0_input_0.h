#ifndef _FC_0_INPUT_0_H
#define _FC_0_INPUT_0_H
#include <stdint.h>
#include <complex>

using namespace std::complex_literals;

 static const float _FC_0_input_0[1*640] __attribute__((section(".nn_data_dtype.float32"))) = {

};
#endif /* _FC_0_INPUT_0_H */
