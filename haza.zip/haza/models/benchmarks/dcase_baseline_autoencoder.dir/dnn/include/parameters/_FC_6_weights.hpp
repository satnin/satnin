#ifndef _FC_6_WEIGHTS_OUTPUT_0_H
#define _FC_6_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FC_6_weights_output_0[128*128];

#endif /* _FC_6_WEIGHTS_OUTPUT_0_H */
