#ifndef DECODER_4_WEIGHT_OUTPUT_0_H
#define DECODER_4_WEIGHT_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float decoder_4_weight_output_0[128];

#endif /* DECODER_4_WEIGHT_OUTPUT_0_H */
