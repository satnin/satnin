#ifndef ENCODER_4_RUNNING_MEAN_OUTPUT_0_H
#define ENCODER_4_RUNNING_MEAN_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float encoder_4_running_mean_output_0[128];

#endif /* ENCODER_4_RUNNING_MEAN_OUTPUT_0_H */
