#ifndef DECODER_10_RUNNING_MEAN_OUTPUT_0_H
#define DECODER_10_RUNNING_MEAN_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float decoder_10_running_mean_output_0[128];

#endif /* DECODER_10_RUNNING_MEAN_OUTPUT_0_H */
