#ifndef ENCODER_7_RUNNING_MEAN_OUTPUT_0_H
#define ENCODER_7_RUNNING_MEAN_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float encoder_7_running_mean_output_0[128];

#endif /* ENCODER_7_RUNNING_MEAN_OUTPUT_0_H */
