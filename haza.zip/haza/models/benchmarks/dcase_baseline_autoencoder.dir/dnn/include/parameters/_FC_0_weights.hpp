#ifndef _FC_0_WEIGHTS_OUTPUT_0_H
#define _FC_0_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FC_0_weights_output_0[128*640];

#endif /* _FC_0_WEIGHTS_OUTPUT_0_H */
