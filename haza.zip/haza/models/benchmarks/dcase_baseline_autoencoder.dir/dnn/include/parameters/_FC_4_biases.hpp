#ifndef _FC_4_BIASES_OUTPUT_0_H
#define _FC_4_BIASES_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FC_4_biases_output_0[8];

#endif /* _FC_4_BIASES_OUTPUT_0_H */
