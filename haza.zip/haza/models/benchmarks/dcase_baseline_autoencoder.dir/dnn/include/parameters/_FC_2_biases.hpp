#ifndef _FC_2_BIASES_OUTPUT_0_H
#define _FC_2_BIASES_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FC_2_biases_output_0[128];

#endif /* _FC_2_BIASES_OUTPUT_0_H */
