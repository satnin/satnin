#ifndef ENCODER_10_WEIGHT_OUTPUT_0_H
#define ENCODER_10_WEIGHT_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float encoder_10_weight_output_0[128];

#endif /* ENCODER_10_WEIGHT_OUTPUT_0_H */
