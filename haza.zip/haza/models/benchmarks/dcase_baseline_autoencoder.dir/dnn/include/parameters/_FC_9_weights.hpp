#ifndef _FC_9_WEIGHTS_OUTPUT_0_H
#define _FC_9_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FC_9_weights_output_0[640*128];

#endif /* _FC_9_WEIGHTS_OUTPUT_0_H */
