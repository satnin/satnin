#ifndef DECODER_7_RUNNING_VAR_OUTPUT_0_H
#define DECODER_7_RUNNING_VAR_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float decoder_7_running_var_output_0[128];

#endif /* DECODER_7_RUNNING_VAR_OUTPUT_0_H */
