#ifndef _FC_4_WEIGHTS_OUTPUT_0_H
#define _FC_4_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FC_4_weights_output_0[8*128];

#endif /* _FC_4_WEIGHTS_OUTPUT_0_H */
