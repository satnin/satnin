#ifndef _FC_9_BIASES_OUTPUT_0_H
#define _FC_9_BIASES_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FC_9_biases_output_0[640];

#endif /* _FC_9_BIASES_OUTPUT_0_H */
