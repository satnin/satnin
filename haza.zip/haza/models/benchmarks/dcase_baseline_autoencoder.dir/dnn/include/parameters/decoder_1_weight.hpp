#ifndef DECODER_1_WEIGHT_OUTPUT_0_H
#define DECODER_1_WEIGHT_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float decoder_1_weight_output_0[128];

#endif /* DECODER_1_WEIGHT_OUTPUT_0_H */
