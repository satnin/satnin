#ifndef DNN_HPP
#define DNN_HPP


#ifdef __cplusplus
extern "C" {
#endif


void model_forward (const float* _FC_0_input_0,
    float** _FC_9_output_0);

#ifdef __cplusplus
}
#endif

#endif /* DNN_HPP */
