#ifndef _RELU_3_LAYER_H
#define _RELU_3_LAYER_H

#include "utils/cpp/rescaling_utils.hpp"
#include "utils/cpp/typedefs.hpp"

#define _RELU_3_NB_ELTS 1*128
#define _RELU_3_ACTIVATION export_cpp::ActivationFunction_T::Rectifier
#define _RELU_3_OUTPUT_0_DEV_FMT export_cpp::DataFormat_T::DEFAULT


// INPUT CONF
#define _BATCHNORM2D_3_OUTPUT_0_IN_BATCH 1
#define _BATCHNORM2D_3_OUTPUT_0_NB_CHANNELS 128
#define _BATCHNORM2D_3_OUTPUT_0_IN_HEIGHT 1
#define _BATCHNORM2D_3_OUTPUT_0_IN_WIDTH 1

// OUTPUT CONF
#define _RELU_3_OUTPUT_0_NB_OUTPUTS 128
#define _RELU_3_OUTPUT_0_OUT_HEIGHT 1
#define _RELU_3_OUTPUT_0_OUT_WIDTH 1
#define _RELU_3_OUTPUT_0_OUT_BATCH 1

// MEMINFO CONF



#define _RELU_3_OUTPUT_0_MEM_SIZE 512
#define _RELU_3_OUTPUT_0_MEM_OFFSET 512
#define _RELU_3_OUTPUT_0_MEM_STRIDE 512
#define _RELU_3_OUTPUT_0_MEM_LENGTH 1
#define _RELU_3_OUTPUT_0_MEM_CONT_SIZE 512
#define _RELU_3_OUTPUT_0_MEM_CONT_OFFSET 512
#define _RELU_3_OUTPUT_0_MEM_WRAP_OFFSET 512
#define _RELU_3_OUTPUT_0_MEM_WRAP_SIZE 0


static const export_cpp::NoScaling _RELU_3_RESCALING = {};

#endif /* _RELU_3_LAYER_H */
