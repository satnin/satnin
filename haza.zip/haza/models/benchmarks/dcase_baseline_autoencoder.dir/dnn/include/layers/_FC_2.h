#ifndef _FC_2_LAYER_H
#define _FC_2_LAYER_H

#include "utils/cpp/rescaling_utils.hpp"
#include "utils/cpp/typedefs.hpp"



// INPUT CONF
#define _RELU_1_OUTPUT_0_IN_BATCH 1
#define _RELU_1_OUTPUT_0_NB_CHANNELS 128
#define _RELU_1_OUTPUT_0_IN_HEIGHT 1
#define _RELU_1_OUTPUT_0_IN_WIDTH 1

// OUTPUT CONF
#define _FC_2_OUTPUT_0_NB_OUTPUTS 128
#define _FC_2_OUTPUT_0_OUT_HEIGHT 1
#define _FC_2_OUTPUT_0_OUT_WIDTH 1
#define _FC_2_OUTPUT_0_OUT_BATCH 1

// MEMINFO CONF





#define _FC_2_OUTPUT_0_MEM_SIZE 512
#define _FC_2_OUTPUT_0_MEM_OFFSET 0
#define _FC_2_OUTPUT_0_MEM_STRIDE 512
#define _FC_2_OUTPUT_0_MEM_LENGTH 1
#define _FC_2_OUTPUT_0_MEM_CONT_SIZE 512
#define _FC_2_OUTPUT_0_MEM_CONT_OFFSET 0
#define _FC_2_OUTPUT_0_MEM_WRAP_OFFSET 0
#define _FC_2_OUTPUT_0_MEM_WRAP_SIZE 0

#define _FC_2_ACTIVATION export_cpp::ActivationFunction_T::Linear

static const export_cpp::NoScaling _FC_2_RESCALING = {};
#define _FC_2_WEIGHTS_SIZE 16384
#define _FC_2_BIASES_SIZE 128

#define _FC_2_OUTPUT_0_DEV_FMT export_cpp::DataFormat_T::DEFAULT

#endif /* _FC_2_LAYER_H */
