#ifndef _FC_1_LAYER_H
#define _FC_1_LAYER_H

#include "utils/cpp/rescaling_utils.hpp"
#include "utils/cpp/typedefs.hpp"



// INPUT CONF
#define _RELU_0_OUTPUT_0_IN_BATCH 1
#define _RELU_0_OUTPUT_0_NB_CHANNELS 128
#define _RELU_0_OUTPUT_0_IN_HEIGHT 1
#define _RELU_0_OUTPUT_0_IN_WIDTH 1

// OUTPUT CONF
#define _FC_1_OUTPUT_0_NB_OUTPUTS 128
#define _FC_1_OUTPUT_0_OUT_HEIGHT 1
#define _FC_1_OUTPUT_0_OUT_WIDTH 1
#define _FC_1_OUTPUT_0_OUT_BATCH 1

// MEMINFO CONF





#define _FC_1_OUTPUT_0_MEM_SIZE 512
#define _FC_1_OUTPUT_0_MEM_OFFSET 512
#define _FC_1_OUTPUT_0_MEM_STRIDE 512
#define _FC_1_OUTPUT_0_MEM_LENGTH 1
#define _FC_1_OUTPUT_0_MEM_CONT_SIZE 512
#define _FC_1_OUTPUT_0_MEM_CONT_OFFSET 512
#define _FC_1_OUTPUT_0_MEM_WRAP_OFFSET 512
#define _FC_1_OUTPUT_0_MEM_WRAP_SIZE 0

#define _FC_1_ACTIVATION export_cpp::ActivationFunction_T::Linear

static const export_cpp::NoScaling _FC_1_RESCALING = {};
#define _FC_1_WEIGHTS_SIZE 16384
#define _FC_1_BIASES_SIZE 128

#define _FC_1_OUTPUT_0_DEV_FMT export_cpp::DataFormat_T::DEFAULT

#endif /* _FC_1_LAYER_H */
