
#include <stdint.h>

#include "forward.hpp"

// Layer & memory configurations

#include "kernels/activation.hpp"
#include "parameters/decoder_10_weight.hpp"
#include "parameters/_FC_7_weights.hpp"
#include "parameters/decoder_4_running_var.hpp"
#include "layers/decoder_10_running_mean.h"
#include "parameters/encoder_4_running_var.hpp"
#include "parameters/encoder_1_weight.hpp"
#include "layers/decoder_1_running_mean.h"
#include "layers/_ReLU_1.h"
#include "parameters/_FC_3_weights.hpp"
#include "parameters/decoder_1_running_var.hpp"
#include "layers/decoder_4_running_mean.h"
#include "layers/encoder_4_running_mean.h"
#include "parameters/decoder_7_running_mean.hpp"
#include "parameters/_FC_7_biases.hpp"
#include "parameters/decoder_1_running_mean.hpp"
#include "layers/encoder_7_bias.h"
#include "parameters/decoder_7_bias.hpp"
#include "parameters/encoder_1_running_mean.hpp"
#include "parameters/_FC_0_weights.hpp"
#include "layers/decoder_1_bias.h"
#include "parameters/decoder_10_bias.hpp"
#include "layers/_FC_9.h"
#include "layers/_FC_0_weights.h"
#include "layers/_ReLU_4.h"
#include "parameters/decoder_4_running_mean.hpp"
#include "layers/decoder_10_weight.h"
#include "layers/decoder_10_running_var.h"
#include "parameters/decoder_10_running_mean.hpp"
#include "layers/encoder_4_bias.h"
#include "layers/encoder_4_running_var.h"
#include "kernels/cpp/batchnorm.hpp"
#include "layers/encoder_7_running_mean.h"
#include "layers/_FC_4_weights.h"
#include "layers/_FC_8.h"
#include "layers/decoder_7_bias.h"
#include "parameters/encoder_7_bias.hpp"
#include "layers/_FC_7_weights.h"
#include "parameters/decoder_7_running_var.hpp"
#include "parameters/encoder_4_bias.hpp"
#include "layers/_ReLU_6.h"
#include "parameters/decoder_7_weight.hpp"
#include "layers/encoder_7_weight.h"
#include "layers/decoder_4_weight.h"
#include "layers/encoder_1_running_mean.h"
#include "parameters/_FC_5_weights.hpp"
#include "layers/_BatchNorm2D_3.h"
#include "layers/_FC_5_weights.h"
#include "parameters/encoder_4_running_mean.hpp"
#include "layers/encoder_10_bias.h"
#include "layers/_FC_7.h"
#include "layers/_BatchNorm2D_7.h"
#include "layers/decoder_4_bias.h"
#include "layers/encoder_1_bias.h"
#include "layers/_BatchNorm2D_4.h"
#include "parameters/encoder_1_running_var.hpp"
#include "layers/encoder_10_running_mean.h"
#include "parameters/_FC_3_biases.hpp"
#include "parameters/_FC_8_weights.hpp"
#include "parameters/encoder_7_weight.hpp"
#include "layers/_FC_6_biases.h"
#include "layers/_ReLU_0.h"
#include "layers/decoder_7_running_mean.h"
#include "layers/_FC_1_biases.h"
#include "layers/encoder_7_running_var.h"
#include "parameters/decoder_1_bias.hpp"
#include "parameters/decoder_10_running_var.hpp"
#include "layers/_FC_8_weights.h"
#include "layers/_FC_2.h"
#include "parameters/_FC_1_weights.hpp"
#include "layers/_FC_6_weights.h"
#include "layers/_FC_9_weights.h"
#include "layers/_FC_3_biases.h"
#include "layers/_BatchNorm2D_6.h"
#include "layers/_ReLU_3.h"
#include "parameters/_FC_2_biases.hpp"
#include "layers/_FC_0_biases.h"
#include "layers/_FC_4.h"
#include "parameters/_FC_9_weights.hpp"
#include "layers/decoder_1_running_var.h"
#include "parameters/_FC_4_weights.hpp"
#include "layers/decoder_7_running_var.h"
#include "parameters/encoder_4_weight.hpp"
#include "layers/decoder_7_weight.h"
#include "parameters/encoder_7_running_mean.hpp"
#include "layers/_ReLU_2.h"
#include "parameters/_FC_0_biases.hpp"
#include "parameters/_FC_4_biases.hpp"
#include "parameters/encoder_10_running_mean.hpp"
#include "parameters/_FC_6_weights.hpp"
#include "layers/_BatchNorm2D_0.h"
#include "layers/_BatchNorm2D_5.h"
#include "layers/_FC_3.h"
#include "layers/_BatchNorm2D_2.h"
#include "layers/_FC_3_weights.h"
#include "layers/_FC_9_biases.h"
#include "parameters/encoder_1_bias.hpp"
#include "kernels/cpp/fullyconnected.hpp"
#include "parameters/_FC_5_biases.hpp"
#include "layers/encoder_4_weight.h"
#include "layers/decoder_10_bias.h"
#include "layers/_ReLU_7.h"
#include "layers/_FC_5.h"
#include "layers/decoder_4_running_var.h"
#include "layers/_FC_6.h"
#include "parameters/decoder_1_weight.hpp"
#include "layers/_FC_2_biases.h"
#include "layers/_FC_5_biases.h"
#include "layers/_BatchNorm2D_1.h"
#include "layers/encoder_10_weight.h"
#include "layers/encoder_1_running_var.h"
#include "layers/_FC_4_biases.h"
#include "layers/_FC_2_weights.h"
#include "parameters/encoder_10_weight.hpp"
#include "layers/_FC_7_biases.h"
#include "layers/_FC_0.h"
#include "parameters/encoder_10_running_var.hpp"
#include "parameters/_FC_2_weights.hpp"
#include "parameters/_FC_6_biases.hpp"
#include "parameters/_FC_1_biases.hpp"
#include "layers/decoder_1_weight.h"
#include "layers/_FC_1_weights.h"
#include "layers/encoder_1_weight.h"
#include "layers/_ReLU_5.h"
#include "layers/_FC_8_biases.h"
#include "parameters/decoder_4_weight.hpp"
#include "parameters/_FC_8_biases.hpp"
#include "parameters/encoder_10_bias.hpp"
#include "layers/encoder_10_running_var.h"
#include "parameters/encoder_7_running_var.hpp"
#include "parameters/decoder_4_bias.hpp"
#include "parameters/_FC_9_biases.hpp"
#include "layers/_FC_1.h"

// Memory block
static unsigned char mem[3584];

void model_forward (const float* _FC_0_input_0,float** _FC_9_output_0_ptr)
{
    

    float* _FC_0_output_0 = (float*) (mem + _FC_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_FC_0_INPUT_0_IN_BATCH,
                              _FC_0_INPUT_0_NB_CHANNELS,
                              _FC_0_INPUT_0_IN_HEIGHT,
                              _FC_0_INPUT_0_IN_WIDTH,
                              _FC_0_OUTPUT_0_NB_OUTPUTS,
                              _FC_0_OUTPUT_0_OUT_HEIGHT,
                              _FC_0_OUTPUT_0_OUT_WIDTH,
                              _FC_0_ACTIVATION,
                              _FC_0_INPUT_0_MEM_CONT_OFFSET,
                              _FC_0_INPUT_0_MEM_CONT_SIZE,
                              _FC_0_INPUT_0_MEM_WRAP_OFFSET,
                              _FC_0_INPUT_0_MEM_WRAP_SIZE,
                              _FC_0_INPUT_0_MEM_STRIDE,
                              _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_0_OUTPUT_0_MEM_STRIDE>
                              (_FC_0_input_0, _FC_0_output_0, _FC_0_weights_output_0, _FC_0_biases_output_0, _FC_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_0\n");
    FILE* _FC_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_0_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_0_OUTPUT_0_NB_OUTPUTS,
                            _FC_0_OUTPUT_0_OUT_HEIGHT,
                            _FC_0_OUTPUT_0_OUT_WIDTH,
                            _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_0_OUTPUT_0_DEV_FMT>
                            (_FC_0_output_0,
                            _FC_0_OUTPUT_0_STREAM);
    fclose(_FC_0_OUTPUT_0_STREAM);
    #endif




    

    float* _BatchNorm2D_0_output_0 = (float*) (mem + _BATCHNORM2D_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::batchnorm_forward<_BATCHNORM2D_0_OUTPUT_0_OUT_BATCH,
                                  _BATCHNORM2D_0_OUTPUT_0_NB_OUTPUTS,
                                  _BATCHNORM2D_0_OUTPUT_0_OUT_HEIGHT,
                                  _BATCHNORM2D_0_OUTPUT_0_OUT_WIDTH,
                                  _BATCHNORM2D_0_ACTIVATION>
                                  (_FC_0_output_0, _BatchNorm2D_0_output_0, 
                                   encoder_1_weight_output_0, encoder_1_bias_output_0, 
                                   encoder_1_running_mean_output_0, encoder_1_running_var_output_0, 
                                   _BATCHNORM2D_0_EPSILON, _BATCHNORM2D_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _BatchNorm2D_0\n");
    FILE* _BATCHNORM2D_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_BatchNorm2D_0_output_0.txt", "w");
    export_cpp::saveOutputs<_BATCHNORM2D_0_OUTPUT_0_NB_OUTPUTS,
                            _BATCHNORM2D_0_OUTPUT_0_OUT_HEIGHT,
                            _BATCHNORM2D_0_OUTPUT_0_OUT_WIDTH,
                            _BATCHNORM2D_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _BATCHNORM2D_0_OUTPUT_0_MEM_CONT_SIZE,
                            _BATCHNORM2D_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _BATCHNORM2D_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _BATCHNORM2D_0_OUTPUT_0_DEV_FMT>
                            (_BatchNorm2D_0_output_0,
                            _BATCHNORM2D_0_OUTPUT_0_STREAM);
    fclose(_BATCHNORM2D_0_OUTPUT_0_STREAM);
    #endif




    

    float* _ReLU_0_output_0 = (float*) (mem + _RELU_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::activation_forward<_RELU_0_NB_ELTS,
                                   _RELU_0_ACTIVATION,
                                   _BATCHNORM2D_0_OUTPUT_0_MEM_CONT_OFFSET,
                                   _BATCHNORM2D_0_OUTPUT_0_MEM_CONT_SIZE,
                                   _BATCHNORM2D_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _BATCHNORM2D_0_OUTPUT_0_MEM_WRAP_SIZE,
                                   _BATCHNORM2D_0_OUTPUT_0_MEM_STRIDE,
                                   _RELU_0_OUTPUT_0_MEM_CONT_OFFSET,
                                   _RELU_0_OUTPUT_0_MEM_CONT_SIZE,
                                   _RELU_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _RELU_0_OUTPUT_0_MEM_WRAP_SIZE,
                                   _RELU_0_OUTPUT_0_MEM_STRIDE,
                                   float>
                                   (_BatchNorm2D_0_output_0, _ReLU_0_output_0, _RELU_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ReLU_0\n");
    FILE* _RELU_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_ReLU_0_output_0.txt", "w");
    export_cpp::saveOutputs<_RELU_0_OUTPUT_0_NB_OUTPUTS,
                            _RELU_0_OUTPUT_0_OUT_HEIGHT,
                            _RELU_0_OUTPUT_0_OUT_WIDTH,
                            _RELU_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _RELU_0_OUTPUT_0_MEM_CONT_SIZE,
                            _RELU_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _RELU_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _RELU_0_OUTPUT_0_DEV_FMT>
                            (_ReLU_0_output_0,
                            _RELU_0_OUTPUT_0_STREAM);
    fclose(_RELU_0_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_1_output_0 = (float*) (mem + _FC_1_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_RELU_0_OUTPUT_0_IN_BATCH,
                              _RELU_0_OUTPUT_0_NB_CHANNELS,
                              _RELU_0_OUTPUT_0_IN_HEIGHT,
                              _RELU_0_OUTPUT_0_IN_WIDTH,
                              _FC_1_OUTPUT_0_NB_OUTPUTS,
                              _FC_1_OUTPUT_0_OUT_HEIGHT,
                              _FC_1_OUTPUT_0_OUT_WIDTH,
                              _FC_1_ACTIVATION,
                              _RELU_0_OUTPUT_0_MEM_CONT_OFFSET,
                              _RELU_0_OUTPUT_0_MEM_CONT_SIZE,
                              _RELU_0_OUTPUT_0_MEM_WRAP_OFFSET,
                              _RELU_0_OUTPUT_0_MEM_WRAP_SIZE,
                              _RELU_0_OUTPUT_0_MEM_STRIDE,
                              _FC_1_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_1_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_1_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_1_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_1_OUTPUT_0_MEM_STRIDE>
                              (_ReLU_0_output_0, _FC_1_output_0, _FC_1_weights_output_0, _FC_1_biases_output_0, _FC_1_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_1\n");
    FILE* _FC_1_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_1_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_1_OUTPUT_0_NB_OUTPUTS,
                            _FC_1_OUTPUT_0_OUT_HEIGHT,
                            _FC_1_OUTPUT_0_OUT_WIDTH,
                            _FC_1_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_1_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_1_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_1_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_1_OUTPUT_0_DEV_FMT>
                            (_FC_1_output_0,
                            _FC_1_OUTPUT_0_STREAM);
    fclose(_FC_1_OUTPUT_0_STREAM);
    #endif




    

    float* _BatchNorm2D_1_output_0 = (float*) (mem + _BATCHNORM2D_1_OUTPUT_0_MEM_OFFSET);

    export_cpp::batchnorm_forward<_BATCHNORM2D_1_OUTPUT_0_OUT_BATCH,
                                  _BATCHNORM2D_1_OUTPUT_0_NB_OUTPUTS,
                                  _BATCHNORM2D_1_OUTPUT_0_OUT_HEIGHT,
                                  _BATCHNORM2D_1_OUTPUT_0_OUT_WIDTH,
                                  _BATCHNORM2D_1_ACTIVATION>
                                  (_FC_1_output_0, _BatchNorm2D_1_output_0, 
                                   encoder_4_weight_output_0, encoder_4_bias_output_0, 
                                   encoder_4_running_mean_output_0, encoder_4_running_var_output_0, 
                                   _BATCHNORM2D_1_EPSILON, _BATCHNORM2D_1_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _BatchNorm2D_1\n");
    FILE* _BATCHNORM2D_1_OUTPUT_0_STREAM = fopen("data/export_outputs/_BatchNorm2D_1_output_0.txt", "w");
    export_cpp::saveOutputs<_BATCHNORM2D_1_OUTPUT_0_NB_OUTPUTS,
                            _BATCHNORM2D_1_OUTPUT_0_OUT_HEIGHT,
                            _BATCHNORM2D_1_OUTPUT_0_OUT_WIDTH,
                            _BATCHNORM2D_1_OUTPUT_0_MEM_CONT_OFFSET,
                            _BATCHNORM2D_1_OUTPUT_0_MEM_CONT_SIZE,
                            _BATCHNORM2D_1_OUTPUT_0_MEM_WRAP_OFFSET,
                            _BATCHNORM2D_1_OUTPUT_0_MEM_WRAP_SIZE,
                            _BATCHNORM2D_1_OUTPUT_0_DEV_FMT>
                            (_BatchNorm2D_1_output_0,
                            _BATCHNORM2D_1_OUTPUT_0_STREAM);
    fclose(_BATCHNORM2D_1_OUTPUT_0_STREAM);
    #endif




    

    float* _ReLU_1_output_0 = (float*) (mem + _RELU_1_OUTPUT_0_MEM_OFFSET);

    export_cpp::activation_forward<_RELU_1_NB_ELTS,
                                   _RELU_1_ACTIVATION,
                                   _BATCHNORM2D_1_OUTPUT_0_MEM_CONT_OFFSET,
                                   _BATCHNORM2D_1_OUTPUT_0_MEM_CONT_SIZE,
                                   _BATCHNORM2D_1_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _BATCHNORM2D_1_OUTPUT_0_MEM_WRAP_SIZE,
                                   _BATCHNORM2D_1_OUTPUT_0_MEM_STRIDE,
                                   _RELU_1_OUTPUT_0_MEM_CONT_OFFSET,
                                   _RELU_1_OUTPUT_0_MEM_CONT_SIZE,
                                   _RELU_1_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _RELU_1_OUTPUT_0_MEM_WRAP_SIZE,
                                   _RELU_1_OUTPUT_0_MEM_STRIDE,
                                   float>
                                   (_BatchNorm2D_1_output_0, _ReLU_1_output_0, _RELU_1_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ReLU_1\n");
    FILE* _RELU_1_OUTPUT_0_STREAM = fopen("data/export_outputs/_ReLU_1_output_0.txt", "w");
    export_cpp::saveOutputs<_RELU_1_OUTPUT_0_NB_OUTPUTS,
                            _RELU_1_OUTPUT_0_OUT_HEIGHT,
                            _RELU_1_OUTPUT_0_OUT_WIDTH,
                            _RELU_1_OUTPUT_0_MEM_CONT_OFFSET,
                            _RELU_1_OUTPUT_0_MEM_CONT_SIZE,
                            _RELU_1_OUTPUT_0_MEM_WRAP_OFFSET,
                            _RELU_1_OUTPUT_0_MEM_WRAP_SIZE,
                            _RELU_1_OUTPUT_0_DEV_FMT>
                            (_ReLU_1_output_0,
                            _RELU_1_OUTPUT_0_STREAM);
    fclose(_RELU_1_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_2_output_0 = (float*) (mem + _FC_2_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_RELU_1_OUTPUT_0_IN_BATCH,
                              _RELU_1_OUTPUT_0_NB_CHANNELS,
                              _RELU_1_OUTPUT_0_IN_HEIGHT,
                              _RELU_1_OUTPUT_0_IN_WIDTH,
                              _FC_2_OUTPUT_0_NB_OUTPUTS,
                              _FC_2_OUTPUT_0_OUT_HEIGHT,
                              _FC_2_OUTPUT_0_OUT_WIDTH,
                              _FC_2_ACTIVATION,
                              _RELU_1_OUTPUT_0_MEM_CONT_OFFSET,
                              _RELU_1_OUTPUT_0_MEM_CONT_SIZE,
                              _RELU_1_OUTPUT_0_MEM_WRAP_OFFSET,
                              _RELU_1_OUTPUT_0_MEM_WRAP_SIZE,
                              _RELU_1_OUTPUT_0_MEM_STRIDE,
                              _FC_2_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_2_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_2_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_2_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_2_OUTPUT_0_MEM_STRIDE>
                              (_ReLU_1_output_0, _FC_2_output_0, _FC_2_weights_output_0, _FC_2_biases_output_0, _FC_2_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_2\n");
    FILE* _FC_2_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_2_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_2_OUTPUT_0_NB_OUTPUTS,
                            _FC_2_OUTPUT_0_OUT_HEIGHT,
                            _FC_2_OUTPUT_0_OUT_WIDTH,
                            _FC_2_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_2_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_2_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_2_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_2_OUTPUT_0_DEV_FMT>
                            (_FC_2_output_0,
                            _FC_2_OUTPUT_0_STREAM);
    fclose(_FC_2_OUTPUT_0_STREAM);
    #endif




    

    float* _BatchNorm2D_2_output_0 = (float*) (mem + _BATCHNORM2D_2_OUTPUT_0_MEM_OFFSET);

    export_cpp::batchnorm_forward<_BATCHNORM2D_2_OUTPUT_0_OUT_BATCH,
                                  _BATCHNORM2D_2_OUTPUT_0_NB_OUTPUTS,
                                  _BATCHNORM2D_2_OUTPUT_0_OUT_HEIGHT,
                                  _BATCHNORM2D_2_OUTPUT_0_OUT_WIDTH,
                                  _BATCHNORM2D_2_ACTIVATION>
                                  (_FC_2_output_0, _BatchNorm2D_2_output_0, 
                                   encoder_7_weight_output_0, encoder_7_bias_output_0, 
                                   encoder_7_running_mean_output_0, encoder_7_running_var_output_0, 
                                   _BATCHNORM2D_2_EPSILON, _BATCHNORM2D_2_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _BatchNorm2D_2\n");
    FILE* _BATCHNORM2D_2_OUTPUT_0_STREAM = fopen("data/export_outputs/_BatchNorm2D_2_output_0.txt", "w");
    export_cpp::saveOutputs<_BATCHNORM2D_2_OUTPUT_0_NB_OUTPUTS,
                            _BATCHNORM2D_2_OUTPUT_0_OUT_HEIGHT,
                            _BATCHNORM2D_2_OUTPUT_0_OUT_WIDTH,
                            _BATCHNORM2D_2_OUTPUT_0_MEM_CONT_OFFSET,
                            _BATCHNORM2D_2_OUTPUT_0_MEM_CONT_SIZE,
                            _BATCHNORM2D_2_OUTPUT_0_MEM_WRAP_OFFSET,
                            _BATCHNORM2D_2_OUTPUT_0_MEM_WRAP_SIZE,
                            _BATCHNORM2D_2_OUTPUT_0_DEV_FMT>
                            (_BatchNorm2D_2_output_0,
                            _BATCHNORM2D_2_OUTPUT_0_STREAM);
    fclose(_BATCHNORM2D_2_OUTPUT_0_STREAM);
    #endif




    

    float* _ReLU_2_output_0 = (float*) (mem + _RELU_2_OUTPUT_0_MEM_OFFSET);

    export_cpp::activation_forward<_RELU_2_NB_ELTS,
                                   _RELU_2_ACTIVATION,
                                   _BATCHNORM2D_2_OUTPUT_0_MEM_CONT_OFFSET,
                                   _BATCHNORM2D_2_OUTPUT_0_MEM_CONT_SIZE,
                                   _BATCHNORM2D_2_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _BATCHNORM2D_2_OUTPUT_0_MEM_WRAP_SIZE,
                                   _BATCHNORM2D_2_OUTPUT_0_MEM_STRIDE,
                                   _RELU_2_OUTPUT_0_MEM_CONT_OFFSET,
                                   _RELU_2_OUTPUT_0_MEM_CONT_SIZE,
                                   _RELU_2_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _RELU_2_OUTPUT_0_MEM_WRAP_SIZE,
                                   _RELU_2_OUTPUT_0_MEM_STRIDE,
                                   float>
                                   (_BatchNorm2D_2_output_0, _ReLU_2_output_0, _RELU_2_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ReLU_2\n");
    FILE* _RELU_2_OUTPUT_0_STREAM = fopen("data/export_outputs/_ReLU_2_output_0.txt", "w");
    export_cpp::saveOutputs<_RELU_2_OUTPUT_0_NB_OUTPUTS,
                            _RELU_2_OUTPUT_0_OUT_HEIGHT,
                            _RELU_2_OUTPUT_0_OUT_WIDTH,
                            _RELU_2_OUTPUT_0_MEM_CONT_OFFSET,
                            _RELU_2_OUTPUT_0_MEM_CONT_SIZE,
                            _RELU_2_OUTPUT_0_MEM_WRAP_OFFSET,
                            _RELU_2_OUTPUT_0_MEM_WRAP_SIZE,
                            _RELU_2_OUTPUT_0_DEV_FMT>
                            (_ReLU_2_output_0,
                            _RELU_2_OUTPUT_0_STREAM);
    fclose(_RELU_2_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_3_output_0 = (float*) (mem + _FC_3_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_RELU_2_OUTPUT_0_IN_BATCH,
                              _RELU_2_OUTPUT_0_NB_CHANNELS,
                              _RELU_2_OUTPUT_0_IN_HEIGHT,
                              _RELU_2_OUTPUT_0_IN_WIDTH,
                              _FC_3_OUTPUT_0_NB_OUTPUTS,
                              _FC_3_OUTPUT_0_OUT_HEIGHT,
                              _FC_3_OUTPUT_0_OUT_WIDTH,
                              _FC_3_ACTIVATION,
                              _RELU_2_OUTPUT_0_MEM_CONT_OFFSET,
                              _RELU_2_OUTPUT_0_MEM_CONT_SIZE,
                              _RELU_2_OUTPUT_0_MEM_WRAP_OFFSET,
                              _RELU_2_OUTPUT_0_MEM_WRAP_SIZE,
                              _RELU_2_OUTPUT_0_MEM_STRIDE,
                              _FC_3_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_3_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_3_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_3_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_3_OUTPUT_0_MEM_STRIDE>
                              (_ReLU_2_output_0, _FC_3_output_0, _FC_3_weights_output_0, _FC_3_biases_output_0, _FC_3_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_3\n");
    FILE* _FC_3_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_3_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_3_OUTPUT_0_NB_OUTPUTS,
                            _FC_3_OUTPUT_0_OUT_HEIGHT,
                            _FC_3_OUTPUT_0_OUT_WIDTH,
                            _FC_3_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_3_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_3_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_3_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_3_OUTPUT_0_DEV_FMT>
                            (_FC_3_output_0,
                            _FC_3_OUTPUT_0_STREAM);
    fclose(_FC_3_OUTPUT_0_STREAM);
    #endif




    

    float* _BatchNorm2D_3_output_0 = (float*) (mem + _BATCHNORM2D_3_OUTPUT_0_MEM_OFFSET);

    export_cpp::batchnorm_forward<_BATCHNORM2D_3_OUTPUT_0_OUT_BATCH,
                                  _BATCHNORM2D_3_OUTPUT_0_NB_OUTPUTS,
                                  _BATCHNORM2D_3_OUTPUT_0_OUT_HEIGHT,
                                  _BATCHNORM2D_3_OUTPUT_0_OUT_WIDTH,
                                  _BATCHNORM2D_3_ACTIVATION>
                                  (_FC_3_output_0, _BatchNorm2D_3_output_0, 
                                   encoder_10_weight_output_0, encoder_10_bias_output_0, 
                                   encoder_10_running_mean_output_0, encoder_10_running_var_output_0, 
                                   _BATCHNORM2D_3_EPSILON, _BATCHNORM2D_3_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _BatchNorm2D_3\n");
    FILE* _BATCHNORM2D_3_OUTPUT_0_STREAM = fopen("data/export_outputs/_BatchNorm2D_3_output_0.txt", "w");
    export_cpp::saveOutputs<_BATCHNORM2D_3_OUTPUT_0_NB_OUTPUTS,
                            _BATCHNORM2D_3_OUTPUT_0_OUT_HEIGHT,
                            _BATCHNORM2D_3_OUTPUT_0_OUT_WIDTH,
                            _BATCHNORM2D_3_OUTPUT_0_MEM_CONT_OFFSET,
                            _BATCHNORM2D_3_OUTPUT_0_MEM_CONT_SIZE,
                            _BATCHNORM2D_3_OUTPUT_0_MEM_WRAP_OFFSET,
                            _BATCHNORM2D_3_OUTPUT_0_MEM_WRAP_SIZE,
                            _BATCHNORM2D_3_OUTPUT_0_DEV_FMT>
                            (_BatchNorm2D_3_output_0,
                            _BATCHNORM2D_3_OUTPUT_0_STREAM);
    fclose(_BATCHNORM2D_3_OUTPUT_0_STREAM);
    #endif




    

    float* _ReLU_3_output_0 = (float*) (mem + _RELU_3_OUTPUT_0_MEM_OFFSET);

    export_cpp::activation_forward<_RELU_3_NB_ELTS,
                                   _RELU_3_ACTIVATION,
                                   _BATCHNORM2D_3_OUTPUT_0_MEM_CONT_OFFSET,
                                   _BATCHNORM2D_3_OUTPUT_0_MEM_CONT_SIZE,
                                   _BATCHNORM2D_3_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _BATCHNORM2D_3_OUTPUT_0_MEM_WRAP_SIZE,
                                   _BATCHNORM2D_3_OUTPUT_0_MEM_STRIDE,
                                   _RELU_3_OUTPUT_0_MEM_CONT_OFFSET,
                                   _RELU_3_OUTPUT_0_MEM_CONT_SIZE,
                                   _RELU_3_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _RELU_3_OUTPUT_0_MEM_WRAP_SIZE,
                                   _RELU_3_OUTPUT_0_MEM_STRIDE,
                                   float>
                                   (_BatchNorm2D_3_output_0, _ReLU_3_output_0, _RELU_3_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ReLU_3\n");
    FILE* _RELU_3_OUTPUT_0_STREAM = fopen("data/export_outputs/_ReLU_3_output_0.txt", "w");
    export_cpp::saveOutputs<_RELU_3_OUTPUT_0_NB_OUTPUTS,
                            _RELU_3_OUTPUT_0_OUT_HEIGHT,
                            _RELU_3_OUTPUT_0_OUT_WIDTH,
                            _RELU_3_OUTPUT_0_MEM_CONT_OFFSET,
                            _RELU_3_OUTPUT_0_MEM_CONT_SIZE,
                            _RELU_3_OUTPUT_0_MEM_WRAP_OFFSET,
                            _RELU_3_OUTPUT_0_MEM_WRAP_SIZE,
                            _RELU_3_OUTPUT_0_DEV_FMT>
                            (_ReLU_3_output_0,
                            _RELU_3_OUTPUT_0_STREAM);
    fclose(_RELU_3_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_4_output_0 = (float*) (mem + _FC_4_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_RELU_3_OUTPUT_0_IN_BATCH,
                              _RELU_3_OUTPUT_0_NB_CHANNELS,
                              _RELU_3_OUTPUT_0_IN_HEIGHT,
                              _RELU_3_OUTPUT_0_IN_WIDTH,
                              _FC_4_OUTPUT_0_NB_OUTPUTS,
                              _FC_4_OUTPUT_0_OUT_HEIGHT,
                              _FC_4_OUTPUT_0_OUT_WIDTH,
                              _FC_4_ACTIVATION,
                              _RELU_3_OUTPUT_0_MEM_CONT_OFFSET,
                              _RELU_3_OUTPUT_0_MEM_CONT_SIZE,
                              _RELU_3_OUTPUT_0_MEM_WRAP_OFFSET,
                              _RELU_3_OUTPUT_0_MEM_WRAP_SIZE,
                              _RELU_3_OUTPUT_0_MEM_STRIDE,
                              _FC_4_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_4_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_4_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_4_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_4_OUTPUT_0_MEM_STRIDE>
                              (_ReLU_3_output_0, _FC_4_output_0, _FC_4_weights_output_0, _FC_4_biases_output_0, _FC_4_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_4\n");
    FILE* _FC_4_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_4_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_4_OUTPUT_0_NB_OUTPUTS,
                            _FC_4_OUTPUT_0_OUT_HEIGHT,
                            _FC_4_OUTPUT_0_OUT_WIDTH,
                            _FC_4_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_4_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_4_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_4_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_4_OUTPUT_0_DEV_FMT>
                            (_FC_4_output_0,
                            _FC_4_OUTPUT_0_STREAM);
    fclose(_FC_4_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_5_output_0 = (float*) (mem + _FC_5_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_FC_4_OUTPUT_0_IN_BATCH,
                              _FC_4_OUTPUT_0_NB_CHANNELS,
                              _FC_4_OUTPUT_0_IN_HEIGHT,
                              _FC_4_OUTPUT_0_IN_WIDTH,
                              _FC_5_OUTPUT_0_NB_OUTPUTS,
                              _FC_5_OUTPUT_0_OUT_HEIGHT,
                              _FC_5_OUTPUT_0_OUT_WIDTH,
                              _FC_5_ACTIVATION,
                              _FC_4_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_4_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_4_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_4_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_4_OUTPUT_0_MEM_STRIDE,
                              _FC_5_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_5_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_5_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_5_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_5_OUTPUT_0_MEM_STRIDE>
                              (_FC_4_output_0, _FC_5_output_0, _FC_5_weights_output_0, _FC_5_biases_output_0, _FC_5_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_5\n");
    FILE* _FC_5_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_5_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_5_OUTPUT_0_NB_OUTPUTS,
                            _FC_5_OUTPUT_0_OUT_HEIGHT,
                            _FC_5_OUTPUT_0_OUT_WIDTH,
                            _FC_5_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_5_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_5_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_5_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_5_OUTPUT_0_DEV_FMT>
                            (_FC_5_output_0,
                            _FC_5_OUTPUT_0_STREAM);
    fclose(_FC_5_OUTPUT_0_STREAM);
    #endif




    

    float* _BatchNorm2D_4_output_0 = (float*) (mem + _BATCHNORM2D_4_OUTPUT_0_MEM_OFFSET);

    export_cpp::batchnorm_forward<_BATCHNORM2D_4_OUTPUT_0_OUT_BATCH,
                                  _BATCHNORM2D_4_OUTPUT_0_NB_OUTPUTS,
                                  _BATCHNORM2D_4_OUTPUT_0_OUT_HEIGHT,
                                  _BATCHNORM2D_4_OUTPUT_0_OUT_WIDTH,
                                  _BATCHNORM2D_4_ACTIVATION>
                                  (_FC_5_output_0, _BatchNorm2D_4_output_0, 
                                   decoder_1_weight_output_0, decoder_1_bias_output_0, 
                                   decoder_1_running_mean_output_0, decoder_1_running_var_output_0, 
                                   _BATCHNORM2D_4_EPSILON, _BATCHNORM2D_4_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _BatchNorm2D_4\n");
    FILE* _BATCHNORM2D_4_OUTPUT_0_STREAM = fopen("data/export_outputs/_BatchNorm2D_4_output_0.txt", "w");
    export_cpp::saveOutputs<_BATCHNORM2D_4_OUTPUT_0_NB_OUTPUTS,
                            _BATCHNORM2D_4_OUTPUT_0_OUT_HEIGHT,
                            _BATCHNORM2D_4_OUTPUT_0_OUT_WIDTH,
                            _BATCHNORM2D_4_OUTPUT_0_MEM_CONT_OFFSET,
                            _BATCHNORM2D_4_OUTPUT_0_MEM_CONT_SIZE,
                            _BATCHNORM2D_4_OUTPUT_0_MEM_WRAP_OFFSET,
                            _BATCHNORM2D_4_OUTPUT_0_MEM_WRAP_SIZE,
                            _BATCHNORM2D_4_OUTPUT_0_DEV_FMT>
                            (_BatchNorm2D_4_output_0,
                            _BATCHNORM2D_4_OUTPUT_0_STREAM);
    fclose(_BATCHNORM2D_4_OUTPUT_0_STREAM);
    #endif




    

    float* _ReLU_4_output_0 = (float*) (mem + _RELU_4_OUTPUT_0_MEM_OFFSET);

    export_cpp::activation_forward<_RELU_4_NB_ELTS,
                                   _RELU_4_ACTIVATION,
                                   _BATCHNORM2D_4_OUTPUT_0_MEM_CONT_OFFSET,
                                   _BATCHNORM2D_4_OUTPUT_0_MEM_CONT_SIZE,
                                   _BATCHNORM2D_4_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _BATCHNORM2D_4_OUTPUT_0_MEM_WRAP_SIZE,
                                   _BATCHNORM2D_4_OUTPUT_0_MEM_STRIDE,
                                   _RELU_4_OUTPUT_0_MEM_CONT_OFFSET,
                                   _RELU_4_OUTPUT_0_MEM_CONT_SIZE,
                                   _RELU_4_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _RELU_4_OUTPUT_0_MEM_WRAP_SIZE,
                                   _RELU_4_OUTPUT_0_MEM_STRIDE,
                                   float>
                                   (_BatchNorm2D_4_output_0, _ReLU_4_output_0, _RELU_4_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ReLU_4\n");
    FILE* _RELU_4_OUTPUT_0_STREAM = fopen("data/export_outputs/_ReLU_4_output_0.txt", "w");
    export_cpp::saveOutputs<_RELU_4_OUTPUT_0_NB_OUTPUTS,
                            _RELU_4_OUTPUT_0_OUT_HEIGHT,
                            _RELU_4_OUTPUT_0_OUT_WIDTH,
                            _RELU_4_OUTPUT_0_MEM_CONT_OFFSET,
                            _RELU_4_OUTPUT_0_MEM_CONT_SIZE,
                            _RELU_4_OUTPUT_0_MEM_WRAP_OFFSET,
                            _RELU_4_OUTPUT_0_MEM_WRAP_SIZE,
                            _RELU_4_OUTPUT_0_DEV_FMT>
                            (_ReLU_4_output_0,
                            _RELU_4_OUTPUT_0_STREAM);
    fclose(_RELU_4_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_6_output_0 = (float*) (mem + _FC_6_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_RELU_4_OUTPUT_0_IN_BATCH,
                              _RELU_4_OUTPUT_0_NB_CHANNELS,
                              _RELU_4_OUTPUT_0_IN_HEIGHT,
                              _RELU_4_OUTPUT_0_IN_WIDTH,
                              _FC_6_OUTPUT_0_NB_OUTPUTS,
                              _FC_6_OUTPUT_0_OUT_HEIGHT,
                              _FC_6_OUTPUT_0_OUT_WIDTH,
                              _FC_6_ACTIVATION,
                              _RELU_4_OUTPUT_0_MEM_CONT_OFFSET,
                              _RELU_4_OUTPUT_0_MEM_CONT_SIZE,
                              _RELU_4_OUTPUT_0_MEM_WRAP_OFFSET,
                              _RELU_4_OUTPUT_0_MEM_WRAP_SIZE,
                              _RELU_4_OUTPUT_0_MEM_STRIDE,
                              _FC_6_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_6_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_6_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_6_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_6_OUTPUT_0_MEM_STRIDE>
                              (_ReLU_4_output_0, _FC_6_output_0, _FC_6_weights_output_0, _FC_6_biases_output_0, _FC_6_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_6\n");
    FILE* _FC_6_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_6_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_6_OUTPUT_0_NB_OUTPUTS,
                            _FC_6_OUTPUT_0_OUT_HEIGHT,
                            _FC_6_OUTPUT_0_OUT_WIDTH,
                            _FC_6_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_6_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_6_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_6_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_6_OUTPUT_0_DEV_FMT>
                            (_FC_6_output_0,
                            _FC_6_OUTPUT_0_STREAM);
    fclose(_FC_6_OUTPUT_0_STREAM);
    #endif




    

    float* _BatchNorm2D_5_output_0 = (float*) (mem + _BATCHNORM2D_5_OUTPUT_0_MEM_OFFSET);

    export_cpp::batchnorm_forward<_BATCHNORM2D_5_OUTPUT_0_OUT_BATCH,
                                  _BATCHNORM2D_5_OUTPUT_0_NB_OUTPUTS,
                                  _BATCHNORM2D_5_OUTPUT_0_OUT_HEIGHT,
                                  _BATCHNORM2D_5_OUTPUT_0_OUT_WIDTH,
                                  _BATCHNORM2D_5_ACTIVATION>
                                  (_FC_6_output_0, _BatchNorm2D_5_output_0, 
                                   decoder_4_weight_output_0, decoder_4_bias_output_0, 
                                   decoder_4_running_mean_output_0, decoder_4_running_var_output_0, 
                                   _BATCHNORM2D_5_EPSILON, _BATCHNORM2D_5_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _BatchNorm2D_5\n");
    FILE* _BATCHNORM2D_5_OUTPUT_0_STREAM = fopen("data/export_outputs/_BatchNorm2D_5_output_0.txt", "w");
    export_cpp::saveOutputs<_BATCHNORM2D_5_OUTPUT_0_NB_OUTPUTS,
                            _BATCHNORM2D_5_OUTPUT_0_OUT_HEIGHT,
                            _BATCHNORM2D_5_OUTPUT_0_OUT_WIDTH,
                            _BATCHNORM2D_5_OUTPUT_0_MEM_CONT_OFFSET,
                            _BATCHNORM2D_5_OUTPUT_0_MEM_CONT_SIZE,
                            _BATCHNORM2D_5_OUTPUT_0_MEM_WRAP_OFFSET,
                            _BATCHNORM2D_5_OUTPUT_0_MEM_WRAP_SIZE,
                            _BATCHNORM2D_5_OUTPUT_0_DEV_FMT>
                            (_BatchNorm2D_5_output_0,
                            _BATCHNORM2D_5_OUTPUT_0_STREAM);
    fclose(_BATCHNORM2D_5_OUTPUT_0_STREAM);
    #endif




    

    float* _ReLU_5_output_0 = (float*) (mem + _RELU_5_OUTPUT_0_MEM_OFFSET);

    export_cpp::activation_forward<_RELU_5_NB_ELTS,
                                   _RELU_5_ACTIVATION,
                                   _BATCHNORM2D_5_OUTPUT_0_MEM_CONT_OFFSET,
                                   _BATCHNORM2D_5_OUTPUT_0_MEM_CONT_SIZE,
                                   _BATCHNORM2D_5_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _BATCHNORM2D_5_OUTPUT_0_MEM_WRAP_SIZE,
                                   _BATCHNORM2D_5_OUTPUT_0_MEM_STRIDE,
                                   _RELU_5_OUTPUT_0_MEM_CONT_OFFSET,
                                   _RELU_5_OUTPUT_0_MEM_CONT_SIZE,
                                   _RELU_5_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _RELU_5_OUTPUT_0_MEM_WRAP_SIZE,
                                   _RELU_5_OUTPUT_0_MEM_STRIDE,
                                   float>
                                   (_BatchNorm2D_5_output_0, _ReLU_5_output_0, _RELU_5_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ReLU_5\n");
    FILE* _RELU_5_OUTPUT_0_STREAM = fopen("data/export_outputs/_ReLU_5_output_0.txt", "w");
    export_cpp::saveOutputs<_RELU_5_OUTPUT_0_NB_OUTPUTS,
                            _RELU_5_OUTPUT_0_OUT_HEIGHT,
                            _RELU_5_OUTPUT_0_OUT_WIDTH,
                            _RELU_5_OUTPUT_0_MEM_CONT_OFFSET,
                            _RELU_5_OUTPUT_0_MEM_CONT_SIZE,
                            _RELU_5_OUTPUT_0_MEM_WRAP_OFFSET,
                            _RELU_5_OUTPUT_0_MEM_WRAP_SIZE,
                            _RELU_5_OUTPUT_0_DEV_FMT>
                            (_ReLU_5_output_0,
                            _RELU_5_OUTPUT_0_STREAM);
    fclose(_RELU_5_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_7_output_0 = (float*) (mem + _FC_7_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_RELU_5_OUTPUT_0_IN_BATCH,
                              _RELU_5_OUTPUT_0_NB_CHANNELS,
                              _RELU_5_OUTPUT_0_IN_HEIGHT,
                              _RELU_5_OUTPUT_0_IN_WIDTH,
                              _FC_7_OUTPUT_0_NB_OUTPUTS,
                              _FC_7_OUTPUT_0_OUT_HEIGHT,
                              _FC_7_OUTPUT_0_OUT_WIDTH,
                              _FC_7_ACTIVATION,
                              _RELU_5_OUTPUT_0_MEM_CONT_OFFSET,
                              _RELU_5_OUTPUT_0_MEM_CONT_SIZE,
                              _RELU_5_OUTPUT_0_MEM_WRAP_OFFSET,
                              _RELU_5_OUTPUT_0_MEM_WRAP_SIZE,
                              _RELU_5_OUTPUT_0_MEM_STRIDE,
                              _FC_7_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_7_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_7_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_7_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_7_OUTPUT_0_MEM_STRIDE>
                              (_ReLU_5_output_0, _FC_7_output_0, _FC_7_weights_output_0, _FC_7_biases_output_0, _FC_7_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_7\n");
    FILE* _FC_7_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_7_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_7_OUTPUT_0_NB_OUTPUTS,
                            _FC_7_OUTPUT_0_OUT_HEIGHT,
                            _FC_7_OUTPUT_0_OUT_WIDTH,
                            _FC_7_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_7_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_7_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_7_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_7_OUTPUT_0_DEV_FMT>
                            (_FC_7_output_0,
                            _FC_7_OUTPUT_0_STREAM);
    fclose(_FC_7_OUTPUT_0_STREAM);
    #endif




    

    float* _BatchNorm2D_6_output_0 = (float*) (mem + _BATCHNORM2D_6_OUTPUT_0_MEM_OFFSET);

    export_cpp::batchnorm_forward<_BATCHNORM2D_6_OUTPUT_0_OUT_BATCH,
                                  _BATCHNORM2D_6_OUTPUT_0_NB_OUTPUTS,
                                  _BATCHNORM2D_6_OUTPUT_0_OUT_HEIGHT,
                                  _BATCHNORM2D_6_OUTPUT_0_OUT_WIDTH,
                                  _BATCHNORM2D_6_ACTIVATION>
                                  (_FC_7_output_0, _BatchNorm2D_6_output_0, 
                                   decoder_7_weight_output_0, decoder_7_bias_output_0, 
                                   decoder_7_running_mean_output_0, decoder_7_running_var_output_0, 
                                   _BATCHNORM2D_6_EPSILON, _BATCHNORM2D_6_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _BatchNorm2D_6\n");
    FILE* _BATCHNORM2D_6_OUTPUT_0_STREAM = fopen("data/export_outputs/_BatchNorm2D_6_output_0.txt", "w");
    export_cpp::saveOutputs<_BATCHNORM2D_6_OUTPUT_0_NB_OUTPUTS,
                            _BATCHNORM2D_6_OUTPUT_0_OUT_HEIGHT,
                            _BATCHNORM2D_6_OUTPUT_0_OUT_WIDTH,
                            _BATCHNORM2D_6_OUTPUT_0_MEM_CONT_OFFSET,
                            _BATCHNORM2D_6_OUTPUT_0_MEM_CONT_SIZE,
                            _BATCHNORM2D_6_OUTPUT_0_MEM_WRAP_OFFSET,
                            _BATCHNORM2D_6_OUTPUT_0_MEM_WRAP_SIZE,
                            _BATCHNORM2D_6_OUTPUT_0_DEV_FMT>
                            (_BatchNorm2D_6_output_0,
                            _BATCHNORM2D_6_OUTPUT_0_STREAM);
    fclose(_BATCHNORM2D_6_OUTPUT_0_STREAM);
    #endif




    

    float* _ReLU_6_output_0 = (float*) (mem + _RELU_6_OUTPUT_0_MEM_OFFSET);

    export_cpp::activation_forward<_RELU_6_NB_ELTS,
                                   _RELU_6_ACTIVATION,
                                   _BATCHNORM2D_6_OUTPUT_0_MEM_CONT_OFFSET,
                                   _BATCHNORM2D_6_OUTPUT_0_MEM_CONT_SIZE,
                                   _BATCHNORM2D_6_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _BATCHNORM2D_6_OUTPUT_0_MEM_WRAP_SIZE,
                                   _BATCHNORM2D_6_OUTPUT_0_MEM_STRIDE,
                                   _RELU_6_OUTPUT_0_MEM_CONT_OFFSET,
                                   _RELU_6_OUTPUT_0_MEM_CONT_SIZE,
                                   _RELU_6_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _RELU_6_OUTPUT_0_MEM_WRAP_SIZE,
                                   _RELU_6_OUTPUT_0_MEM_STRIDE,
                                   float>
                                   (_BatchNorm2D_6_output_0, _ReLU_6_output_0, _RELU_6_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ReLU_6\n");
    FILE* _RELU_6_OUTPUT_0_STREAM = fopen("data/export_outputs/_ReLU_6_output_0.txt", "w");
    export_cpp::saveOutputs<_RELU_6_OUTPUT_0_NB_OUTPUTS,
                            _RELU_6_OUTPUT_0_OUT_HEIGHT,
                            _RELU_6_OUTPUT_0_OUT_WIDTH,
                            _RELU_6_OUTPUT_0_MEM_CONT_OFFSET,
                            _RELU_6_OUTPUT_0_MEM_CONT_SIZE,
                            _RELU_6_OUTPUT_0_MEM_WRAP_OFFSET,
                            _RELU_6_OUTPUT_0_MEM_WRAP_SIZE,
                            _RELU_6_OUTPUT_0_DEV_FMT>
                            (_ReLU_6_output_0,
                            _RELU_6_OUTPUT_0_STREAM);
    fclose(_RELU_6_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_8_output_0 = (float*) (mem + _FC_8_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_RELU_6_OUTPUT_0_IN_BATCH,
                              _RELU_6_OUTPUT_0_NB_CHANNELS,
                              _RELU_6_OUTPUT_0_IN_HEIGHT,
                              _RELU_6_OUTPUT_0_IN_WIDTH,
                              _FC_8_OUTPUT_0_NB_OUTPUTS,
                              _FC_8_OUTPUT_0_OUT_HEIGHT,
                              _FC_8_OUTPUT_0_OUT_WIDTH,
                              _FC_8_ACTIVATION,
                              _RELU_6_OUTPUT_0_MEM_CONT_OFFSET,
                              _RELU_6_OUTPUT_0_MEM_CONT_SIZE,
                              _RELU_6_OUTPUT_0_MEM_WRAP_OFFSET,
                              _RELU_6_OUTPUT_0_MEM_WRAP_SIZE,
                              _RELU_6_OUTPUT_0_MEM_STRIDE,
                              _FC_8_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_8_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_8_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_8_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_8_OUTPUT_0_MEM_STRIDE>
                              (_ReLU_6_output_0, _FC_8_output_0, _FC_8_weights_output_0, _FC_8_biases_output_0, _FC_8_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_8\n");
    FILE* _FC_8_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_8_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_8_OUTPUT_0_NB_OUTPUTS,
                            _FC_8_OUTPUT_0_OUT_HEIGHT,
                            _FC_8_OUTPUT_0_OUT_WIDTH,
                            _FC_8_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_8_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_8_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_8_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_8_OUTPUT_0_DEV_FMT>
                            (_FC_8_output_0,
                            _FC_8_OUTPUT_0_STREAM);
    fclose(_FC_8_OUTPUT_0_STREAM);
    #endif




    

    float* _BatchNorm2D_7_output_0 = (float*) (mem + _BATCHNORM2D_7_OUTPUT_0_MEM_OFFSET);

    export_cpp::batchnorm_forward<_BATCHNORM2D_7_OUTPUT_0_OUT_BATCH,
                                  _BATCHNORM2D_7_OUTPUT_0_NB_OUTPUTS,
                                  _BATCHNORM2D_7_OUTPUT_0_OUT_HEIGHT,
                                  _BATCHNORM2D_7_OUTPUT_0_OUT_WIDTH,
                                  _BATCHNORM2D_7_ACTIVATION>
                                  (_FC_8_output_0, _BatchNorm2D_7_output_0, 
                                   decoder_10_weight_output_0, decoder_10_bias_output_0, 
                                   decoder_10_running_mean_output_0, decoder_10_running_var_output_0, 
                                   _BATCHNORM2D_7_EPSILON, _BATCHNORM2D_7_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _BatchNorm2D_7\n");
    FILE* _BATCHNORM2D_7_OUTPUT_0_STREAM = fopen("data/export_outputs/_BatchNorm2D_7_output_0.txt", "w");
    export_cpp::saveOutputs<_BATCHNORM2D_7_OUTPUT_0_NB_OUTPUTS,
                            _BATCHNORM2D_7_OUTPUT_0_OUT_HEIGHT,
                            _BATCHNORM2D_7_OUTPUT_0_OUT_WIDTH,
                            _BATCHNORM2D_7_OUTPUT_0_MEM_CONT_OFFSET,
                            _BATCHNORM2D_7_OUTPUT_0_MEM_CONT_SIZE,
                            _BATCHNORM2D_7_OUTPUT_0_MEM_WRAP_OFFSET,
                            _BATCHNORM2D_7_OUTPUT_0_MEM_WRAP_SIZE,
                            _BATCHNORM2D_7_OUTPUT_0_DEV_FMT>
                            (_BatchNorm2D_7_output_0,
                            _BATCHNORM2D_7_OUTPUT_0_STREAM);
    fclose(_BATCHNORM2D_7_OUTPUT_0_STREAM);
    #endif




    

    float* _ReLU_7_output_0 = (float*) (mem + _RELU_7_OUTPUT_0_MEM_OFFSET);

    export_cpp::activation_forward<_RELU_7_NB_ELTS,
                                   _RELU_7_ACTIVATION,
                                   _BATCHNORM2D_7_OUTPUT_0_MEM_CONT_OFFSET,
                                   _BATCHNORM2D_7_OUTPUT_0_MEM_CONT_SIZE,
                                   _BATCHNORM2D_7_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _BATCHNORM2D_7_OUTPUT_0_MEM_WRAP_SIZE,
                                   _BATCHNORM2D_7_OUTPUT_0_MEM_STRIDE,
                                   _RELU_7_OUTPUT_0_MEM_CONT_OFFSET,
                                   _RELU_7_OUTPUT_0_MEM_CONT_SIZE,
                                   _RELU_7_OUTPUT_0_MEM_WRAP_OFFSET,
                                   _RELU_7_OUTPUT_0_MEM_WRAP_SIZE,
                                   _RELU_7_OUTPUT_0_MEM_STRIDE,
                                   float>
                                   (_BatchNorm2D_7_output_0, _ReLU_7_output_0, _RELU_7_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ReLU_7\n");
    FILE* _RELU_7_OUTPUT_0_STREAM = fopen("data/export_outputs/_ReLU_7_output_0.txt", "w");
    export_cpp::saveOutputs<_RELU_7_OUTPUT_0_NB_OUTPUTS,
                            _RELU_7_OUTPUT_0_OUT_HEIGHT,
                            _RELU_7_OUTPUT_0_OUT_WIDTH,
                            _RELU_7_OUTPUT_0_MEM_CONT_OFFSET,
                            _RELU_7_OUTPUT_0_MEM_CONT_SIZE,
                            _RELU_7_OUTPUT_0_MEM_WRAP_OFFSET,
                            _RELU_7_OUTPUT_0_MEM_WRAP_SIZE,
                            _RELU_7_OUTPUT_0_DEV_FMT>
                            (_ReLU_7_output_0,
                            _RELU_7_OUTPUT_0_STREAM);
    fclose(_RELU_7_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_9_output_0 = (float*) (mem + _FC_9_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_default_forward<_RELU_7_OUTPUT_0_IN_BATCH,
                              _RELU_7_OUTPUT_0_NB_CHANNELS,
                              _RELU_7_OUTPUT_0_IN_HEIGHT,
                              _RELU_7_OUTPUT_0_IN_WIDTH,
                              _FC_9_OUTPUT_0_NB_OUTPUTS,
                              _FC_9_OUTPUT_0_OUT_HEIGHT,
                              _FC_9_OUTPUT_0_OUT_WIDTH,
                              _FC_9_ACTIVATION,
                              _RELU_7_OUTPUT_0_MEM_CONT_OFFSET,
                              _RELU_7_OUTPUT_0_MEM_CONT_SIZE,
                              _RELU_7_OUTPUT_0_MEM_WRAP_OFFSET,
                              _RELU_7_OUTPUT_0_MEM_WRAP_SIZE,
                              _RELU_7_OUTPUT_0_MEM_STRIDE,
                              _FC_9_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_9_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_9_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_9_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_9_OUTPUT_0_MEM_STRIDE>
                              (_ReLU_7_output_0, _FC_9_output_0, _FC_9_weights_output_0, _FC_9_biases_output_0, _FC_9_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_9\n");
    FILE* _FC_9_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_9_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_9_OUTPUT_0_NB_OUTPUTS,
                            _FC_9_OUTPUT_0_OUT_HEIGHT,
                            _FC_9_OUTPUT_0_OUT_WIDTH,
                            _FC_9_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_9_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_9_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_9_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_9_OUTPUT_0_DEV_FMT>
                            (_FC_9_output_0,
                            _FC_9_OUTPUT_0_STREAM);
    fclose(_FC_9_OUTPUT_0_STREAM);
    #endif




    *_FC_9_output_0_ptr = _FC_9_output_0;
}
