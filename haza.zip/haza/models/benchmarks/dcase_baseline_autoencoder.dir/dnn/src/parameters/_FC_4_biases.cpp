
#include <cstdint>
#include "parameters/_FC_4_biases.hpp"
#include <complex>

using namespace std::complex_literals;

const float _FC_4_biases_output_0[8] __attribute__((section(".nn_data_dtype.float32"))) =
{
-0.08282620459794998,-0.008112800307571888,-0.001589811174198985,-0.015022849664092064,-0.008264102973043919, 0.08632152527570724,-0.031067240983247757, 0.03480495885014534,
};
