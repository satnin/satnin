# models

Set of small ONNX models (a few bytes up to ~1 MB, most well under 100 KB)
used to test conversion by the Aidge framework (`aidge-onnx` ->
`aidge-core` / `aidge-quantization`). Models are organized by category and
chosen to cover as many different ONNX operators as possible, rather than
to be performant — except in `benchmarks/`, where the point is instead to
reproduce known, real literature architectures at their real accuracy.

## Layout

```
models/
  scripts/                  generator scripts (regenerate everything below)
  full_models/               complete, realistic small architectures
    mlp/
    cnn/
    rnn/
    transformer/
    autoencoder/
  operators/                 float operator coverage, outside any full model
    composite/                small graphs chaining a whole operator family
    single_op/                one operator per file
  quantized_int8/             int8-quantized operator coverage
    single_op/                one (de)quantization / integer op per file
    qdq_cnn_block.onnx        a realistic QDQ-quantized CNN block
  real_world/                 actually-trained tiny models for embedded use cases
    home_appliances/
    home_automation/
    smart_watch/
    audio/
    energy/
  benchmarks/                 actually-trained classic literature benchmark models
    mnist_cnn.onnx             compact custom CNN
    lenet5_mnist.onnx          + lenet5_mnist_int8_{qdq,qoperator}.onnx
    resnet8_cifar10.onnx       + resnet8_cifar10_int8_{qdq,qoperator}.onnx
    ds_cnn_s_kws.onnx          + ds_cnn_s_kws_int8_{qdq,qoperator}.onnx
    tinyconv_kws.onnx
    dcase_baseline_autoencoder.onnx  + dcase_baseline_autoencoder_int8_{qdq,qoperator}.onnx
```

Regenerate everything at any time with:

```bash
pip install onnx
python scripts/gen_full_models.py
python scripts/gen_single_op_models.py
python scripts/gen_quantized_int8_models.py

pip install torch   # only needed for the actually-trained models below
python scripts/gen_real_world_models.py

pip install torchvision   # MNIST (mnist_cnn, lenet5) and CIFAR-10 (resnet8) benchmarks
python scripts/gen_mnist_model.py
python scripts/gen_benchmark_lenet5.py
python scripts/gen_benchmark_resnet8.py    # downloads ~170 MB

pip install torchaudio                      # DS-CNN-S / TinyConv keyword spotting
python scripts/gen_benchmark_kws.py         # downloads ~2.4 GB (Speech Commands v0.02)

python scripts/gen_benchmark_dcase_ae.py    # no download (synthetic proxy data)

pip install onnxsim                         # optional: cleans up PyTorch's export noise
pip install onnxruntime                     # for the int8 quantized variants below
python scripts/gen_benchmark_quantize.py    # produces the `_int8_qdq.onnx` / `_int8_qoperator.onnx` siblings
```

Unless stated otherwise (see `real_world/` below), models are generated with
random weights (just to have non-zero tensors), opset 17, and validated
with `onnx.checker.check_model` before being saved.

## `<model>.json` metadata sidecars

Every generated `<model>.onnx` comes with a `<model>.json` file right next
to it (same name, same folder), describing its inputs and outputs:

```json
{
  "model": "activity_recognition.onnx",
  "description": "Activity recognizer (resting/walking/running) from a raw accelerometer magnitude sequence. Trained 1D-CNN (Conv8-Pool-FC16-FC3), train accuracy=1.000",
  "inputs": [
    {
      "name": "input",
      "shape": [1, 1, 32],
      "dtype": "float32",
      "description": "Raw sequence of the last 32 accelerometer-magnitude samples (~32 Hz), in chronological order (oldest sample at index 0, most recent at index 31), in g (9.81 m/s^2). On device this window is held in a circular buffer [...].",
      "example": [[[1.02, 1.28, 0.94, "...", 1.31]]]
    }
  ],
  "outputs": [
    {
      "name": "output",
      "shape": [1, 3],
      "dtype": "float32",
      "description": "Softmax probabilities over 3 activity classes, in class-index order: [0]=resting, [1]=walking, [2]=running.",
      "example": [[0.01, 0.92, 0.07]]
    }
  ]
}
```

Every input/output entry carries an **`example`** value with the right
shape and dtype, ready to feed straight into a converter or a unit test
without writing one:
- For `real_world/` models, the input example is a **real sample drawn
  from the training set** (a genuine, labeled sequence window — the
  `activity_recognition.onnx` one above is a real "walking" window), and
  the output example is the **model's actual prediction** for it, computed
  at generation time. Not synthetic filler: an end-to-end sanity-checked
  example.
- For the other categories (`full_models/`, `operators/`,
  `quantized_int8/`), where there is no "real" input to draw from, the
  example is a deterministic dtype-appropriate random value (uniform
  float in [-1, 1], int8 in [-128, 127], etc.) — same tensor name and shape
  always regenerate the same example, so it doesn't churn on every rerun.

For `real_world/` models the per-tensor `description` spells out feature
units, ordering, and output/class semantics. For the more generic
categories it names the tensor and, for `operators/single_op/` and
`quantized_int8/single_op/`, the operator that consumes/produces it — shape
and dtype are read directly from the ONNX graph, so they can't drift out
of sync with the model. Generated by the shared helper in
`scripts/_common.py` (`io_entry`, `random_example`, `write_json_metadata`).

## `full_models/` — complete small architectures

| Folder | Model | Operators covered |
|---|---|---|
| `mlp/` | `mlp_classifier.onnx` | Gemm, Relu, Softmax |
| `mlp/` | `mlp_residual.onnx` | Gemm, Sigmoid, Tanh, Add, Identity |
| `cnn/` | `cnn_basic.onnx` | Conv, BatchNormalization, Relu, MaxPool, GlobalAveragePool, Flatten, Gemm, Softmax |
| `cnn/` | `cnn_residual_block.onnx` | Conv, BatchNormalization, Relu, Add (ResNet-style skip connection) |
| `cnn/` | `cnn_inception_block.onnx` | Parallel Conv (1x1/3x3/5x5), Concat, LeakyRelu, GlobalAveragePool |
| `cnn/` | `cnn_depthwise_separable.onnx` | Pad, grouped (depthwise) Conv, Clip (ReLU6), pointwise Conv, MaxPool |
| `rnn/` | `rnn_lstm_classifier.onnx` | LSTM, Squeeze, Gemm |
| `rnn/` | `rnn_gru_classifier.onnx` | GRU, Squeeze, Gemm, Sigmoid |
| `transformer/` | `attention_encoder_block.onnx` | MatMul, Transpose, Softmax (self-attention), ReduceMean/Sub/Sqrt/Div (manual LayerNorm), Erf (GELU) |
| `autoencoder/` | `conv_autoencoder.onnx` | Conv (encoder), ConvTranspose (decoder), Relu, Sigmoid |

## `operators/` — isolated float operator coverage

### `operators/composite/`

Small graphs that don't represent a real model: each one chains an entire
family of operators (elementwise math, shape manipulation, activations,
reductions, broadcast/conditional) that isn't otherwise exercised, to widen
converter coverage beyond classic architectures.

| File | Operators covered |
|---|---|
| `ops_elementwise.onnx` | Add, Sub, Mul, Div, Abs, Pow, Sqrt, Neg, Exp, Log |
| `ops_shape_manipulation.onnx` | Transpose, Reshape, Split, Concat, Unsqueeze, Squeeze, Slice |
| `ops_activations.onnx` | LeakyRelu, PRelu, Elu, Selu, Softplus, Softsign, HardSigmoid, Clip |
| `ops_reduction.onnx` | ReduceMean, ReduceSum, ReduceMax, ReduceMin, ArgMax, TopK |
| `ops_conditional_broadcast.onnx` | Greater, Where, Cast, Expand, Tile, Slice |

### `operators/single_op/` — one operator per model

Each file contains a **single compute node** (the file name matches the
ONNX op type, e.g. `conv.onnx`, `reducemean.onnx`, `lstm.onnx`). Goal: test
the conversion of each operator in isolation, independently of the rest of
a graph, and immediately pinpoint a conversion issue specific to one
operator.

About fifty operators are covered, grouped by family:
- **Binary elementwise**: Add, Sub, Mul, Div, Pow, Greater
- **Unary elementwise**: Abs, Neg, Sqrt, Exp, Log, Reciprocal, Erf, Identity
- **Activations**: Relu, Sigmoid, Tanh, Selu, Softplus, Softsign, LeakyRelu,
  Elu, HardSigmoid, PRelu, Clip, Softmax
- **Convolution / pooling / normalization**: Conv, ConvTranspose, MaxPool,
  AveragePool, GlobalAveragePool, BatchNormalization, Flatten
- **Linear algebra**: Gemm, MatMul
- **Shape manipulation**: Transpose, Reshape, Squeeze, Unsqueeze, Concat,
  Split, Slice, Gather, Expand, Tile, Pad
- **Reductions**: ReduceMean, ReduceSum, ReduceMax, ReduceMin, ArgMax, TopK
- **Misc**: Where, Cast, LSTM, GRU

## `quantized_int8/` — int8-quantized operator coverage

Dedicated to quantized graphs (testing `aidge-quantization`):

| File | Operators covered |
|---|---|
| `single_op/quantizelinear.onnx` | QuantizeLinear (float32 -> int8) |
| `single_op/dequantizelinear.onnx` | DequantizeLinear (int8 -> float32) |
| `single_op/dynamicquantizelinear.onnx` | DynamicQuantizeLinear (scale/zero-point computed dynamically) |
| `single_op/qlinearconv.onnx` | QLinearConv (fully quantized convolution, int32 bias) |
| `single_op/qlinearmatmul.onnx` | QLinearMatMul (fully quantized matrix multiplication) |
| `single_op/convinteger.onnx` | ConvInteger (integer-arithmetic convolution, int32 output) |
| `single_op/matmulinteger.onnx` | MatMulInteger (integer-arithmetic matrix multiplication, int32 output) |
| `qdq_cnn_block.onnx` | Full CNN block in the QDQ format (QuantizeLinear/DequantizeLinear around Conv, Relu, MaxPool) |

`single_op/` isolates each (de)quantization or integer compute operator, on
the same principle as `operators/single_op/`. `qdq_cnn_block.onnx` shows a
realistic case: a full convolutional block as exported after
post-training quantization (PTQ), with QuantizeLinear/DequantizeLinear
pairs wrapping each float operator.

## `real_world/` — actually-trained embedded use cases

Unlike every other category above (random weights, meant to exercise
operator conversion), these models are **genuinely trained with PyTorch**
(`torch.onnx.export`) on a synthetic-but-domain-realistic dataset, so their
weights encode an actual decision function instead of noise.

**Inputs are raw sensor sequences, not pre-computed statistics.** Each
model consumes a window of L raw, chronologically-ordered samples (e.g.
the last 32 accelerometer-magnitude readings) rather than a hand-crafted
summary such as mean/std/max. On the embedded target, that window is
expected to live in a **circular buffer**: each new sample overwrites the
oldest entry in place, and firmware linearizes the buffer (reads it out
oldest-to-newest from the current write pointer) into a flat vector before
calling the model — the model itself never sees the physical ring/wrap
-around indexing, only a plain chronological sequence. This is spelled out
per model in its `.json` sidecar (see above).

Three architectures are used, picked per use case:
- **1D-CNN, single conv/pool block** (`Conv1d -> Relu -> MaxPool -> Flatten -> Gemm -> Relu -> Gemm -> Softmax/Sigmoid`)
  for signals that are quasi-periodic or transient at an arbitrary
  phase/position within the window (a wash agitation cycle, a
  walking/running gait, a mains current/voltage waveform, a glass-break
  impact) — convolution gives the phase/position tolerance a plain dense
  layer does not have.
- **1D-CNN, two conv/pool blocks** (`Conv1d -> Relu -> MaxPool -> Conv1d -> Relu -> MaxPool -> Flatten -> Gemm -> Relu -> Gemm -> Softmax`),
  used only for `audio_event_classifier.onnx`: a longer, richer raw
  waveform window benefits from a deeper feature extractor, and is also
  the category's largest model (this is the one making use of most of the
  ~100 KB size budget).
- **Logistic regression** (`Gemm -> Sigmoid`) or **plain MLP**
  (`Gemm -> Relu -> Gemm -> Sigmoid`) directly on the raw window, for
  signals whose class is driven by amplitude/duration/trend rather than
  periodicity (a compressor duty cycle, a PIR burst, a rising smoke trend,
  a beat-to-beat HR drift).

Generated with `scripts/gen_real_world_models.py`, which prints the
training-set accuracy achieved for every model (all >= 0.97 on the
synthetic data — see script output). Each `.onnx` file's `doc_string` (and
its `.json` sidecar) also records the accuracy and the exact input/output
semantics.

| Domain | Model | Task | Architecture | Raw input window | Size |
|---|---|---|---|---|---|
| `home_appliances/` | `washing_machine_cycle_classifier.onnx` | 4-class: idle / wash / rinse / spin | 1D-CNN (Conv8-Pool-FC16-FC4), Softmax | 24 motor current-draw samples | ~8 KB |
| `home_appliances/` | `fridge_compressor_anomaly_detector.onnx` | Binary: normal / anomalous compressor cycle | Logistic regression, Sigmoid | 32 current-draw samples (one duty cycle) | <1 KB |
| `home_automation/` | `occupancy_detector.onnx` | Binary: empty / occupied room | Logistic regression, Sigmoid | 16 PIR motion-intensity samples | <1 KB |
| `home_automation/` | `smoke_co_alarm_classifier.onnx` | Binary: safe / alarm | MLP (16-8-1), Sigmoid | 16 smoke-density samples | ~1 KB |
| `smart_watch/` | `activity_recognition.onnx` | 3-class: resting / walking / running | 1D-CNN (Conv8-Pool-FC16-FC3), Softmax | 32 accelerometer-magnitude samples | ~10 KB |
| `smart_watch/` | `heart_rate_anomaly_detector.onnx` | Binary: normal / abnormal heart rate | MLP (16-8-1), Sigmoid | 16 beat-to-beat HR samples | ~1 KB |
| `audio/` | `audio_event_classifier.onnx` | 3-class: background noise / speech-like babble / siren-alarm | 1D-CNN, 2 blocks (Conv8-Pool4-Conv16-Pool4-FC32-FC3), Softmax | 256 raw waveform samples (32 ms @ virtual 8 kHz) | ~38 KB |
| `audio/` | `glass_break_detector.onnx` | Binary: normal ambient sound / glass-break impact | 1D-CNN (Conv12-Pool8-FC16-FC1), Sigmoid | 128 raw waveform samples (16 ms @ virtual 8 kHz) | ~14 KB |
| `energy/` | `appliance_load_classifier.onnx` | 4-class (NILM-style): idle / resistive heater / kettle / motor start-up | 1D-CNN (Conv16-Pool4-FC32-FC4), Softmax | 128 raw mains current samples (~2 mains cycles) | ~68 KB |
| `energy/` | `voltage_anomaly_detector.onnx` | Binary: normal / anomalous (sag, swell, or transient spike) | 1D-CNN (Conv8-Pool2-FC16-FC1), Sigmoid | 64 raw mains voltage samples (~2 mains cycles) | ~18 KB |

These models range from a few hundred bytes (plain logistic regression on
a short window) up to ~68 KB (the deepest/widest 1D-CNNs), reflecting the
requested "smallest possible, but up to ~100 KB is fine" budget — the
larger audio/energy models spend that extra headroom on longer raw windows
and wider conv/dense layers, while acquisition and buffering are still
assumed to happen upstream in fixed-point/DSP code; only the classifier
itself is exported as ONNX for conversion testing. The synthetic datasets
are for reproducibility only — swap in real sensor recordings and retrain
the same way (`pip install torch`, then rerun the script) for production
use.

## `benchmarks/` — actually-trained classic literature benchmarks

Unlike `real_world/` (domain-realistic but synthetic data) and unlike
every random-weight category above, these models reproduce **well-known
published architectures**, each **trained on its real, public dataset**
(downloaded via `torchvision`/`torchaudio`, cached under the system temp
directory, never committed to the repo) — the point is both "does the
converter handle a famous, widely-implemented reference architecture" and
"is this actually a working model with a real, reported accuracy," not
just an operator-coverage exercise.

| Model | Reference | Task | Architecture | Input | Params | Size | Real test accuracy |
|---|---|---|---|---|---|---|---|
| `mnist_cnn.onnx` | (custom, compact) | 10-class digits | Conv8-Pool-Conv8-Pool-FC32-FC10, Softmax | `(1,1,28,28)` raw pixels [0,255] | ~7.5k | ~60 KB | **97.9%** (MNIST) |
| `lenet5_mnist.onnx` | LeCun et al., 1998 | 10-class digits | Conv6-AvgPool-Conv16-AvgPool-Conv120-FC84-FC10, Softmax | `(1,1,28,28)` raw pixels [0,255] | ~61.7k | ~245 KB | **98.7%** (MNIST) |
| `lenet5_mnist_int8_qdq.onnx` | ↳ int8, QDQ format | " | " | " | " | **~76 KB** (3.2x) | **99.7%** (300-sample check) |
| `lenet5_mnist_int8_qoperator.onnx` | ↳ int8, QOperator format | " | " | " | " | **~69 KB** (3.6x) | **99.7%** (300-sample check) |
| `resnet8_cifar10.onnx` | MLPerf Tiny "image classification" (ResNet-v1, 6n+2, n=1) | 10-class objects | Conv-BN-ReLU stem + 3 residual stages (16/32/64 filters) + GAP + FC, Softmax | `(1,3,32,32)` raw RGB pixels [0,255] | ~78k | ~308 KB | **76.6%** (CIFAR-10, 10 epochs) |
| `resnet8_cifar10_int8_qdq.onnx` | ↳ int8, QDQ format | " | " | " | " | **~102 KB** (3.0x) | **79.0%** (300-sample check) |
| `resnet8_cifar10_int8_qoperator.onnx` | ↳ int8, QOperator format | " | " | " | " | **~91 KB** (3.4x) | **79.0%** (300-sample check) |
| `ds_cnn_s_kws.onnx` | Zhang et al., 2018 "Hello Edge" DS-CNN-S *(approximate)* | 12-class keyword spotting | Conv-BN-ReLU stem + 4x depthwise-separable Conv-BN-ReLU + GAP + FC, Softmax | `(1,1,49,10)` MFCC features | ~23.2k | ~94 KB | **84.2%** (Speech Commands) |
| `ds_cnn_s_kws_int8_qdq.onnx` | ↳ int8, QDQ format | " | " | " | " | **~50 KB** (1.9x) | **84.4%** (full test split) |
| `ds_cnn_s_kws_int8_qoperator.onnx` | ↳ int8, QOperator format | " | " | " | " | **~38 KB** (2.5x) | **84.4%** (full test split) |
| `tinyconv_kws.onnx` | TFLite Micro `micro_speech` reference | 12-class keyword spotting | 1x Conv2D directly into FC, Softmax | `(1,1,49,40)` log-mel features | ~46.7k | ~184 KB | **65.6%** (Speech Commands) |
| `dcase_baseline_autoencoder.onnx` | DCASE 2020 Task 2 baseline | Unsupervised anomaly detection (reconstruction error) | Dense autoencoder 640-128-128-128-128-8-128-128-128-128-640, BN+ReLU | `(1,640)` log-mel features | ~268k | ~1.06 MB | *(synthetic data — see caveat below)* |
| `dcase_baseline_autoencoder_int8_qdq.onnx` | ↳ int8, QDQ format | " | " | " | " | **~328 KB** (3.2x) | *(synthetic data)* |
| `dcase_baseline_autoencoder_int8_qoperator.onnx` | ↳ int8, QOperator format | " | " | " | " | **~307 KB** (3.5x) | *(synthetic data)* |

All numbers above are measured, not estimated: parameter counts are
printed by the generator scripts, and "real test accuracy" is the actual
accuracy on each dataset's official held-out test split (or, for the int8
models, on a same-split spot-check — see each script for the exact
sample count) — evaluated by literally running the exported `.onnx` file
through `onnxruntime`, not the pre-export PyTorch model.

**Which literature model, why:**
- **LeNet-5** — *the* original CNN benchmark; kept alongside the smaller
  custom `mnist_cnn.onnx` as the "faithful, larger" reference point (see
  the size comparison: same task, ~4x the parameters).
- **ResNet-8** — MLPerf Tiny's own reference model for image
  classification; the standard `6n+2`-depth CIFAR ResNet parametrization.
- **DS-CNN-S** — the small depthwise-separable CNN from the "Hello Edge"
  keyword-spotting paper, sized to the same ballpark as the published ~24k
  -parameter configuration (an approximate reproduction: the paper's exact
  per-layer hyperparameters aren't guaranteed bit-for-bit here, see the
  script's doc string).
- **TinyConv** — the deliberately minimal `micro_speech` example model
  from TensorFlow Lite for Microcontrollers; useful as a "simplest
  possible KWS baseline" contrast to DS-CNN-S (much lower accuracy, and,
  perhaps counterintuitively, a *larger* file — its single conv layer
  feeds a huge flatten-to-dense layer with no pooling to shrink it first).
- **DCASE baseline autoencoder** — the standard unsupervised
  reconstruction-error architecture for machine-sound anomaly detection.
  **Caveat:** trained on synthetic proxy data (smooth random-basis
  "normal" vectors vs. scattered outliers), not the real DCASE/MIMII/
  ToyADMOS dataset (tens of GB, not fetched in this environment) — this is
  a structurally faithful benchmark of the published architecture, not a
  working anomaly detector. Its `.json` sidecar says so explicitly.

**int8 quantization** (`scripts/gen_benchmark_quantize.py`): the four
larger fp32 models (LeNet-5, ResNet-8, DS-CNN-S, DCASE autoencoder) each
get **two** int8 siblings, produced with `onnxruntime`'s static
post-training quantization (`quantize_static`, per-channel weights) using
**200 real calibration samples** drawn from each model's own dataset (not
random noise) — one per quantized graph representation onnxruntime can
emit, since a converter may support one better than the other:
- **`_int8_qdq.onnx`** — QDQ format: the graph keeps its original
  float32-typed ops, with `QuantizeLinear`/`DequantizeLinear` pairs
  inserted around each quantized op (same style as `quantized_int8/`
  elsewhere in this folder).
- **`_int8_qoperator.onnx`** — QOperator format: ops are directly replaced
  by their integer-native counterparts (`QLinearConv`, `QLinearMatMul`/
  `QGemm`, `QLinearAdd`, `QLinearGlobalAveragePool`, `QLinearSoftmax`,
  `ConvInteger`, ...) with int8/uint8-typed tensors flowing between them,
  no separate Quantize/Dequantize nodes. Consistently a bit smaller than
  the QDQ sibling (no duplicated scale/zero-point constants around every
  op) and gives the converter a completely different operator set to
  handle.

As the table shows, both shrink each model 1.9-3.6x (QOperator slightly
more than QDQ throughout) while keeping accuracy within noise of the
float32 original (in several cases the int8 spot-check even measured
slightly higher, which is just sampling variance on a few hundred images,
not a real improvement) — and QDQ vs. QOperator make no accuracy
difference, as expected, since they encode the same quantized computation
two different ways.

Every model's `.json` sidecar carries a real example input/output (a real
test-set MNIST digit, CIFAR-10 image, or Speech Commands MFCC clip, and
the model's real prediction for it — not synthetic filler), same
convention as everywhere else in this folder. `mnist_cnn.onnx` and
`lenet5_mnist.onnx` both start with a `Div` (and, for LeNet-5, a `Pad`)
node doing the `[0,255] -> [0,1]` normalization (and, for LeNet-5, the
28x28 -> 32x32 padding) inside the graph, so raw pixel values go straight
in with no external preprocessing — same philosophy as the circular-buffer
inputs in `real_world/`. `resnet8_cifar10.onnx` does the same with a
per-channel `Sub`/`Div` standardization.
