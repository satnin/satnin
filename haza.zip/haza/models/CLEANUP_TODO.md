# Cleanup TODO — environnement global Python 3.14

Ne rien désinstaller tant que l'utilisateur n'a pas donné le "top". Cette
liste sert de mémo pour le nettoyage à faire ensuite.

## À supprimer (incidents / plus utilisés)

- **torchcodec** — installé pour tenter de réparer `torchaudio.load`
  (nécessitait FFmpeg, absent du système). Finalement contourné en lisant
  les WAV directement avec le module stdlib `wave` dans
  `gen_benchmark_kws.py`. **Plus nécessaire du tout.**

## À garder normalement (dépendances documentées des scripts de régénération)

Ces paquets sont prérequis dans le README (`pip install ...`) pour
régénérer les modèles — à ne retirer que si l'utilisateur veut un
environnement 100% propre sans plus jamais régénérer localement :

- `onnx`, `onnxruntime` — cœur du projet models/ (utilisés partout)
- `torch` — entraînement real_world/ et benchmarks/
- `torchvision` — MNIST (mnist_cnn, lenet5) et CIFAR-10 (resnet8)
- `torchaudio` — transforms MFCC/MelSpectrogram pour DS-CNN-S/TinyConv
  (le chargement audio lui-même n'utilise PAS torchaudio, juste ses
  transforms de features, donc torchaudio reste nécessaire)
- `onnxsim` (+ deps `rich`, `markdown-it-py`, `mdurl`) — utilisé par
  `_common.py::simplify_onnx_model()`, appelé par plusieurs scripts
  (`gen_mnist_model.py`, `gen_benchmark_lenet5.py`,
  `gen_benchmark_resnet8.py`, `gen_benchmark_kws.py`) pour nettoyer les
  graphes ONNX exportés par PyTorch (nœuds Pad/Slice/Constant parasites)

## Dossiers de données téléchargées (hors dépôt, dans le dossier temp système)

- `%TEMP%/aidge_mnist_data` (MNIST, ~11 Mo)
- `%TEMP%/aidge_cifar10_data` (CIFAR-10, ~170 Mo)
- `%TEMP%/aidge_speech_commands` (Speech Commands v0.02, ~2.4 Go — le plus
  gros, à supprimer en priorité si besoin de libérer de l'espace)

## Commande de nettoyage complet (à valider avant exécution)

```bash
pip uninstall -y torchcodec
# Si l'utilisateur veut tout retirer (plus de régénération possible sans réinstaller) :
pip uninstall -y torch torchvision torchaudio onnxsim rich markdown-it-py mdurl
rm -rf "$TEMP/aidge_mnist_data" "$TEMP/aidge_cifar10_data" "$TEMP/aidge_speech_commands"
```

**Attendre le "top" de l'utilisateur avant d'exécuter quoi que ce soit ci-dessus.**
