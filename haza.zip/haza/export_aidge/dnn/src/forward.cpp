
#include <stdint.h>

#include "forward.hpp"

// Layer & memory configurations

#include "parameters/_ConvAct_3_biases.hpp"
#include "kernels/cpp/convolution.hpp"
#include "layers/_ConvAct_1_biases.h"
#include "layers/_PadConvAct_0_biases.h"
#include "layers/_PadConvDwAct_1_weights.h"
#include "layers/_PadConvDwAct_0.h"
#include "layers/_PadConvDwAct_0_weights.h"
#include "layers/_FC_0_post_reshape_1.h"
#include "parameters/_PadConvAct_0_weights.hpp"
#include "parameters/_ConvAct_2_biases.hpp"
#include "layers/_ConvAct_3_biases.h"
#include "parameters/_PadConvDwAct_2_biases.hpp"
#include "layers/_GlobalAveragePooling_0.h"
#include "parameters/_PadConvDwAct_3_biases.hpp"
#include "layers/_ConvAct_2.h"
#include "layers/_PadConvDwAct_2_weights.h"
#include "parameters/_PadConvDwAct_0_biases.hpp"
#include "layers/_ConvAct_3_weights.h"
#include "parameters/_ConvAct_3_weights.hpp"
#include "parameters/_PadConvDwAct_1_biases.hpp"
#include "layers/_ConvAct_2_biases.h"
#include "parameters/_PadConvDwAct_1_weights.hpp"
#include "kernels/cpp/pooling.hpp"
#include "parameters/_ConvAct_0_weights.hpp"
#include "kernels/cpp/softmax.hpp"
#include "parameters/_PadConvDwAct_3_weights.hpp"
#include "layers/_ConvAct_0.h"
#include "layers/_ConvAct_3.h"
#include "layers/_PadConvDwAct_3_biases.h"
#include "layers/_FC_0.h"
#include "parameters/_FC_0_biases.hpp"
#include "layers/_PadConvDwAct_3.h"
#include "parameters/_PadConvDwAct_0_weights.hpp"
#include "parameters/_PadConvDwAct_2_weights.hpp"
#include "kernels/cpp/convolution_depthwise.hpp"
#include "parameters/_ConvAct_1_weights.hpp"
#include "parameters/_ConvAct_2_weights.hpp"
#include "layers/_PadConvDwAct_1_biases.h"
#include "layers/_PadConvAct_0_weights.h"
#include "layers/_PadConvDwAct_3_weights.h"
#include "parameters/_ConvAct_1_biases.hpp"
#include "layers/_PadConvAct_0.h"
#include "layers/_PadConvDwAct_2_biases.h"
#include "layers/_ConvAct_1.h"
#include "layers/_ConvAct_1_weights.h"
#include "layers/_PadConvDwAct_1.h"
#include "layers/_ConvAct_0_biases.h"
#include "layers/_ConvAct_0_weights.h"
#include "layers/_PadConvDwAct_2.h"
#include "layers/_PadConvDwAct_0_biases.h"
#include "kernels/cpp/fullyconnected.hpp"
#include "parameters/_FC_0_post_reshape_1.hpp"
#include "layers/_Softmax_0.h"
#include "parameters/_PadConvAct_0_biases.hpp"
#include "layers/_FC_0_biases.h"
#include "parameters/_ConvAct_0_biases.hpp"
#include "layers/_ConvAct_2_weights.h"

// Memory block
static unsigned char mem[61440];

void model_forward (const float* _PadConvAct_0_input_0,float** _Softmax_0_output_0_ptr)
{
    

    float* _PadConvAct_0_output_0 = (float*) (mem + _PADCONVACT_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_forward<_PADCONVACT_0_INPUT_0_NB_CHANNELS,
                           _PADCONVACT_0_INPUT_0_IN_HEIGHT,
                           _PADCONVACT_0_INPUT_0_IN_WIDTH,
                           _PADCONVACT_0_OUTPUT_0_NB_OUTPUTS,
                           _PADCONVACT_0_OUTPUT_0_OUT_HEIGHT,
                           _PADCONVACT_0_OUTPUT_0_OUT_WIDTH,
                           _PADCONVACT_0_PADDING_Y,
                           _PADCONVACT_0_PADDING_X,
                           _PADCONVACT_0_STRIDE_Y,
                           _PADCONVACT_0_STRIDE_X,
                           _PADCONVACT_0_DILATION_Y,
                           _PADCONVACT_0_DILATION_X,
                           _PADCONVACT_0_KERNEL_HEIGHT,
                           _PADCONVACT_0_KERNEL_WIDTH,
                           _PADCONVACT_0_ACTIVATION,
                           _PADCONVACT_0_INPUT_0_MEM_CONT_OFFSET,
                           _PADCONVACT_0_INPUT_0_MEM_CONT_SIZE,
                           _PADCONVACT_0_INPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVACT_0_INPUT_0_MEM_WRAP_SIZE,
                           _PADCONVACT_0_INPUT_0_MEM_STRIDE,
                           _PADCONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVACT_0_OUTPUT_0_MEM_STRIDE>
                           (_PadConvAct_0_input_0, _PadConvAct_0_output_0, _PadConvAct_0_weights_output_0, _PadConvAct_0_biases_output_0, _PADCONVACT_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _PadConvAct_0\n");
    FILE* _PADCONVACT_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_PadConvAct_0_output_0.txt", "w");
    export_cpp::saveOutputs<_PADCONVACT_0_OUTPUT_0_NB_OUTPUTS,
                            _PADCONVACT_0_OUTPUT_0_OUT_HEIGHT,
                            _PADCONVACT_0_OUTPUT_0_OUT_WIDTH,
                            _PADCONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _PADCONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                            _PADCONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _PADCONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _PADCONVACT_0_OUTPUT_0_DEV_FMT>
                            (_PadConvAct_0_output_0,
                            _PADCONVACT_0_OUTPUT_0_STREAM);
    fclose(_PADCONVACT_0_OUTPUT_0_STREAM);
    #endif




    

    float* _PadConvDwAct_0_output_0 = (float*) (mem + _PADCONVDWACT_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_depthwise_forward<_PADCONVACT_0_OUTPUT_0_NB_CHANNELS,
                           _PADCONVACT_0_OUTPUT_0_IN_HEIGHT,
                           _PADCONVACT_0_OUTPUT_0_IN_WIDTH,
                           _PADCONVDWACT_0_OUTPUT_0_NB_OUTPUTS,
                           _PADCONVDWACT_0_OUTPUT_0_OUT_HEIGHT,
                           _PADCONVDWACT_0_OUTPUT_0_OUT_WIDTH,
                           _PADCONVDWACT_0_PADDING_Y,
                           _PADCONVDWACT_0_PADDING_X,
                           _PADCONVDWACT_0_STRIDE_Y,
                           _PADCONVDWACT_0_STRIDE_X,
                           _PADCONVDWACT_0_DILATION_Y,
                           _PADCONVDWACT_0_DILATION_X,
                           _PADCONVDWACT_0_KERNEL_HEIGHT,
                           _PADCONVDWACT_0_KERNEL_WIDTH,
                           _PADCONVDWACT_0_ACTIVATION,
                           _PADCONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVACT_0_OUTPUT_0_MEM_STRIDE,
                           _PADCONVDWACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVDWACT_0_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVDWACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVDWACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVDWACT_0_OUTPUT_0_MEM_STRIDE>
                           (_PadConvAct_0_output_0, _PadConvDwAct_0_output_0, _PadConvDwAct_0_weights_output_0, _PadConvDwAct_0_biases_output_0, _PADCONVDWACT_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _PadConvDwAct_0\n");
    FILE* _PADCONVDWACT_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_PadConvDwAct_0_output_0.txt", "w");
    export_cpp::saveOutputs<_PADCONVDWACT_0_OUTPUT_0_NB_OUTPUTS,
                            _PADCONVDWACT_0_OUTPUT_0_OUT_HEIGHT,
                            _PADCONVDWACT_0_OUTPUT_0_OUT_WIDTH,
                            _PADCONVDWACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _PADCONVDWACT_0_OUTPUT_0_MEM_CONT_SIZE,
                            _PADCONVDWACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _PADCONVDWACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _PADCONVDWACT_0_OUTPUT_0_DEV_FMT>
                            (_PadConvDwAct_0_output_0,
                            _PADCONVDWACT_0_OUTPUT_0_STREAM);
    fclose(_PADCONVDWACT_0_OUTPUT_0_STREAM);
    #endif




    

    float* _ConvAct_0_output_0 = (float*) (mem + _CONVACT_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_forward<_PADCONVDWACT_0_OUTPUT_0_NB_CHANNELS,
                           _PADCONVDWACT_0_OUTPUT_0_IN_HEIGHT,
                           _PADCONVDWACT_0_OUTPUT_0_IN_WIDTH,
                           _CONVACT_0_OUTPUT_0_NB_OUTPUTS,
                           _CONVACT_0_OUTPUT_0_OUT_HEIGHT,
                           _CONVACT_0_OUTPUT_0_OUT_WIDTH,
                           _CONVACT_0_PADDING_Y,
                           _CONVACT_0_PADDING_X,
                           _CONVACT_0_STRIDE_Y,
                           _CONVACT_0_STRIDE_X,
                           _CONVACT_0_DILATION_Y,
                           _CONVACT_0_DILATION_X,
                           _CONVACT_0_KERNEL_HEIGHT,
                           _CONVACT_0_KERNEL_WIDTH,
                           _CONVACT_0_ACTIVATION,
                           _PADCONVDWACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVDWACT_0_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVDWACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVDWACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVDWACT_0_OUTPUT_0_MEM_STRIDE,
                           _CONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _CONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                           _CONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _CONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _CONVACT_0_OUTPUT_0_MEM_STRIDE>
                           (_PadConvDwAct_0_output_0, _ConvAct_0_output_0, _ConvAct_0_weights_output_0, _ConvAct_0_biases_output_0, _CONVACT_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ConvAct_0\n");
    FILE* _CONVACT_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_ConvAct_0_output_0.txt", "w");
    export_cpp::saveOutputs<_CONVACT_0_OUTPUT_0_NB_OUTPUTS,
                            _CONVACT_0_OUTPUT_0_OUT_HEIGHT,
                            _CONVACT_0_OUTPUT_0_OUT_WIDTH,
                            _CONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _CONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                            _CONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _CONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _CONVACT_0_OUTPUT_0_DEV_FMT>
                            (_ConvAct_0_output_0,
                            _CONVACT_0_OUTPUT_0_STREAM);
    fclose(_CONVACT_0_OUTPUT_0_STREAM);
    #endif




    

    float* _PadConvDwAct_1_output_0 = (float*) (mem + _PADCONVDWACT_1_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_depthwise_forward<_CONVACT_0_OUTPUT_0_NB_CHANNELS,
                           _CONVACT_0_OUTPUT_0_IN_HEIGHT,
                           _CONVACT_0_OUTPUT_0_IN_WIDTH,
                           _PADCONVDWACT_1_OUTPUT_0_NB_OUTPUTS,
                           _PADCONVDWACT_1_OUTPUT_0_OUT_HEIGHT,
                           _PADCONVDWACT_1_OUTPUT_0_OUT_WIDTH,
                           _PADCONVDWACT_1_PADDING_Y,
                           _PADCONVDWACT_1_PADDING_X,
                           _PADCONVDWACT_1_STRIDE_Y,
                           _PADCONVDWACT_1_STRIDE_X,
                           _PADCONVDWACT_1_DILATION_Y,
                           _PADCONVDWACT_1_DILATION_X,
                           _PADCONVDWACT_1_KERNEL_HEIGHT,
                           _PADCONVDWACT_1_KERNEL_WIDTH,
                           _PADCONVDWACT_1_ACTIVATION,
                           _CONVACT_0_OUTPUT_0_MEM_CONT_OFFSET,
                           _CONVACT_0_OUTPUT_0_MEM_CONT_SIZE,
                           _CONVACT_0_OUTPUT_0_MEM_WRAP_OFFSET,
                           _CONVACT_0_OUTPUT_0_MEM_WRAP_SIZE,
                           _CONVACT_0_OUTPUT_0_MEM_STRIDE,
                           _PADCONVDWACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVDWACT_1_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVDWACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVDWACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVDWACT_1_OUTPUT_0_MEM_STRIDE>
                           (_ConvAct_0_output_0, _PadConvDwAct_1_output_0, _PadConvDwAct_1_weights_output_0, _PadConvDwAct_1_biases_output_0, _PADCONVDWACT_1_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _PadConvDwAct_1\n");
    FILE* _PADCONVDWACT_1_OUTPUT_0_STREAM = fopen("data/export_outputs/_PadConvDwAct_1_output_0.txt", "w");
    export_cpp::saveOutputs<_PADCONVDWACT_1_OUTPUT_0_NB_OUTPUTS,
                            _PADCONVDWACT_1_OUTPUT_0_OUT_HEIGHT,
                            _PADCONVDWACT_1_OUTPUT_0_OUT_WIDTH,
                            _PADCONVDWACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                            _PADCONVDWACT_1_OUTPUT_0_MEM_CONT_SIZE,
                            _PADCONVDWACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                            _PADCONVDWACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                            _PADCONVDWACT_1_OUTPUT_0_DEV_FMT>
                            (_PadConvDwAct_1_output_0,
                            _PADCONVDWACT_1_OUTPUT_0_STREAM);
    fclose(_PADCONVDWACT_1_OUTPUT_0_STREAM);
    #endif




    

    float* _ConvAct_1_output_0 = (float*) (mem + _CONVACT_1_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_forward<_PADCONVDWACT_1_OUTPUT_0_NB_CHANNELS,
                           _PADCONVDWACT_1_OUTPUT_0_IN_HEIGHT,
                           _PADCONVDWACT_1_OUTPUT_0_IN_WIDTH,
                           _CONVACT_1_OUTPUT_0_NB_OUTPUTS,
                           _CONVACT_1_OUTPUT_0_OUT_HEIGHT,
                           _CONVACT_1_OUTPUT_0_OUT_WIDTH,
                           _CONVACT_1_PADDING_Y,
                           _CONVACT_1_PADDING_X,
                           _CONVACT_1_STRIDE_Y,
                           _CONVACT_1_STRIDE_X,
                           _CONVACT_1_DILATION_Y,
                           _CONVACT_1_DILATION_X,
                           _CONVACT_1_KERNEL_HEIGHT,
                           _CONVACT_1_KERNEL_WIDTH,
                           _CONVACT_1_ACTIVATION,
                           _PADCONVDWACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVDWACT_1_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVDWACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVDWACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVDWACT_1_OUTPUT_0_MEM_STRIDE,
                           _CONVACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                           _CONVACT_1_OUTPUT_0_MEM_CONT_SIZE,
                           _CONVACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                           _CONVACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                           _CONVACT_1_OUTPUT_0_MEM_STRIDE>
                           (_PadConvDwAct_1_output_0, _ConvAct_1_output_0, _ConvAct_1_weights_output_0, _ConvAct_1_biases_output_0, _CONVACT_1_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ConvAct_1\n");
    FILE* _CONVACT_1_OUTPUT_0_STREAM = fopen("data/export_outputs/_ConvAct_1_output_0.txt", "w");
    export_cpp::saveOutputs<_CONVACT_1_OUTPUT_0_NB_OUTPUTS,
                            _CONVACT_1_OUTPUT_0_OUT_HEIGHT,
                            _CONVACT_1_OUTPUT_0_OUT_WIDTH,
                            _CONVACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                            _CONVACT_1_OUTPUT_0_MEM_CONT_SIZE,
                            _CONVACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                            _CONVACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                            _CONVACT_1_OUTPUT_0_DEV_FMT>
                            (_ConvAct_1_output_0,
                            _CONVACT_1_OUTPUT_0_STREAM);
    fclose(_CONVACT_1_OUTPUT_0_STREAM);
    #endif




    

    float* _PadConvDwAct_2_output_0 = (float*) (mem + _PADCONVDWACT_2_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_depthwise_forward<_CONVACT_1_OUTPUT_0_NB_CHANNELS,
                           _CONVACT_1_OUTPUT_0_IN_HEIGHT,
                           _CONVACT_1_OUTPUT_0_IN_WIDTH,
                           _PADCONVDWACT_2_OUTPUT_0_NB_OUTPUTS,
                           _PADCONVDWACT_2_OUTPUT_0_OUT_HEIGHT,
                           _PADCONVDWACT_2_OUTPUT_0_OUT_WIDTH,
                           _PADCONVDWACT_2_PADDING_Y,
                           _PADCONVDWACT_2_PADDING_X,
                           _PADCONVDWACT_2_STRIDE_Y,
                           _PADCONVDWACT_2_STRIDE_X,
                           _PADCONVDWACT_2_DILATION_Y,
                           _PADCONVDWACT_2_DILATION_X,
                           _PADCONVDWACT_2_KERNEL_HEIGHT,
                           _PADCONVDWACT_2_KERNEL_WIDTH,
                           _PADCONVDWACT_2_ACTIVATION,
                           _CONVACT_1_OUTPUT_0_MEM_CONT_OFFSET,
                           _CONVACT_1_OUTPUT_0_MEM_CONT_SIZE,
                           _CONVACT_1_OUTPUT_0_MEM_WRAP_OFFSET,
                           _CONVACT_1_OUTPUT_0_MEM_WRAP_SIZE,
                           _CONVACT_1_OUTPUT_0_MEM_STRIDE,
                           _PADCONVDWACT_2_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVDWACT_2_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVDWACT_2_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVDWACT_2_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVDWACT_2_OUTPUT_0_MEM_STRIDE>
                           (_ConvAct_1_output_0, _PadConvDwAct_2_output_0, _PadConvDwAct_2_weights_output_0, _PadConvDwAct_2_biases_output_0, _PADCONVDWACT_2_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _PadConvDwAct_2\n");
    FILE* _PADCONVDWACT_2_OUTPUT_0_STREAM = fopen("data/export_outputs/_PadConvDwAct_2_output_0.txt", "w");
    export_cpp::saveOutputs<_PADCONVDWACT_2_OUTPUT_0_NB_OUTPUTS,
                            _PADCONVDWACT_2_OUTPUT_0_OUT_HEIGHT,
                            _PADCONVDWACT_2_OUTPUT_0_OUT_WIDTH,
                            _PADCONVDWACT_2_OUTPUT_0_MEM_CONT_OFFSET,
                            _PADCONVDWACT_2_OUTPUT_0_MEM_CONT_SIZE,
                            _PADCONVDWACT_2_OUTPUT_0_MEM_WRAP_OFFSET,
                            _PADCONVDWACT_2_OUTPUT_0_MEM_WRAP_SIZE,
                            _PADCONVDWACT_2_OUTPUT_0_DEV_FMT>
                            (_PadConvDwAct_2_output_0,
                            _PADCONVDWACT_2_OUTPUT_0_STREAM);
    fclose(_PADCONVDWACT_2_OUTPUT_0_STREAM);
    #endif




    

    float* _ConvAct_2_output_0 = (float*) (mem + _CONVACT_2_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_forward<_PADCONVDWACT_2_OUTPUT_0_NB_CHANNELS,
                           _PADCONVDWACT_2_OUTPUT_0_IN_HEIGHT,
                           _PADCONVDWACT_2_OUTPUT_0_IN_WIDTH,
                           _CONVACT_2_OUTPUT_0_NB_OUTPUTS,
                           _CONVACT_2_OUTPUT_0_OUT_HEIGHT,
                           _CONVACT_2_OUTPUT_0_OUT_WIDTH,
                           _CONVACT_2_PADDING_Y,
                           _CONVACT_2_PADDING_X,
                           _CONVACT_2_STRIDE_Y,
                           _CONVACT_2_STRIDE_X,
                           _CONVACT_2_DILATION_Y,
                           _CONVACT_2_DILATION_X,
                           _CONVACT_2_KERNEL_HEIGHT,
                           _CONVACT_2_KERNEL_WIDTH,
                           _CONVACT_2_ACTIVATION,
                           _PADCONVDWACT_2_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVDWACT_2_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVDWACT_2_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVDWACT_2_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVDWACT_2_OUTPUT_0_MEM_STRIDE,
                           _CONVACT_2_OUTPUT_0_MEM_CONT_OFFSET,
                           _CONVACT_2_OUTPUT_0_MEM_CONT_SIZE,
                           _CONVACT_2_OUTPUT_0_MEM_WRAP_OFFSET,
                           _CONVACT_2_OUTPUT_0_MEM_WRAP_SIZE,
                           _CONVACT_2_OUTPUT_0_MEM_STRIDE>
                           (_PadConvDwAct_2_output_0, _ConvAct_2_output_0, _ConvAct_2_weights_output_0, _ConvAct_2_biases_output_0, _CONVACT_2_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ConvAct_2\n");
    FILE* _CONVACT_2_OUTPUT_0_STREAM = fopen("data/export_outputs/_ConvAct_2_output_0.txt", "w");
    export_cpp::saveOutputs<_CONVACT_2_OUTPUT_0_NB_OUTPUTS,
                            _CONVACT_2_OUTPUT_0_OUT_HEIGHT,
                            _CONVACT_2_OUTPUT_0_OUT_WIDTH,
                            _CONVACT_2_OUTPUT_0_MEM_CONT_OFFSET,
                            _CONVACT_2_OUTPUT_0_MEM_CONT_SIZE,
                            _CONVACT_2_OUTPUT_0_MEM_WRAP_OFFSET,
                            _CONVACT_2_OUTPUT_0_MEM_WRAP_SIZE,
                            _CONVACT_2_OUTPUT_0_DEV_FMT>
                            (_ConvAct_2_output_0,
                            _CONVACT_2_OUTPUT_0_STREAM);
    fclose(_CONVACT_2_OUTPUT_0_STREAM);
    #endif




    

    float* _PadConvDwAct_3_output_0 = (float*) (mem + _PADCONVDWACT_3_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_depthwise_forward<_CONVACT_2_OUTPUT_0_NB_CHANNELS,
                           _CONVACT_2_OUTPUT_0_IN_HEIGHT,
                           _CONVACT_2_OUTPUT_0_IN_WIDTH,
                           _PADCONVDWACT_3_OUTPUT_0_NB_OUTPUTS,
                           _PADCONVDWACT_3_OUTPUT_0_OUT_HEIGHT,
                           _PADCONVDWACT_3_OUTPUT_0_OUT_WIDTH,
                           _PADCONVDWACT_3_PADDING_Y,
                           _PADCONVDWACT_3_PADDING_X,
                           _PADCONVDWACT_3_STRIDE_Y,
                           _PADCONVDWACT_3_STRIDE_X,
                           _PADCONVDWACT_3_DILATION_Y,
                           _PADCONVDWACT_3_DILATION_X,
                           _PADCONVDWACT_3_KERNEL_HEIGHT,
                           _PADCONVDWACT_3_KERNEL_WIDTH,
                           _PADCONVDWACT_3_ACTIVATION,
                           _CONVACT_2_OUTPUT_0_MEM_CONT_OFFSET,
                           _CONVACT_2_OUTPUT_0_MEM_CONT_SIZE,
                           _CONVACT_2_OUTPUT_0_MEM_WRAP_OFFSET,
                           _CONVACT_2_OUTPUT_0_MEM_WRAP_SIZE,
                           _CONVACT_2_OUTPUT_0_MEM_STRIDE,
                           _PADCONVDWACT_3_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVDWACT_3_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVDWACT_3_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVDWACT_3_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVDWACT_3_OUTPUT_0_MEM_STRIDE>
                           (_ConvAct_2_output_0, _PadConvDwAct_3_output_0, _PadConvDwAct_3_weights_output_0, _PadConvDwAct_3_biases_output_0, _PADCONVDWACT_3_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _PadConvDwAct_3\n");
    FILE* _PADCONVDWACT_3_OUTPUT_0_STREAM = fopen("data/export_outputs/_PadConvDwAct_3_output_0.txt", "w");
    export_cpp::saveOutputs<_PADCONVDWACT_3_OUTPUT_0_NB_OUTPUTS,
                            _PADCONVDWACT_3_OUTPUT_0_OUT_HEIGHT,
                            _PADCONVDWACT_3_OUTPUT_0_OUT_WIDTH,
                            _PADCONVDWACT_3_OUTPUT_0_MEM_CONT_OFFSET,
                            _PADCONVDWACT_3_OUTPUT_0_MEM_CONT_SIZE,
                            _PADCONVDWACT_3_OUTPUT_0_MEM_WRAP_OFFSET,
                            _PADCONVDWACT_3_OUTPUT_0_MEM_WRAP_SIZE,
                            _PADCONVDWACT_3_OUTPUT_0_DEV_FMT>
                            (_PadConvDwAct_3_output_0,
                            _PADCONVDWACT_3_OUTPUT_0_STREAM);
    fclose(_PADCONVDWACT_3_OUTPUT_0_STREAM);
    #endif




    

    float* _ConvAct_3_output_0 = (float*) (mem + _CONVACT_3_OUTPUT_0_MEM_OFFSET);

    export_cpp::convolution_forward<_PADCONVDWACT_3_OUTPUT_0_NB_CHANNELS,
                           _PADCONVDWACT_3_OUTPUT_0_IN_HEIGHT,
                           _PADCONVDWACT_3_OUTPUT_0_IN_WIDTH,
                           _CONVACT_3_OUTPUT_0_NB_OUTPUTS,
                           _CONVACT_3_OUTPUT_0_OUT_HEIGHT,
                           _CONVACT_3_OUTPUT_0_OUT_WIDTH,
                           _CONVACT_3_PADDING_Y,
                           _CONVACT_3_PADDING_X,
                           _CONVACT_3_STRIDE_Y,
                           _CONVACT_3_STRIDE_X,
                           _CONVACT_3_DILATION_Y,
                           _CONVACT_3_DILATION_X,
                           _CONVACT_3_KERNEL_HEIGHT,
                           _CONVACT_3_KERNEL_WIDTH,
                           _CONVACT_3_ACTIVATION,
                           _PADCONVDWACT_3_OUTPUT_0_MEM_CONT_OFFSET,
                           _PADCONVDWACT_3_OUTPUT_0_MEM_CONT_SIZE,
                           _PADCONVDWACT_3_OUTPUT_0_MEM_WRAP_OFFSET,
                           _PADCONVDWACT_3_OUTPUT_0_MEM_WRAP_SIZE,
                           _PADCONVDWACT_3_OUTPUT_0_MEM_STRIDE,
                           _CONVACT_3_OUTPUT_0_MEM_CONT_OFFSET,
                           _CONVACT_3_OUTPUT_0_MEM_CONT_SIZE,
                           _CONVACT_3_OUTPUT_0_MEM_WRAP_OFFSET,
                           _CONVACT_3_OUTPUT_0_MEM_WRAP_SIZE,
                           _CONVACT_3_OUTPUT_0_MEM_STRIDE>
                           (_PadConvDwAct_3_output_0, _ConvAct_3_output_0, _ConvAct_3_weights_output_0, _ConvAct_3_biases_output_0, _CONVACT_3_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _ConvAct_3\n");
    FILE* _CONVACT_3_OUTPUT_0_STREAM = fopen("data/export_outputs/_ConvAct_3_output_0.txt", "w");
    export_cpp::saveOutputs<_CONVACT_3_OUTPUT_0_NB_OUTPUTS,
                            _CONVACT_3_OUTPUT_0_OUT_HEIGHT,
                            _CONVACT_3_OUTPUT_0_OUT_WIDTH,
                            _CONVACT_3_OUTPUT_0_MEM_CONT_OFFSET,
                            _CONVACT_3_OUTPUT_0_MEM_CONT_SIZE,
                            _CONVACT_3_OUTPUT_0_MEM_WRAP_OFFSET,
                            _CONVACT_3_OUTPUT_0_MEM_WRAP_SIZE,
                            _CONVACT_3_OUTPUT_0_DEV_FMT>
                            (_ConvAct_3_output_0,
                            _CONVACT_3_OUTPUT_0_STREAM);
    fclose(_CONVACT_3_OUTPUT_0_STREAM);
    #endif




    

    float* _GlobalAveragePooling_0_output_0 = (float*) (mem + _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::pooling_forward<_CONVACT_3_OUTPUT_0_NB_CHANNELS,
                                _CONVACT_3_OUTPUT_0_IN_HEIGHT,
                                _CONVACT_3_OUTPUT_0_IN_WIDTH,
                                _GLOBALAVERAGEPOOLING_0_OUTPUT_0_NB_OUTPUTS,
                                _GLOBALAVERAGEPOOLING_0_OUTPUT_0_OUT_HEIGHT,
                                _GLOBALAVERAGEPOOLING_0_OUTPUT_0_OUT_WIDTH,
                                _GLOBALAVERAGEPOOLING_0_PADDING_Y,
                                _GLOBALAVERAGEPOOLING_0_PADDING_X,
                                _GLOBALAVERAGEPOOLING_0_STRIDE_Y,
                                _GLOBALAVERAGEPOOLING_0_STRIDE_X,
                                _GLOBALAVERAGEPOOLING_0_KERNEL_HEIGHT,
                                _GLOBALAVERAGEPOOLING_0_KERNEL_WIDTH,
                                _GLOBALAVERAGEPOOLING_0_POOLING_TYPE,
                                _GLOBALAVERAGEPOOLING_0_ACTIVATION,
                                _CONVACT_3_OUTPUT_0_MEM_CONT_OFFSET,
                                _CONVACT_3_OUTPUT_0_MEM_CONT_SIZE,
                                _CONVACT_3_OUTPUT_0_MEM_WRAP_OFFSET,
                                _CONVACT_3_OUTPUT_0_MEM_WRAP_SIZE,
                                _CONVACT_3_OUTPUT_0_MEM_STRIDE,
                                _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_CONT_SIZE,
                                _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_STRIDE>
                                (_ConvAct_3_output_0, _GlobalAveragePooling_0_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _GlobalAveragePooling_0\n");
    FILE* _GLOBALAVERAGEPOOLING_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_GlobalAveragePooling_0_output_0.txt", "w");
    export_cpp::saveOutputs<_GLOBALAVERAGEPOOLING_0_OUTPUT_0_NB_OUTPUTS,
                            _GLOBALAVERAGEPOOLING_0_OUTPUT_0_OUT_HEIGHT,
                            _GLOBALAVERAGEPOOLING_0_OUTPUT_0_OUT_WIDTH,
                            _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_CONT_SIZE,
                            _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _GLOBALAVERAGEPOOLING_0_OUTPUT_0_DEV_FMT>
                            (_GlobalAveragePooling_0_output_0,
                            _GLOBALAVERAGEPOOLING_0_OUTPUT_0_STREAM);
    fclose(_GLOBALAVERAGEPOOLING_0_OUTPUT_0_STREAM);
    #endif




    

    float* _FC_0_output_0 = (float*) (mem + _FC_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::fullyconnected_forward<_GLOBALAVERAGEPOOLING_0_OUTPUT_0_IN_BATCH,
                              _GLOBALAVERAGEPOOLING_0_OUTPUT_0_NB_CHANNELS,
                              _GLOBALAVERAGEPOOLING_0_OUTPUT_0_IN_HEIGHT,
                              _GLOBALAVERAGEPOOLING_0_OUTPUT_0_IN_WIDTH,
                              _FC_0_OUTPUT_0_NB_OUTPUTS,
                              _FC_0_OUTPUT_0_OUT_HEIGHT,
                              _FC_0_OUTPUT_0_OUT_WIDTH,
                              _FC_0_ACTIVATION,
                              _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_CONT_OFFSET,
                              _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_CONT_SIZE,
                              _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_WRAP_OFFSET,
                              _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_WRAP_SIZE,
                              _GLOBALAVERAGEPOOLING_0_OUTPUT_0_MEM_STRIDE,
                              _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                              _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                              _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                              _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                              _FC_0_OUTPUT_0_MEM_STRIDE>
                              (_GlobalAveragePooling_0_output_0, _FC_0_output_0, _FC_0_post_reshape_1_output_0, _FC_0_biases_output_0, _FC_0_RESCALING);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _FC_0\n");
    FILE* _FC_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_FC_0_output_0.txt", "w");
    export_cpp::saveOutputs<_FC_0_OUTPUT_0_NB_OUTPUTS,
                            _FC_0_OUTPUT_0_OUT_HEIGHT,
                            _FC_0_OUTPUT_0_OUT_WIDTH,
                            _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                            _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _FC_0_OUTPUT_0_DEV_FMT>
                            (_FC_0_output_0,
                            _FC_0_OUTPUT_0_STREAM);
    fclose(_FC_0_OUTPUT_0_STREAM);
    #endif




    

    float* _Softmax_0_output_0 = (float*) (mem + _SOFTMAX_0_OUTPUT_0_MEM_OFFSET);

    export_cpp::softmax_forward<_SOFTMAX_0_AXIS_SIZE,
                                _SOFTMAX_0_AXIS_SIZE_POST,
                                _SOFTMAX_0_AXIS_SIZE_PRE,
                                _FC_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _FC_0_OUTPUT_0_MEM_CONT_SIZE,
                                _FC_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _FC_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _FC_0_OUTPUT_0_MEM_STRIDE,
                                _SOFTMAX_0_OUTPUT_0_MEM_CONT_OFFSET,
                                _SOFTMAX_0_OUTPUT_0_MEM_CONT_SIZE,
                                _SOFTMAX_0_OUTPUT_0_MEM_WRAP_OFFSET,
                                _SOFTMAX_0_OUTPUT_0_MEM_WRAP_SIZE,
                                _SOFTMAX_0_OUTPUT_0_MEM_STRIDE>
                                (_FC_0_output_0, _Softmax_0_output_0);

    #ifdef SAVE_OUTPUTS
    printf("[NOTICE] - Saving outputs of node _Softmax_0\n");
    FILE* _SOFTMAX_0_OUTPUT_0_STREAM = fopen("data/export_outputs/_Softmax_0_output_0.txt", "w");
    export_cpp::saveOutputs<_SOFTMAX_0_OUTPUT_0_NB_OUTPUTS,
                            _SOFTMAX_0_OUTPUT_0_OUT_HEIGHT,
                            _SOFTMAX_0_OUTPUT_0_OUT_WIDTH,
                            _SOFTMAX_0_OUTPUT_0_MEM_CONT_OFFSET,
                            _SOFTMAX_0_OUTPUT_0_MEM_CONT_SIZE,
                            _SOFTMAX_0_OUTPUT_0_MEM_WRAP_OFFSET,
                            _SOFTMAX_0_OUTPUT_0_MEM_WRAP_SIZE,
                            _SOFTMAX_0_OUTPUT_0_DEV_FMT>
                            (_Softmax_0_output_0,
                            _SOFTMAX_0_OUTPUT_0_STREAM);
    fclose(_SOFTMAX_0_OUTPUT_0_STREAM);
    #endif



    *_Softmax_0_output_0_ptr = _Softmax_0_output_0;
}
