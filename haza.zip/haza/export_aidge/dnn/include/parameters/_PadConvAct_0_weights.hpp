#ifndef _PADCONVACT_0_WEIGHTS_OUTPUT_0_H
#define _PADCONVACT_0_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _PadConvAct_0_weights_output_0[64*10*4*1];

#endif /* _PADCONVACT_0_WEIGHTS_OUTPUT_0_H */
