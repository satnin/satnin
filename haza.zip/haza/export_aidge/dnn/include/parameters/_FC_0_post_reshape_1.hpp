#ifndef _FC_0_POST_RESHAPE_1_OUTPUT_0_H
#define _FC_0_POST_RESHAPE_1_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _FC_0_post_reshape_1_output_0[12*64];

#endif /* _FC_0_POST_RESHAPE_1_OUTPUT_0_H */
