#ifndef _PADCONVDWACT_3_WEIGHTS_OUTPUT_0_H
#define _PADCONVDWACT_3_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _PadConvDwAct_3_weights_output_0[64*3*3*1];

#endif /* _PADCONVDWACT_3_WEIGHTS_OUTPUT_0_H */
