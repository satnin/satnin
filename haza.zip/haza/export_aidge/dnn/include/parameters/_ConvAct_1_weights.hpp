#ifndef _CONVACT_1_WEIGHTS_OUTPUT_0_H
#define _CONVACT_1_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _ConvAct_1_weights_output_0[64*1*1*64];

#endif /* _CONVACT_1_WEIGHTS_OUTPUT_0_H */
