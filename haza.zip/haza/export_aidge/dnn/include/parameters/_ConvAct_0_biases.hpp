#ifndef _CONVACT_0_BIASES_OUTPUT_0_H
#define _CONVACT_0_BIASES_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _ConvAct_0_biases_output_0[64];

#endif /* _CONVACT_0_BIASES_OUTPUT_0_H */
