#ifndef _PADCONVDWACT_1_BIASES_OUTPUT_0_H
#define _PADCONVDWACT_1_BIASES_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _PadConvDwAct_1_biases_output_0[64];

#endif /* _PADCONVDWACT_1_BIASES_OUTPUT_0_H */
