#ifndef _PADCONVDWACT_1_WEIGHTS_OUTPUT_0_H
#define _PADCONVDWACT_1_WEIGHTS_OUTPUT_0_H

#include <cstdint>
#include "utils/cpp/typedefs.hpp"
#include <complex>

extern const float _PadConvDwAct_1_weights_output_0[64*3*3*1];

#endif /* _PADCONVDWACT_1_WEIGHTS_OUTPUT_0_H */
